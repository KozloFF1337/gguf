#!/usr/bin/env bash
# =====================================================================
# Доп. образы для CI/CD, которых ещё нет на сервере. Запускать на Mac (интернет).
# Результат: gitlab-deploy/images/ci-extra.tar (amd64), который грузится на сервер.
#
#   postgres:17        — Db/Integration тесты (Testcontainers)
#   docker:27.5.1-cli  — сборка образов + docker compose в deploy-job
#   nginx:alpine       — база рантайма SPA
#   altair-aspnet:9.0  — кастомная база рантайма app (aspnet + wget)
# =====================================================================
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
IMAGES="$HERE/images"
mkdir -p "$IMAGES"

THIRD=(postgres:17 docker:27.5.1-cli nginx:alpine)

echo "==> [1/3] Кастомная база рантайма altair-aspnet:9.0 (amd64)"
STAGE="$(mktemp -d)"
cp "$HERE/ci/base-aspnet.Dockerfile" "$STAGE/Dockerfile"
docker buildx build --platform linux/amd64 --provenance=false --sbom=false \
  --load -t altair-aspnet:9.0 "$STAGE"
rm -rf "$STAGE"

echo "==> [2/3] Тяну amd64-варианты сторонних образов по digest"
for img in "${THIRD[@]}"; do
  digest="$(docker manifest inspect "$img" | python3 -c '
import sys, json
d = json.load(sys.stdin)
for m in d.get("manifests", []):
    p = m.get("platform", {})
    if p.get("architecture") == "amd64" and p.get("os") == "linux":
        print(m["digest"]); break
')"
  [ -n "$digest" ] || { echo "!! нет amd64-манифеста для $img"; exit 1; }
  echo "    $img -> $digest"
  repo="${img%%:*}"
  docker pull -q "${repo}@${digest}" >/dev/null
  docker tag  "${repo}@${digest}" "$img"
done

# Проверим, что в docker:cli есть compose-плагин (нужен deploy-job).
docker run --rm --entrypoint docker docker:27.5.1-cli compose version >/dev/null 2>&1 \
  && echo "    docker compose в docker:27.5.1-cli: есть" \
  || echo "    !! ВНИМАНИЕ: в docker:27.5.1-cli нет 'docker compose' — скажи, подберу другой образ"

echo "==> [3/3] Сохраняю ci-extra.tar"
docker save altair-aspnet:9.0 "${THIRD[@]}" -o "$IMAGES/ci-extra.tar"

echo
echo "Готово:"
ls -lh "$IMAGES/ci-extra.tar"
echo "Перенеси ci-extra.tar в gitlab-deploy/images/ на сервере и загрузи:"
echo "  docker load -i images/ci-extra.tar"
