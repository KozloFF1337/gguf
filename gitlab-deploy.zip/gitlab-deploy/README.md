# GitLab на air-gapped сервере (10.16.0.155)

Self-hosted GitLab CE + Runner для хранения кода и (позже) CI/CD.
Поднимается рядом с Altair, порты не конфликтуют.

| Сервис | Порт на хосте | Назначение |
|--------|---------------|------------|
| GitLab web | **8090** | веб-интерфейс, http-клонирование |
| GitLab ssh | **2222** | клонирование по ssh (`git@host:2222`) |
| Altair (уже есть) | 4000 / 4173 / 6432 | не трогаем |
| Системный SSH | 22 | не трогаем |

Учётки после установки:

| Логин | Пароль (из `.env`) | Права |
|-------|--------------------|-------|
| `root` | `GITLAB_ROOT_PASSWORD` | суперпользователь GitLab |
| `admin` | `ADMIN_PASSWORD` | полные права администратора |
| `user` | `USER_PASSWORD` | **только чтение/клонирование** (Reporter в группе `altair`) |

---

## Часть А. Подготовка образов (на Mac, где есть интернет)

```bash
cd gitlab-deploy
./build-images.sh
```

Соберёт под **linux/amd64** и сложит в `gitlab-deploy/images/`:

- `gitlab-images.tar` — GitLab CE + Runner (~1.8 ГБ)
- `ci-dotnet.tar` — .NET 8+9 SDK с прогретым кэшем NuGet (для CI)
- `ci-node.tar` — Node 20 с прогретым кэшем npm (для CI SPA)

> Твои `~/dotnet-sdk*.tar` и `~/runner.tar` — **arm64**, на сервер не годятся.
> `ci-dotnet.tar` уже содержит оба SDK + библиотеки, поэтому raw-SDK тары не нужны.

## Часть Б. Перенос на сервер

Скопируй на сервер всю папку `gitlab-deploy/` (вместе с `images/*.tar`).
Для GitLab достаточно `gitlab-images.tar`; CI-тары (`ci-*.tar`) понадобятся
на этапе настройки CD — их можно донести позже.

## Часть В. Запуск (на сервере)

```bash
cd gitlab-deploy
cp .env.example .env        # если .env ещё нет
nano .env                   # ПОМЕНЯЙ пароли и при необходимости IP/порты
./load-and-run.sh
```

Скрипт сам: загрузит образы → поднимет compose → дождётся старта GitLab
(первый запуск 3–6 мин) → заведёт `admin`, `user` и группу `altair`.
В конце напечатает адреса и пароли.

## Часть Г. Залить проект в GitLab

На машине с кодом (репозиторий уже инициализирован — см. корневой `.gitignore`):

```bash
# http (проще для старта):
git remote add origin http://10.16.0.155:8090/altair/altair.git
git push -u origin --all

# либо ssh (добавь свой ключ в GitLab -> Preferences -> SSH Keys):
git remote add origin ssh://git@10.16.0.155:2222/altair/altair.git
git push -u origin --all
```

`user` сразу увидит проект только на чтение (клонировать может, пушить — нет).

---

## Как устроены права read-only

`user` — обычная (не админ) учётка. Доступ «только чтение» к коду даёт **роль
Reporter в группе `altair`** (Reporter может клонировать/смотреть, но не пушить).
Любой проект, созданный/залитый в группу `altair`, автоматически доступен
`user` на чтение. Хочешь дать доступ к другому проекту — добавь `user`
как Reporter в нужную группу/проект (UI: Project → Members).

## CI/CD (следующий шаг)

`ci-dotnet.tar` и `ci-node.tar` — оффлайн-образы для пайплайна (восстановление
пакетов без интернета). Когда дойдём до CD:

1. `docker load -i images/ci-dotnet.tar && docker load -i images/ci-node.tar`
2. Зарегистрировать раннер: `./register-runner.sh <glrt-токен из UI>`
3. Добавить `.gitlab-ci.yml` (соберём вместе).

## Полезное

```bash
docker logs -f gitlab                 # лог GitLab
docker exec -it gitlab gitlab-ctl status
docker exec -it gitlab gitlab-rake gitlab:check SANITIZE=true
docker compose down                   # остановить (данные в volume сохранятся)
```

Данные GitLab лежат в docker-volume'ах (`gitlab_config`, `gitlab_data`,
`gitlab_logs`, `gitlab_runner_config`) и переживают перезапуск/`down`.

## Если GitLab завис в `starting`, а Puma перезапускается

Не меняй проброс web-порта на `8090:80`, если `GITLAB_EXTERNAL_URL` содержит
`:8090`. Для Docker-образа GitLab нестандартный порт из `external_url`
становится портом nginx внутри контейнера, поэтому правильная пара здесь:

```yaml
ports:
  - "${GITLAB_HTTP_PORT:-8090}:${GITLAB_HTTP_PORT:-8090}"
```

Если поставить `8090:80`, Docker будет слать трафик на внутренний порт `80`, а
GitLab внутри контейнера продолжит ждать на `8090`; из-за этого пропадает
страница `502 Waiting for GitLab to boot`.

Чаще всего постоянный restart Puma на маленьком сервере означает нехватку RAM
или swap. В этом деплое включён более экономный режим:

```env
GITLAB_PUMA_WORKERS=0
GITLAB_SIDEKIQ_CONCURRENCY=5
```

После переноса этих правок на сервер примени конфиг так:

```bash
cd gitlab-deploy
docker compose up -d
docker exec gitlab gitlab-ctl reconfigure
docker restart gitlab
./load-and-run.sh
```

Проверки на сервере:

```bash
free -h
docker inspect --format 'OOMKilled={{.State.OOMKilled}} ExitCode={{.State.ExitCode}}' gitlab
docker exec gitlab gitlab-ctl status
docker exec gitlab tail -n 120 /var/log/gitlab/puma/puma_stderr.log
docker logs --tail 120 gitlab
```

Минимально жизнеспособная конфигурация для маленького GitLab: примерно 2 GB RAM
+ 1 GB swap, лучше 2.5+ GB RAM + swap и SSD. Если swap отсутствует, добавь его
перед повторным стартом GitLab.
