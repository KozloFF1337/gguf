# CI/CD для Альтаира на self-hosted GitLab (оффлайн)

Пайплайн (`.gitlab-ci.yml` в корне репо):

```
push в любую ветку:   build:app ─┐
                      build:spa ─┼─► (параллельно) ─► test (unit + Db + Integration)
push/merge в main:    ... ─► [deploy:app]  [deploy:spa]   ← кнопки «play» вручную
```

- **build:app** — `dotnet publish` в образе `altair-ci-dotnet` (тёплый NuGet, без сети) → артефакт `app-image/`.
- **build:spa** — `npm ci --offline && npm run build` в `altair-ci-node` → артефакт `spa-image/`.
- **test** — полный прогон `dotnet test` (unit + `Db`/`Integration`). Db/Integration поднимают `postgres:17` через Testcontainers на хостовом docker-демоне (примонтирован `docker.sock`), Ryuk выключен.
- **deploy:app / deploy:spa** — только ветка `main`, **запуск вручную** (кнопка в GitLab). Собирают рантайм-образ из артефакта поверх предзагруженной базы (оффлайн) и пересоздают сервис: `docker compose up -d --force-recreate --no-deps app|spa` в `$DEPLOY_DIR`.

---

## Разовая настройка (делается один раз)

### 1. Mac (есть интернет): собрать недостающие образы

`ci-dotnet.tar` и `ci-node.tar` у тебя уже есть. Нужны ещё четыре образа:

```bash
cd gitlab-deploy
./build-ci-extra.sh        # → images/ci-extra.tar (postgres:17, docker:cli, nginx:alpine, altair-aspnet:9.0)
```

Перенеси `images/ci-extra.tar` на сервер в `gitlab-deploy/images/`.

### 2. Сервер: загрузить все CI-образы в Docker

```bash
cd ~/gitlab-deploy
docker load -i images/ci-dotnet.tar
docker load -i images/ci-node.tar
docker load -i images/ci-extra.tar
docker images | grep -E 'altair-ci|altair-aspnet|postgres|nginx|docker'
```

### 3. Сервер: указать путь к offline-deploy

В `gitlab-deploy/.env` поправь `DEPLOY_DIR` под реальный путь, где лежит твой
`offline-deploy` на сервере (там, где `docker-compose.yml` + `.env` Альтаира):

```env
DEPLOY_DIR=/home/master/offline-deploy
```

### 4. GitLab: создать токен раннера и зарегистрировать

1. Зайди в GitLab под `admin` → **Admin area → CI/CD → Runners → New instance runner**
   → включи **«Run untagged jobs»** → **Create** → скопируй токен `glrt-…`.
2. На сервере:
   ```bash
   cd ~/gitlab-deploy
   ./register-runner.sh glrt-ТВОЙ_ТОКЕН
   docker restart gitlab-runner
   docker exec gitlab-runner gitlab-runner list   # должен показать раннера
   ```
   (Если раньше уже регистрировал раннера без нужных volume — сними старую
   регистрацию: `docker exec gitlab-runner gitlab-runner unregister --all-runners`,
   потом зарегистрируй заново скриптом выше.)

### 5. GitLab: задать переменную DEPLOY_DIR для проекта

Проект **altair/altair → Settings → CI/CD → Variables → Add variable**:
- Key: `DEPLOY_DIR`
- Value: тот же путь, что в `.env` (напр. `/home/master/offline-deploy`)
- Flags: снять «Protected» (или сделать ветку main protected), «Masked» не нужно.

### 6. Залить код (если ещё не залит)

```bash
git remote add origin http://10.16.0.155:8090/altair/altair.git
git push -u origin --all
```

После пуша пайплайн запустится сам: **CI/CD → Pipelines**.

---

## Как пользоваться

- **Каждый пуш** → автоматически `build` + `test`. Красный пайплайн = что-то сломал.
- **Выкатить на сервер** (ветка `main`, тесты зелёные): открой пайплайн →
  у джоб `deploy:app` / `deploy:spa` нажми **▶ (play)**. Каждую можно катить отдельно.

---

## Важные нюансы

- **Данные приложения.** `tech_params.xlsm` и `rating_years/*` — в `.gitignore`, в CI
  их нет, поэтому собранный в CI образ `altair-app` их не содержит. На редеплое это ок:
  named volume `app_data`/`app_config` уже заполнены с первого оффлайн-деплоя и
  переживают пересоздание контейнера. Полная пересборка «с нуля» (`down -v`) — только
  через `build-and-package.sh` на Mac.
- **postgres для тестов** — именно `postgres:17` (не alpine), как в `PostgresFixture`.
- **Сеть.** Раннер с `--docker-network-mode host` → Testcontainers коннектится к
  поднятому postgres по `localhost:<port>`. Для air-gapped всё локально, наружу не ходит.
- **docker compose в deploy.** Образ `docker:27.5.1-cli` должен содержать плагин
  `docker compose` (скрипт сборки это проверяет). Если вдруг нет — скажи, заменю образ.
- **Память.** GitLab + раннер + CI-джоба (.NET сборка/тесты) + сам Альтаир на одном
  сервере. Следи за `free -h`; тяжёлые джобы лучше не гонять параллельно с пиковой
  нагрузкой приложения.
