#!/usr/bin/env bash
# =====================================================================
# Сборка/упаковка всех образов для air-gapped GitLab-сервера (amd64).
# Запускать на Mac (нужен интернет). Результат — tar'ы в gitlab-deploy/images/:
#   gitlab-images.tar  — gitlab-ce + gitlab-runner (платформа GitLab)
#   ci-dotnet.tar      — .NET 8+9 SDK + прогретый NuGet-кэш (для CI)
#   ci-node.tar        — Node 20 + прогретый npm-кэш (для CI SPA)
#
# Сервер amd64, Mac arm64 -> всё пакуем под linux/amd64 (через QEMU/buildx).
# =====================================================================
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/.." && pwd)"
IMAGES="$HERE/images"
mkdir -p "$IMAGES"

GITLAB_IMG="gitlab/gitlab-ce:17.11.2-ce.0"
RUNNER_IMG="gitlab/gitlab-runner:latest"

echo "============================================================"
echo " 1/5  Достаю amd64-вариант GitLab Runner (локальный — arm64)"
echo "============================================================"
RUNNER_DIGEST="$(docker manifest inspect "$RUNNER_IMG" | python3 -c '
import sys, json
d = json.load(sys.stdin)
for m in d.get("manifests", []):
    p = m.get("platform", {})
    if p.get("architecture") == "amd64" and p.get("os") == "linux":
        print(m["digest"]); break
')"
[ -n "$RUNNER_DIGEST" ] || { echo "!! не нашёл amd64-манифест для $RUNNER_IMG"; exit 1; }
echo "    amd64 digest: $RUNNER_DIGEST"
docker pull "gitlab/gitlab-runner@${RUNNER_DIGEST}"
docker tag  "gitlab/gitlab-runner@${RUNNER_DIGEST}" "$RUNNER_IMG"
echo "    arch проверка: $(docker image inspect "$RUNNER_IMG" --format '{{.Architecture}}')"

echo "============================================================"
echo " 2/5  Собираю CI-образ .NET (8+9, прогретый NuGet) под amd64"
echo "============================================================"
STAGE_D="$(mktemp -d)"
( cd "$ROOT" && rsync -aR \
    Altair.sln \
    Altair/Altair.csproj \
    Altair.Shared/Altair.Shared.csproj \
    astep/astep.csproj \
    Altair.Tests/Altair.Tests.csproj \
    "$STAGE_D/" )
cp "$HERE/ci/dotnet.Dockerfile" "$STAGE_D/Dockerfile"
docker buildx build --platform linux/amd64 --provenance=false --sbom=false \
  --load -t altair-ci-dotnet:8-9 "$STAGE_D"
rm -rf "$STAGE_D"

echo "============================================================"
echo " 3/5  Собираю CI-образ Node 20 (прогретый npm) под amd64"
echo "============================================================"
STAGE_N="$(mktemp -d)"
cp "$ROOT/altair-spa/package.json" "$ROOT/altair-spa/package-lock.json" "$STAGE_N/"
cp "$HERE/ci/node.Dockerfile" "$STAGE_N/Dockerfile"
docker buildx build --platform linux/amd64 --provenance=false --sbom=false \
  --load -t altair-ci-node:20 "$STAGE_N"
rm -rf "$STAGE_N"

echo "============================================================"
echo " 4/5  Сохраняю платформу GitLab -> images/gitlab-images.tar"
echo "============================================================"
docker save "$GITLAB_IMG" "$RUNNER_IMG" -o "$IMAGES/gitlab-images.tar"

echo "============================================================"
echo " 5/5  Сохраняю CI-образы -> images/ci-dotnet.tar, ci-node.tar"
echo "============================================================"
docker save altair-ci-dotnet:8-9 -o "$IMAGES/ci-dotnet.tar"
docker save altair-ci-node:20    -o "$IMAGES/ci-node.tar"

echo
echo "Готово. Содержимое gitlab-deploy/images/:"
ls -lh "$IMAGES"/*.tar
