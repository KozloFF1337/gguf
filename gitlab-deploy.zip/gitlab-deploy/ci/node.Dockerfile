# =====================================================================
# Оффлайн CI-образ для React-SPA (altair-spa): Node 20 + прогретый npm-кэш.
#
# Собирается на машине С интернетом (Mac) под linux/amd64 — это критично:
# npm кэширует платформенные бинарники (esbuild и т.п.) под целевую архитектуру,
# поэтому кэш обязан быть собран под amd64, иначе `npm ci --offline` на сервере
# не найдёт linux-x64 бинарь esbuild.
#
# Контекст сборки — staging-каталог с package.json и package-lock.json.
# =====================================================================
FROM node:20-bookworm

WORKDIR /app
COPY package.json package-lock.json ./

# Заполняем кэш тарболлов (~/.npm). node_modules в образе не нужен —
# CI пересоздаст его из кэша командой `npm ci --offline`.
RUN npm ci --no-audit --no-fund \
 && npm cache verify \
 && rm -rf node_modules
