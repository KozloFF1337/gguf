# =====================================================================
# ОФФЛАЙН рантайм-образ React-SPA (собирается раннером на сервере).
# Контекст — артефакт job'ы build:spa (готовый dist + nginx.conf).
# nginx:alpine оффлайн самодостаточен (busybox-wget уже внутри, apt не нужен).
#
#   контекст/
#     ├── dist/        ← результат npm run build
#     └── nginx.conf
# =====================================================================
FROM nginx:alpine

RUN rm -rf /usr/share/nginx/html/* /etc/nginx/conf.d/default.conf

COPY nginx.conf /etc/nginx/conf.d/altair.conf
COPY dist/ /usr/share/nginx/html/

EXPOSE 80

HEALTHCHECK --interval=30s --timeout=5s --start-period=5s --retries=3 \
  CMD wget -qO- http://localhost/ >/dev/null || exit 1
