# =====================================================================
# ОФФЛАЙН рантайм-образ Altair (собирается раннером на сервере).
# Контекст — артефакт job'ы build:app: уже опубликованное приложение,
# поэтому здесь НЕТ ни restore, ни apt — только COPY поверх готовой базы.
#
#   контекст/
#     ├── publish/   ← результат dotnet publish
#     └── data/      ← Data/, Services/config/, seed-data/ (что есть в репо)
# =====================================================================
FROM altair-aspnet:9.0

WORKDIR /app

# Опубликованное приложение
COPY publish/ ./

# Данные/конфиги приложения. Часть файлов (tech_params.xlsm, rating_years/*)
# в .gitignore и в CI отсутствуют — на сервере они уже лежат в named volume
# app_data/app_config с первого оффлайн-деплоя и переживают пересоздание app.
COPY data/ ./

RUN mkdir -p Data/rating_years Services/config

EXPOSE 5000

# Планировщик включён (как в основном Dockerfile), автозагрузка при старте — нет.
ENTRYPOINT ["dotnet", "Altair.dll", "--no-autoload"]
