# =====================================================================
# Кастомная база рантайма для Altair: aspnet:9.0 + wget + локаль.
# Собирается на Mac (есть интернет), предзагружается на сервер.
# Нужна, потому что на air-gapped сервере `apt-get install wget` не пройдёт,
# а wget требуется для healthcheck приложения (см. offline-deploy/compose).
# =====================================================================
FROM mcr.microsoft.com/dotnet/aspnet:9.0

RUN apt-get update \
 && apt-get install -y --no-install-recommends wget \
 && rm -rf /var/lib/apt/lists/*

ENV LANG=ru_RU.UTF-8 \
    LC_ALL=ru_RU.UTF-8 \
    DOTNET_SYSTEM_GLOBALIZATION_INVARIANT=false \
    DOTNET_RUNNING_IN_CONTAINER=true \
    ASPNETCORE_URLS=http://+:5000
