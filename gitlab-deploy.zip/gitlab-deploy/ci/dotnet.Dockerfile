# =====================================================================
# Оффлайн CI-образ для .NET: SDK 8 + SDK 9 + ПРОГРЕТЫЙ NuGet-кэш всего
# solution (Altair net9, Altair.Shared net8, astep net8, Altair.Tests net9).
#
# Собирается на машине С интернетом (Mac) под linux/amd64, грузится на
# amd64 GitLab-runner. Контекст сборки — временный staging-каталог,
# куда build-images.sh кладёт только .sln и .csproj.
# =====================================================================
FROM mcr.microsoft.com/dotnet/sdk:9.0

# 1) Доставляем .NET 8 SDK рядом с 9 (общий DOTNET_ROOT=/usr/share/dotnet).
RUN curl -fsSL https://dot.net/v1/dotnet-install.sh -o /tmp/dotnet-install.sh \
 && chmod +x /tmp/dotnet-install.sh \
 && /tmp/dotnet-install.sh --channel 8.0 --install-dir /usr/share/dotnet \
 && rm /tmp/dotnet-install.sh \
 && dotnet --list-sdks

# 2) Прогреваем NuGet-кэш: restore по .sln (нужны только csproj, не исходники).
WORKDIR /src
COPY . .
RUN dotnet restore Altair.sln

# 3) Исходники больше не нужны — в образе остаётся только тёплый ~/.nuget/packages.
WORKDIR /
RUN rm -rf /src

# 4) Гарантируем оффлайн-restore: глобальный кэш как fallback, онлайн-источников нет.
#    Если пакета нет в кэше — restore честно упадёт, а не зависнет без сети.
RUN mkdir -p /root/.nuget/NuGet && printf '%s\n' \
  '<?xml version="1.0" encoding="utf-8"?>' \
  '<configuration>' \
  '  <packageSources><clear /></packageSources>' \
  '  <fallbackPackageFolders>' \
  '    <add key="warm-cache" value="/root/.nuget/packages" />' \
  '  </fallbackPackageFolders>' \
  '</configuration>' > /root/.nuget/NuGet/NuGet.Config
