# =====================================================================
# Идемпотентный сидинг GitLab: админ + read-only пользователь + группа.
# Запускается внутри контейнера через gitlab-rails runner (см. load-and-run.sh).
# Повторный запуск безопасен — обновит пароли, не наплодит дублей.
#
#   docker exec -e ADMIN_PASSWORD=... -e USER_PASSWORD=... \
#     gitlab gitlab-rails runner /tmp/seed-users.rb
# =====================================================================

admin_password = ENV['ADMIN_PASSWORD']
user_password  = ENV['USER_PASSWORD']
abort('ADMIN_PASSWORD не задан') if admin_password.to_s.empty?
abort('USER_PASSWORD не задан')  if user_password.to_s.empty?

def upsert_user(username:, name:, email:, password:, admin:)
  u = User.find_by(username: username) || User.new
  u.username              = username
  u.name                  = name
  u.email                 = email
  u.password              = password
  u.password_confirmation = password
  u.admin                 = admin
  u.skip_confirmation!                 # почта сразу подтверждена
  u.password_automatically_set = false # не требовать смены пароля при входе
  unless u.save
    abort("Не удалось сохранить пользователя #{username}: #{u.errors.full_messages.join(', ')}")
  end
  u
end

admin = upsert_user(username: 'admin', name: 'Administrator',
                    email: 'admin@example.com', password: admin_password, admin: true)
puts '✓ админ:      admin  (полные права администратора)'

ro = upsert_user(username: 'user', name: 'Read Only',
                 email: 'user@example.com', password: user_password, admin: false)
puts '✓ пользователь: user (обычная учётка)'

# --- Группа 'altair': кладёшь проект сюда, и user сразу видит его read-only ---
group = Group.find_by(full_path: 'altair')
unless group
  res = Groups::CreateService.new(
    admin,
    name: 'Altair',
    path: 'altair',
    visibility_level: Gitlab::VisibilityLevel::PRIVATE
  ).execute
  group = res.respond_to?(:payload) ? res.payload[:group] : res
end

if group&.persisted?
  group.add_owner(admin)       # админ — владелец группы
  group.add_reporter(ro)       # user — Reporter: клонировать/смотреть код, БЕЗ push
  puts "✓ группа 'altair': admin=Owner, user=Reporter (только чтение/клонирование)"
else
  warn "! Группу 'altair' создать не удалось — заведи её вручную и добавь user как Reporter."
end

puts
puts 'Готово. Залей проект в группу altair, например:'
puts '  git remote add origin http://<host>:<port>/altair/altair.git'
puts '  git push -u origin --all'
