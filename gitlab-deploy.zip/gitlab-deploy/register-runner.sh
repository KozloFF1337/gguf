#!/usr/bin/env bash
# =====================================================================
# Регистрация GitLab Runner (нужно на этапе настройки CI/CD, не сейчас).
#
# 1) В GitLab: Admin area -> CI/CD -> Runners -> New instance runner ->
#    Run untagged jobs (вкл.) -> Create -> скопируй токен вида glrt-XXXX.
# 2) Запусти:  ./register-runner.sh glrt-XXXX
#
# Раннер запускает CI-джобы в docker-контейнерах на этом же сервере, используя
# предзагруженные оффлайн-образы (altair-ci-dotnet / altair-ci-node / docker:cli …).
#
# Монтируем в КАЖДУЮ job:
#   • /var/run/docker.sock — нужен тестам (Testcontainers поднимает postgres)
#     и deploy-job (docker build + docker compose) на хостовом демоне;
#   • $DEPLOY_DIR по ТОМУ ЖЕ пути — чтобы deploy-job делал `docker compose up`
#     в реальном offline-deploy (bind-mount'ы в compose резолвятся одинаково
#     внутри job и на хосте только при совпадающем абсолютном пути).
# DEPLOY_DIR берётся из .env (см. ниже). Это же значение задай как CI/CD variable
# в проекте GitLab — его использует deploy-job в .gitlab-ci.yml.
# =====================================================================
set -euo pipefail
cd "$(dirname "$0")"
[ -f .env ] && { set -a; . ./.env; set +a; }

TOKEN="${1:-}"
[ -n "$TOKEN" ] || { echo "Использование: ./register-runner.sh <runner-token glrt-...>"; exit 1; }
URL="${GITLAB_EXTERNAL_URL:-http://10.16.0.155:8090}"
DEPLOY_DIR="${DEPLOY_DIR:-}"
[ -n "$DEPLOY_DIR" ] || { echo "!! Задай DEPLOY_DIR в .env (абсолютный путь к offline-deploy на сервере), напр. /home/master/offline-deploy"; exit 1; }

docker exec gitlab-runner gitlab-runner register \
  --non-interactive \
  --url "$URL" \
  --token "$TOKEN" \
  --executor docker \
  --docker-image "altair-ci-dotnet:8-9" \
  --docker-pull-policy if-not-present \
  --docker-volumes /var/run/docker.sock:/var/run/docker.sock \
  --docker-volumes "${DEPLOY_DIR}:${DEPLOY_DIR}" \
  --docker-network-mode host

echo "Раннер зарегистрирован (DEPLOY_DIR=${DEPLOY_DIR})."
echo "Проверка: docker exec gitlab-runner gitlab-runner list"
