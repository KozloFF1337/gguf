using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;
using Microsoft.EntityFrameworkCore;

using Altair.Data;
public class BoilerRepository : IBoilerRepository
{
    private readonly BoilerDbContext _context;
    public BoilerRepository(BoilerDbContext context)
    {
        _context = context;
    }

    public async Task<List<Boiler>> GetBoilers(PeriodType periodType)
    {
        // Для обратной совместимости: возвращаем данные с максимальной датой для данного типа периода
        var maxDate = await _context.Set<Boiler>()
            .Where(b => b.PeriodType == periodType && b.Date != null)
            .MaxAsync(b => (DateTime?)b.Date);

        if (maxDate == null)
        {
            // Старый формат данных без даты
            return await _context.Set<Boiler>()
                .Where(b => b.PeriodType == periodType)
                .ToListAsync();
        }

        return await _context.Set<Boiler>()
            .Where(b => b.PeriodType == periodType && b.Date == maxDate)
            .ToListAsync();
    }

    public async Task<List<Boiler>> GetBoilersByDate(PeriodType periodType, DateTime date)
    {
        return await _context.Set<Boiler>()
            .Where(b => b.PeriodType == periodType && b.Date == date.Date)
            .ToListAsync();
    }

    public async Task<List<DateTime>> GetAvailableDates(PeriodType periodType)
    {
        return await _context.Set<Boiler>()
            .Where(b => b.PeriodType == periodType && b.Date != null)
            .Select(b => b.Date!.Value)
            .Distinct()
            .OrderByDescending(d => d)
            .ToListAsync();
    }
}
