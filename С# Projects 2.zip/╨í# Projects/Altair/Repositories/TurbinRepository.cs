using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;
using Microsoft.EntityFrameworkCore;

using Altair.Data;
public class TurbinRepository : ITurbinRepository
{
    private readonly TurbinDbContext _context;
    public TurbinRepository(TurbinDbContext context)
    {
        _context = context;
    }

    public async Task<List<Turbin>> GetTurbins(PeriodType periodType)
    {
        // Для обратной совместимости: возвращаем данные с максимальной датой для данного типа периода
        var maxDate = await _context.Set<Turbin>()
            .Where(t => t.PeriodType == periodType && t.Date != null)
            .MaxAsync(t => (DateTime?)t.Date);

        if (maxDate == null)
        {
            // Старый формат данных без даты
            return await _context.Set<Turbin>()
                .Where(t => t.PeriodType == periodType)
                .ToListAsync();
        }

        return await _context.Set<Turbin>()
            .Where(t => t.PeriodType == periodType && t.Date == maxDate)
            .ToListAsync();
    }

    public async Task<List<Turbin>> GetTurbinsByDate(PeriodType periodType, DateTime date)
    {
        return await _context.Set<Turbin>()
            .Where(t => t.PeriodType == periodType && t.Date == date.Date)
            .ToListAsync();
    }

    public async Task<List<DateTime>> GetAvailableDates(PeriodType periodType)
    {
        return await _context.Set<Turbin>()
            .Where(t => t.PeriodType == periodType && t.Date != null)
            .Select(t => t.Date!.Value)
            .Distinct()
            .OrderByDescending(d => d)
            .ToListAsync();
    }
}
