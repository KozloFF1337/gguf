namespace Altair.Models
{
    public class HomeIndexViewModel
    {
        public HomePage? HomePage { get; set; }
        public List<Boiler> Boilers { get; set; } = new();
        public List<Turbin> Turbines { get; set; } = new();
        public PeriodType SelectedPeriod { get; set; } = PeriodType.Day;
        public DateTime? SelectedDate { get; set; }
    }
}
