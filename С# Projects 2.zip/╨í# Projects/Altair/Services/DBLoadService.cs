using System;
using System.Data;
using System.Globalization;
using Microsoft.Data.SqlClient;
using Npgsql;
using Altair.Models;

namespace Altair.Services
{
    public interface IDBLoadService
    {
        Task<string> ExecuteFullLoadAsync();
        Task<string> LoadBoilersAsync();
        Task<string> LoadTurbinesAsync();
        Task<string> ExecuteLoadWithPeriodAsync(DateTime startDate, DateTime endDate);
    }

    public class DBLoadService : IDBLoadService
    {
        private readonly ILogger<DBLoadService> _logger;
        private readonly IConfiguration _configuration;
        private readonly IDataLoadProgressService _progressService;

        public DBLoadService(ILogger<DBLoadService> logger, IConfiguration configuration, IDataLoadProgressService progressService)
        {
            _logger = logger;
            _configuration = configuration;
            _progressService = progressService;
        }

        public async Task<string> ExecuteLoadWithPeriodAsync(DateTime startDate, DateTime endDate)
        {
            if (_progressService.IsLoading)
            {
                return "⚠️ Загрузка уже выполняется. Дождитесь завершения.";
            }

            try
            {
                // 10 шагов: подключение, сырые котлы, сырые турбины, недельные КА, недельные ТА,
                // месячные КА, месячные ТА, годовые КА, годовые ТА, финальная вставка
                _progressService.StartLoading($"Загрузка данных за период {startDate:dd.MM.yyyy} - {endDate:dd.MM.yyyy}", 10);

                await Task.Run(() =>
                {
                    _logger.LogInformation($"🚀 Начало загрузки данных за период {startDate:dd.MM.yyyy} - {endDate:dd.MM.yyyy}");

                    string pgConnection = _configuration.GetConnectionString("DefaultConnection") ?? "";
                    string sqlConnection = _configuration.GetConnectionString("ASTEPConnection") ?? "";

                    using (NpgsqlConnection connection1 = new NpgsqlConnection(pgConnection))
                    using (SqlConnection connection = new SqlConnection(sqlConnection))
                    {
                        _progressService.UpdateProgress(1, "Подключение к базам данных...");
                        connection.Open();
                        connection1.Open();

                        // === ЭТАП 1: Загрузка сырых данных котлов ===
                        _progressService.UpdateProgress(2, "Загрузка сырых данных котлов...");
                        _logger.LogInformation("🔥 Загрузка котлов...");
                        GenerateDB_KA_WithPeriod(new BoilerRecord(), BuildBoilerCodes(), SQL_config.insertQuerry_KA_upsert, SQL_config.format, connection1, connection, startDate, endDate);
                        _logger.LogInformation("✅ Котлы загружены");

                        // === ЭТАП 2: Загрузка сырых данных турбин ===
                        _progressService.UpdateProgress(3, "Загрузка сырых данных турбин...");
                        _logger.LogInformation("⚙️ Загрузка турбин...");
                        GenerateDB_TA_WithPeriod(new TurbinRecord(), BuildTurbinCodes(), SQL_config.insertQuerry_TA_upsert, SQL_config.format, connection1, connection, startDate, endDate);
                        _logger.LogInformation("✅ Турбины загружены");

                        // === ЭТАП 3: Недельные данные ===
                        var weekTurbins = new List<Turbin>();
                        var weekBoilers = new List<Boiler>();

                        DateTime dt = DateTime.Now.AddDays(-9);
                        string select_TA_Week = BuildSelectQuery("raw_turbins", dt, 24);
                        string select_KA_Week = BuildSelectQuery("raw_boilers", dt, 24);

                        _progressService.UpdateProgress(4, "Обработка недельных данных турбин...");
                        DBFunctions.GetRelevantWeekData_TA(new Turbin(), weekTurbins, select_TA_Week, connection1, connection);

                        _progressService.UpdateProgress(5, "Обработка недельных данных котлов...");
                        DBFunctions.GetRelevantWeekData_KA(new Boiler(), weekBoilers, select_KA_Week, connection1, connection);

                        // === ЭТАП 4: Месячные данные ===
                        dt = DateTime.Now.AddDays(-32);
                        string select_TA_Month = BuildSelectQuery("raw_turbins", dt, 0);
                        string select_KA_Month = BuildSelectQuery("raw_boilers", dt, 0);

                        _progressService.UpdateProgress(6, "Обработка месячных данных турбин...");
                        DBFunctions.GetRelevantMonthData_TA(new Turbin(), weekTurbins, select_TA_Month, connection1, connection);

                        _progressService.UpdateProgress(7, "Обработка месячных данных котлов...");
                        DBFunctions.GetRelevantMonthData_KA(new Boiler(), weekBoilers, select_KA_Month, connection1, connection);

                        // === ЭТАП 5: Годовые данные ===
                        dt = DateTime.Now.AddDays(-367);
                        string select_TA_Year = BuildSelectQuery("raw_turbins", dt, 0);
                        string select_KA_Year = BuildSelectQuery("raw_boilers", dt, 0);

                        _progressService.UpdateProgress(8, "Обработка годовых данных турбин...");
                        DBFunctions.GetRelevantYearData_TA(new Turbin(), weekTurbins, select_TA_Year, connection1, connection);

                        _progressService.UpdateProgress(9, "Обработка годовых данных котлов...");
                        DBFunctions.GetRelevantYearData_KA(new Boiler(), weekBoilers, select_KA_Year, connection1, connection);

                        // === ЭТАП 6: Вставка итоговых данных ===
                        _progressService.UpdateProgress(10, "Сохранение итоговых данных...");
                        DBFunctions.InsertFinalData_TA(SQL_config.truncate_week_TA, SQL_config.insertQuerry_week_TA, weekTurbins, connection1);
                        DBFunctions.InsertFinalData_KA(SQL_config.truncate_week_KA, SQL_config.insertQuerry_week_KA, weekBoilers, connection1);

                        connection1.Close();
                        connection.Close();
                    }
                });

                _progressService.CompleteLoading(true, "✅ Все данные успешно загружены!");
                _logger.LogInformation("🎉 Все данные успешно загружены!");
                return "✅ Все данные успешно загружены! Процесс завершен.";
            }
            catch (Exception ex)
            {
                _progressService.CompleteLoading(false, $"❌ Ошибка: {ex.Message}");
                _logger.LogError(ex, "❌ Ошибка при загрузке данных");
                return $"❌ Ошибка: {ex.Message}";
            }
        }

        public async Task<string> ExecuteFullLoadAsync()
        {
            // По умолчанию загружаем данные за весь 2025 год
            return await ExecuteLoadWithPeriodAsync(new DateTime(2025, 1, 1), DateTime.Now);
        }

        public async Task<string> LoadBoilersAsync()
        {
            try
            {
                string pgConnection = _configuration.GetConnectionString("DefaultConnection") ?? "";
                string sqlConnection = _configuration.GetConnectionString("ASTEPConnection") ?? "";

                using (NpgsqlConnection connection1 = new NpgsqlConnection(pgConnection))
                using (SqlConnection connection = new SqlConnection(sqlConnection))
                {
                    connection.Open();
                    connection1.Open();
                    DBFunctions.GenerateDB_KA(new BoilerRecord(), BuildBoilerCodes(), SQL_config.insertQuerry_KA, SQL_config.format, connection1, connection);
                    connection1.Close();
                    connection.Close();
                }

                return "✅ Котлы загружены";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при загрузке котлов");
                return $"❌ Ошибка: {ex.Message}";
            }
        }

        public async Task<string> LoadTurbinesAsync()
        {
            try
            {
                string pgConnection = _configuration.GetConnectionString("DefaultConnection") ?? "";
                string sqlConnection = _configuration.GetConnectionString("ASTEPConnection") ?? "";

                using (NpgsqlConnection connection1 = new NpgsqlConnection(pgConnection))
                using (SqlConnection connection = new SqlConnection(sqlConnection))
                {
                    connection.Open();
                    connection1.Open();
                    DBFunctions.GenerateDB_TA(new TurbinRecord(), BuildTurbinCodes(), SQL_config.insertQuerry_TA, SQL_config.format, connection1, connection);
                    connection1.Close();
                    connection.Close();
                }

                return "✅ Турбины загружены";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при загрузке турбин");
                return $"❌ Ошибка: {ex.Message}";
            }
        }

        private void GenerateDB_KA_WithPeriod(BoilerRecord rec_KA, Dictionary<int, List<string>> matching_dict_KA, string insertQuerry_KA, string format, NpgsqlConnection connection1, SqlConnection connection, DateTime startDate, DateTime endDate)
        {
            foreach (var dic in matching_dict_KA)
            {
                foreach (string code in dic.Value)
                {
                    string sql_start = $"exec dbo.p_GetParamValuePivot '{DBFunctions.Correct(dic.Key)}','Основная', ";
                    string sql_end = $", '{startDate:yyyy-MM-dd} 00:00:00', '{endDate:yyyy-MM-dd} 23:00:00', 'Сутки';";

                    rec_KA.StationID = short.Parse(code.Substring(11, 2));
                    rec_KA.BoilerID = code.Substring(1, 2) + ((code[9] == '0') ? "" : code[9].ToString());
                    rec_KA.BoilerID = rec_KA.BoilerID.Replace("A", "А").Replace("B", "Б");

                    string a = sql_start + code + sql_end;
                    SqlCommand command = new SqlCommand(a, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        try
                        {
                            rec_KA.Date = DateTime.ParseExact(reader[0].ToString()!.Substring(0, 10), format, CultureInfo.InvariantCulture);
                            rec_KA.Consumption = TryParseDouble(reader[1]);
                            rec_KA.KPD = TryParseDouble(reader[2]);
                            rec_KA.Production = TryParseDouble(reader[3]);
                            rec_KA.Hours = int.TryParse(reader[4]?.ToString(), out var hours) ? hours : 0;
                            rec_KA.humidity = TryParseDouble(reader[5]);
                            rec_KA.ash = TryParseDouble(reader[6]);
                            rec_KA.temp_fact = TryParseDouble(reader[7]);
                            rec_KA.temp_nominal = TryParseDouble(reader[8]);
                            rec_KA.temp_koef = TryParseDouble(reader[9]);

                            using (var insertCommand = new NpgsqlCommand(insertQuerry_KA, connection1))
                            {
                                insertCommand.Parameters.AddWithValue("@BoilerID", rec_KA.BoilerID);
                                insertCommand.Parameters.AddWithValue("@StationID", rec_KA.StationID);
                                insertCommand.Parameters.AddWithValue("@Production", rec_KA.Production);
                                insertCommand.Parameters.AddWithValue("@KPD", rec_KA.KPD);
                                insertCommand.Parameters.AddWithValue("@Date", rec_KA.Date);
                                insertCommand.Parameters.AddWithValue("@Consumption", rec_KA.Consumption);
                                insertCommand.Parameters.AddWithValue("@Hours", rec_KA.Hours);
                                insertCommand.Parameters.AddWithValue("@Temp_fact", rec_KA.temp_fact);
                                insertCommand.Parameters.AddWithValue("@Temp_nominal", rec_KA.temp_nominal);
                                insertCommand.Parameters.AddWithValue("@Temp_koef", rec_KA.temp_koef);
                                insertCommand.Parameters.AddWithValue("@Humidity", rec_KA.humidity);
                                insertCommand.Parameters.AddWithValue("@Ash", rec_KA.ash);

                                insertCommand.ExecuteNonQuery();
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Ошибка при обработке строки: {ex.Message}");
                        }
                    }
                    reader.Close();
                }
            }
        }

        private void GenerateDB_TA_WithPeriod(TurbinRecord rec_TA, Dictionary<int, List<string>> matching_dict_TA, string insertQuerry_TA, string format, NpgsqlConnection connection1, SqlConnection connection, DateTime startDate, DateTime endDate)
        {
            foreach (var dic in matching_dict_TA)
            {
                foreach (string code in dic.Value)
                {
                    string sql_start = $"exec dbo.p_GetParamValuePivot '{DBFunctions.Correct(dic.Key)}','Основная', ";
                    string sql_end = $", '{startDate:yyyy-MM-dd} 00:00:00', '{endDate:yyyy-MM-dd} 23:00:00', 'Сутки';";

                    rec_TA.StationID = short.Parse(code.Substring(11, 2));
                    rec_TA.TurbinID = code.Substring(1, 2) + ((code[9] == '0') ? "" : code[9].ToString());
                    rec_TA.TurbinID = rec_TA.TurbinID.Replace("A", "А").Replace("B", "Б");

                    string a = sql_start + code + sql_end;
                    SqlCommand command = new SqlCommand(a, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        try
                        {
                            rec_TA.Date = DateTime.ParseExact(reader[0].ToString()!.Substring(0, 10), format, CultureInfo.InvariantCulture);
                            rec_TA.URT = TryParseDouble(reader[1]);
                            rec_TA.Consumption = TryParseDouble(reader[2]);
                            rec_TA.Hours = int.TryParse(reader[3]?.ToString(), out var hours) ? hours : 0;
                            rec_TA.variation = TryParseDouble(reader[4]);

                            if (reader.FieldCount > 5)
                            {
                                rec_TA.NominalURT = TryParseDouble(reader[5]);
                            }
                            else
                            {
                                rec_TA.NominalURT = 0;
                            }

                            using (var insertCommand = new NpgsqlCommand(insertQuerry_TA, connection1))
                            {
                                insertCommand.Parameters.AddWithValue("@TurbinID", rec_TA.TurbinID);
                                insertCommand.Parameters.AddWithValue("@StationID", rec_TA.StationID);
                                insertCommand.Parameters.AddWithValue("@URT", rec_TA.URT);
                                insertCommand.Parameters.AddWithValue("@Date", rec_TA.Date);
                                insertCommand.Parameters.AddWithValue("@Consumption", rec_TA.Consumption);
                                insertCommand.Parameters.AddWithValue("@Hours", rec_TA.Hours);
                                insertCommand.Parameters.AddWithValue("@Variation", rec_TA.variation);
                                insertCommand.Parameters.AddWithValue("@NominalURT", rec_TA.NominalURT);

                                insertCommand.ExecuteNonQuery();
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Ошибка при обработке строки: {ex.Message}");
                        }
                    }
                    reader.Close();
                }
            }
        }

        private static double TryParseDouble(object value)
        {
            if (value is DBNull || string.IsNullOrWhiteSpace(value?.ToString()))
                return 0;

            string normalizedValue = value.ToString()!.Trim().Replace(',', '.');

            if (!double.TryParse(normalizedValue, NumberStyles.Float | NumberStyles.AllowThousands, CultureInfo.InvariantCulture, out var result))
                return 0;

            return Math.Round(result, 3);
        }

        private Dictionary<int, List<string>> BuildBoilerCodes()
        {
            return new Dictionary<int, List<string>>
            {
                { 25, Akscodes.GetBoilerCodes(25) },
                { 9, Akscodes.GetBoilerCodes(9) },
                { 15, Akscodes.GetBoilerCodes(15) },
                { 1, Akscodes.GetBoilerCodes(1) }
            };
        }

        private Dictionary<int, List<string>> BuildTurbinCodes()
        {
            return new Dictionary<int, List<string>>
            {
                { 25, Akscodes.GetTurbineCodes(25) },
                { 9, Akscodes.GetTurbineCodes(9) },
                { 15, Akscodes.GetTurbineCodes(15) },
                { 1, Akscodes.GetTurbineCodes(1) }
            };
        }

        private string BuildSelectQuery(string table, DateTime dt, int hours)
        {
            string dateStr = $"{dt.Year}-{(dt.Month < 10 ? "0" : "")}{dt.Month}-{(dt.Day < 10 ? "0" : "")}{dt.Day}";
            string hoursCondition = hours > 0 ? $"AND hours = {hours}" : "";
            string idField = table == "raw_turbins" ? "turbinid" : "boilerid";

            return $@"SELECT *
                FROM {table}
                WHERE ({idField}, stationid) IN (
                    SELECT {idField}, stationid
                        FROM {table}
                        WHERE date > '{dateStr}' {hoursCondition} AND consumption > 0
                        GROUP BY {idField}, stationid
                        HAVING COUNT(*) > 3
                        AND NOT EXISTS (
                            SELECT 1
                            FROM {table} AS t2
                            WHERE t2.{idField} = {table}.{idField}
                            AND t2.stationid = {table}.stationid
                            AND t2.hours <> {(hours > 0 ? hours : 24)}
                            AND t2.date = (SELECT MAX(date)
                                            FROM {table} AS t3
                                            WHERE t3.{idField} = t2.{idField}
                                            AND t3.stationid = t2.stationid)
                            )) and date > '{dateStr}' {hoursCondition} AND consumption > 0
                            ORDER BY stationid, {idField}, date;";
        }
    }
}
