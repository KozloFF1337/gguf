#!/usr/bin/env bash
# =====================================================================
# Регистрация GitLab Runner (нужно на этапе настройки CI/CD, не сейчас).
#
# 1) В GitLab: Admin area -> CI/CD -> Runners -> New instance runner ->
#    Run untagged jobs (вкл.) -> Create -> скопируй токен вида glrt-XXXX.
# 2) Запусти:  ./register-runner.sh glrt-XXXX
#
# Раннер будет запускать CI-джобы в docker-контейнерах на этом же сервере,
# используя оффлайн-образы altair-ci-dotnet / altair-ci-node.
# =====================================================================
set -euo pipefail
cd "$(dirname "$0")"
[ -f .env ] && { set -a; . ./.env; set +a; }

TOKEN="${1:-}"
[ -n "$TOKEN" ] || { echo "Использование: ./register-runner.sh <runner-token glrt-...>"; exit 1; }
URL="${GITLAB_EXTERNAL_URL:-http://10.16.0.155:8090}"

docker exec gitlab-runner gitlab-runner register \
  --non-interactive \
  --url "$URL" \
  --token "$TOKEN" \
  --executor docker \
  --docker-image "altair-ci-dotnet:8-9" \
  --docker-pull-policy if-not-present \
  --docker-volumes /var/run/docker.sock:/var/run/docker.sock \
  --docker-network-mode host

echo "Раннер зарегистрирован. Проверка: docker exec gitlab-runner gitlab-runner list"
