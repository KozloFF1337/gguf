#!/usr/bin/env bash
# =====================================================================
# Запуск GitLab на air-gapped СЕРВЕРЕ (без интернета).
# Запускать из папки gitlab-deploy/ на сервере:
#   ./load-and-run.sh
#
# Делает: docker load образов -> compose up -> ждёт готовности ->
#         заводит пользователей admin/user и группу altair.
# Первый старт GitLab долгий (3-6 минут) — это нормально.
# =====================================================================
set -euo pipefail
cd "$(dirname "$0")"

# docker compose (v2) или docker-compose (v1)
if docker compose version >/dev/null 2>&1; then DC="docker compose"; else DC="docker-compose"; fi

dump_gitlab_diagnostics() {
  echo
  echo "==================== GitLab diagnostics ===================="
  echo "==> docker ps"
  docker ps --filter name=gitlab --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}' || true
  echo
  echo "==> gitlab-ctl status"
  docker exec gitlab gitlab-ctl status || true
  echo
  echo "==> healthcheck"
  docker inspect --format '{{json .State.Health}}' gitlab || true
  echo
  echo "==> possible OOM events"
  docker inspect --format 'OOMKilled={{.State.OOMKilled}} ExitCode={{.State.ExitCode}} Error={{.State.Error}}' gitlab || true
  echo
  echo "==> last container logs"
  docker logs --tail 120 gitlab || true
  echo
  echo "==> last Puma logs"
  docker exec gitlab tail -n 120 /var/log/gitlab/puma/puma_stderr.log /var/log/gitlab/puma/puma_stdout.log || true
  echo
  echo "==> last nginx/gitlab-workhorse logs"
  docker exec gitlab tail -n 80 /var/log/gitlab/nginx/gitlab_error.log /var/log/gitlab/gitlab-workhorse/current || true
  echo "============================================================"
}

# --- 1. .env ---
[ -f .env ] || { echo "!! Нет .env — скопируй .env.example в .env и поправь пароли."; exit 1; }
set -a; . ./.env; set +a

# --- 2. Загрузка образов ---
if [ -f images/gitlab-images.tar ]; then
  echo "==> docker load images/gitlab-images.tar (gitlab-ce + gitlab-runner)"
  docker load -i images/gitlab-images.tar
else
  echo "!! images/gitlab-images.tar не найден — считаю, что образы уже загружены."
fi

# --- 3. Подъём ---
echo "==> $DC up -d"
$DC up -d

# --- 4. Ждём, пока GitLab реально загрузится (rails отвечает) ---
echo "==> Жду готовности GitLab (первый старт — несколько минут)…"
ready=0
for _ in $(seq 1 80); do   # 80 * 15s = до 20 минут
  if docker exec gitlab gitlab-rails runner 'nil' >/dev/null 2>&1; then ready=1; break; fi
  printf '.'; sleep 15
done
echo
[ "$ready" = 1 ] || { echo "!! GitLab не поднялся за отведённое время."; dump_gitlab_diagnostics; exit 1; }
echo "   GitLab готов."

# --- 5. Сидинг пользователей ---
echo "==> Завожу admin / user и группу altair"
docker cp seed-users.rb gitlab:/tmp/seed-users.rb
docker exec \
  -e ADMIN_PASSWORD="${ADMIN_PASSWORD}" \
  -e USER_PASSWORD="${USER_PASSWORD}" \
  gitlab gitlab-rails runner /tmp/seed-users.rb

# --- 6. Итог ---
SSH_HOST="${GITLAB_HOSTNAME:-10.16.0.155}"
SSH_PORT="${GITLAB_SSH_PORT:-2222}"
echo
echo "============================================================"
echo "  GitLab поднят: ${GITLAB_EXTERNAL_URL}"
echo "  ------------------------------------------------------------"
echo "  root  / ${GITLAB_ROOT_PASSWORD}     (суперпользователь GitLab)"
echo "  admin / ${ADMIN_PASSWORD}     (полные права)"
echo "  user  / ${USER_PASSWORD}     (только чтение/клонирование)"
echo "  ------------------------------------------------------------"
echo "  Клонировать (после заливки проекта в группу altair):"
echo "    http: ${GITLAB_EXTERNAL_URL}/altair/altair.git"
echo "    ssh:  ssh://git@${SSH_HOST}:${SSH_PORT}/altair/altair.git"
echo "============================================================"
