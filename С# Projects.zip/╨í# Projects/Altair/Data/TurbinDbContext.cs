using Microsoft.EntityFrameworkCore;
using Altair.Models;

namespace Altair.Data
{
    public class TurbinDbContext : DbContext
    {
        public TurbinDbContext(DbContextOptions<TurbinDbContext> options) : base(options) { }

        public DbSet<Turbin> Turbins { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new TurbinConfig());
        }
    }
}
