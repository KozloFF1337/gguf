using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Altair.Models;

namespace Altair.Data
{
    public class BoilerConfig : IEntityTypeConfiguration<Boiler>
    {
        public void Configure(EntityTypeBuilder<Boiler> builder)
        {
            builder.HasKey(b => b.Id);
            builder.Property(b => b.StationID).IsRequired();
            builder.Property(b => b.BoilerID).IsRequired();
            builder.Property(b => b.PeriodType).IsRequired();
            builder.Property(b => b.PeriodValue).IsRequired();
            builder.Property(b => b.KPD).IsRequired();
            builder.Property(b => b.Production).IsRequired();
            builder.Property(b => b.Consumption).IsRequired();
            // Добавьте остальные нужные поля
        }
    }
}
