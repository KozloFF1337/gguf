using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


internal class HomePageConfig : IEntityTypeConfiguration<HomePageEntity>
{
    public void Configure(EntityTypeBuilder<HomePageEntity> builder)
    {
        builder.Property(h => h.year).IsRequired();
        builder.Property(h => h.boilers_total).IsRequired();
        builder.Property(h => h.turbins_total).IsRequired();
        builder.Property(h => h.reservs_total_rub).IsRequired();
        builder.Property(h => h.reservs_total_tut).IsRequired();
        builder.Property(h => h.boilers_prisosi).IsRequired();
        builder.Property(h => h.boilers_nedozhogi).IsRequired();
        builder.Property(h => h.boilers_rs).IsRequired();
        builder.Property(h => h.boilers_temp).IsRequired();
        builder.Property(h => h.boilers_consumption).IsRequired();
        builder.Property(h => h.turbins_vac).IsRequired();
        builder.Property(h => h.turbins_rezhim).IsRequired();
        builder.Property(h => h.turbins_temp_pv).IsRequired();
        builder.Property(h => h.turbins_steam_temp).IsRequired();
        builder.Property(h => h.turbins_steam_pressure).IsRequired();
        builder.Property(h => h.turbins_steam_after_pp).IsRequired();
        builder.Property(h => h.turbins_steam_in_reg).IsRequired();
        builder.Property(h => h.turbins_neplan).IsRequired();
        builder.Property(h => h.boilers_final_1).IsRequired();
        builder.Property(h => h.boilers_final_2).IsRequired();
        builder.Property(h => h.boilers_final_3).IsRequired();
        builder.Property(h => h.boilers_final_4).IsRequired();
        builder.Property(h => h.boilers_final_5).IsRequired();
        builder.Property(h => h.boilers_final_6).IsRequired();
        builder.Property(h => h.boilers_final_7).IsRequired();
        builder.Property(h => h.boilers_final_8).IsRequired();
        builder.Property(h => h.boilers_final_9).IsRequired();
        builder.Property(h => h.boilers_final_10).IsRequired();
        builder.Property(h => h.boilers_final_11).IsRequired();
        builder.Property(h => h.boilers_final_12).IsRequired();
        builder.Property(h => h.boilers_final_1_rub).IsRequired();
        builder.Property(h => h.boilers_final_2_rub).IsRequired();
        builder.Property(h => h.boilers_final_3_rub).IsRequired();
        builder.Property(h => h.boilers_final_4_rub).IsRequired();
        builder.Property(h => h.boilers_final_5_rub).IsRequired();
        builder.Property(h => h.boilers_final_6_rub).IsRequired();
        builder.Property(h => h.boilers_final_7_rub).IsRequired();
        builder.Property(h => h.boilers_final_8_rub).IsRequired();
        builder.Property(h => h.boilers_final_9_rub).IsRequired();
        builder.Property(h => h.boilers_final_10_rub).IsRequired();
        builder.Property(h => h.boilers_final_11_rub).IsRequired();
        builder.Property(h => h.boilers_final_12_rub).IsRequired();
        builder.Property(h => h.turbins_final_1).IsRequired();
        builder.Property(h => h.turbins_final_2).IsRequired();
        builder.Property(h => h.turbins_final_3).IsRequired();
        builder.Property(h => h.turbins_final_4).IsRequired();
        builder.Property(h => h.turbins_final_5).IsRequired();
        builder.Property(h => h.turbins_final_6).IsRequired();
        builder.Property(h => h.turbins_final_7).IsRequired();
        builder.Property(h => h.turbins_final_8).IsRequired();
        builder.Property(h => h.turbins_final_9).IsRequired();
        builder.Property(h => h.turbins_final_10).IsRequired();
        builder.Property(h => h.turbins_final_11).IsRequired();
        builder.Property(h => h.turbins_final_12).IsRequired();
        builder.Property(h => h.turbins_final_1_rub).IsRequired();
        builder.Property(h => h.turbins_final_2_rub).IsRequired();
        builder.Property(h => h.turbins_final_3_rub).IsRequired();
        builder.Property(h => h.turbins_final_4_rub).IsRequired();
        builder.Property(h => h.turbins_final_5_rub).IsRequired();
        builder.Property(h => h.turbins_final_6_rub).IsRequired();
        builder.Property(h => h.turbins_final_7_rub).IsRequired();
        builder.Property(h => h.turbins_final_8_rub).IsRequired();
        builder.Property(h => h.turbins_final_9_rub).IsRequired();
        builder.Property(h => h.turbins_final_10_rub).IsRequired();
        builder.Property(h => h.turbins_final_11_rub).IsRequired();
        builder.Property(h => h.turbins_final_12_rub).IsRequired();
    }
}