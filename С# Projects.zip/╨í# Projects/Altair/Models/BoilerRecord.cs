using System;

namespace Altair.Models
{
    public class BoilerRecord
    {
        public int StationID { get; set; }
        public string BoilerID { get; set; } = string.Empty;
        public double KPD { get; set; }
        public double Production { get; set; }
        public double Consumption { get; set; }
        public double Hours { get; set; }
        public DateTime Date { get; set; }
        public double humidity { get; set; }
        public double ash { get; set; }
        public double temp_fact { get; set; }
        public double temp_nominal { get; set; }
        public double temp_koef { get; set; }
    }
}
