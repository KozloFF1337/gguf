namespace Altair.Models
{
    public class HomeIndexViewModel
    {
        public HomePage? HomePage { get; set; }
        public List<Boiler> Boilers { get; set; } = new();
        public List<Turbin> Turbines { get; set; } = new();
        public PeriodType SelectedPeriod { get; set; } = PeriodType.Day;
        public DateTime? SelectedDate { get; set; }
        public double ReservesRub { get; set; }

        // Данные для графика по месяцам (текущий год)
        public double[] MonthlyTurbinesRub { get; set; } = new double[12];
        public double[] MonthlyBoilersRub { get; set; } = new double[12];
        public double[] MonthlyTotalRub { get; set; } = new double[12];

        // Данные для графика по месяцам (предыдущий год)
        public double[] MonthlyTurbinesRubPrev { get; set; } = new double[12];
        public double[] MonthlyBoilersRubPrev { get; set; } = new double[12];
        public double[] MonthlyTotalRubPrev { get; set; } = new double[12];
    }
}
