namespace Altair.Models
{
    public class Boiler
    {
        public int Id { get; set; }
        public int StationID { get; set; }
        public string BoilerID { get; set; } = "";
        public PeriodType PeriodType { get; set; }
        public int PeriodValue { get; set; }
        public double KPD { get; set; }
        // Поправка для нормативного КПД: kpd_correction = humidity + ash - (temp_fact - temp_nominal) * temp_koef
        // Скорректированный норматив = baseKPD_from_config - KPD_correction
        public double KPD_correction { get; set; }
        public double Production { get; set; }
        public double Consumption { get; set; }

        // Дата для дневных данных (для Day - конкретная дата, для Month - первый день месяца, для Year - первый день года)
        public DateTime? Date { get; set; }
    }
}