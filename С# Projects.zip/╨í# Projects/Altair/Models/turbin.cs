namespace Altair.Models
{
    public class Turbin
    {
        public int Id { get; set; }
        public int StationID { get; set; }
        public string TurbinID { get; set; } = "";
        public PeriodType PeriodType { get; set; }
        public int PeriodValue { get; set; }
        public double URT { get; set; }
        public double Consumption { get; set; }
        public double NominalURT { get; set; }
        // Поправка на вакуум из АСТЭП. Если nominal_urt = 0 (нет акскода), то в JS:
        // NominalURT_adjusted = normative_config_urt + Variation
        public double Variation { get; set; }

        // Дата для дневных данных (для Day - конкретная дата, для Month - первый день месяца, для Year - первый день года)
        public DateTime? Date { get; set; }
    }
}