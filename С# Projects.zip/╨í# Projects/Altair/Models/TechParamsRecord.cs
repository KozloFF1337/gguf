namespace Altair.Models
{
    public class TechParamsRecord
    {
        public int RowNumber { get; set; }
        public string StationName { get; set; } = string.Empty;
        public string EquipmentParameter { get; set; } = string.Empty;
        public double? ActualValue { get; set; }
        public double? NormValue { get; set; }
        public string DeviationStartDate { get; set; } = string.Empty;
        public string DaysCount { get; set; } = string.Empty;
    }

    public class TechParamsData
    {
        public List<TechParamsRecord> GresRecords { get; set; } = new();
        public List<TechParamsRecord> TecRecords { get; set; } = new();
        public DateTime? LastUpdated { get; set; }
    }

    public class TechParamsViewModel
    {
        public TechParamsData Data { get; set; } = new();
        public string SelectedType { get; set; } = "GRES"; // GRES или TEC
    }
}
