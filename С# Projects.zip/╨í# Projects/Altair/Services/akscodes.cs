using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using ClosedXML.Excel;
using Altair.Models;

namespace Altair.Services
{
    public static class Akscodes
{
    // Словари для хранения данных котлов и турбин
    public static Dictionary<int, List<string>> matching_dict_KA { get; private set; } = new Dictionary<int, List<string>>();
    public static Dictionary<int, List<string>> matching_dict_TA { get; private set; } = new Dictionary<int, List<string>>();

    // Словарь для хранения акскодов стоимости ТУТ (станция → акскод)
    public static Dictionary<int, string> matching_dict_FuelPrice { get; private set; } = new Dictionary<int, string>();

    // Дополнительные поля
    public static BoilerRecord rec_KA = new BoilerRecord();
    public static TurbinRecord rec_TA = new TurbinRecord();
    public static Turbin rec_WT = new Turbin();
    public static Boiler rec_WB = new Boiler();
    public static List<Turbin> weekTurbins = new List<Turbin>();
    public static List<Boiler> weekBoilers = new List<Boiler>();

    // Базовый путь к папке Services/config (устанавливается при инициализации)
    private static string _configBasePath = "";

    /// <summary>
    /// Инициализирует базовый путь для конфигурационных файлов
    /// </summary>
    public static void Initialize(string contentRootPath)
    {
        _configBasePath = Path.Combine(contentRootPath, "Services", "config");
        LoadFromExcel();
    }

    // Статический конструктор - пустой, загрузка происходит через Initialize
    static Akscodes()
    {
        // Загрузка происходит через Initialize()
    }

    /// <summary>
    /// Загружает данные из Excel файла config/config.xlsx
    /// </summary>
    private static void LoadFromExcel()
    {
        // Если путь не инициализирован, пробуем определить автоматически
        if (string.IsNullOrEmpty(_configBasePath))
        {
            // Пробуем найти путь относительно текущей директории
            string currentDir = Directory.GetCurrentDirectory();
            _configBasePath = Path.Combine(currentDir, "Services", "config");
        }

        string configPath = Path.Combine(_configBasePath, "config.xlsx");

        if (!File.Exists(configPath))
        {
            Console.WriteLine($"[Akscodes] Файл конфигурации не найден: {configPath}");
            return;
        }

        try
        {
            using (var workbook = new XLWorkbook(configPath))
            {
                foreach (var worksheet in workbook.Worksheets)
                {
                    // Лист "Стоимость ТУТ" — отдельный лист с акскодами стоимости для всех станций
                    if (worksheet.Name == "Стоимость ТУТ")
                    {
                        LoadFuelPriceSheet(worksheet);
                        continue;
                    }

                    // Пропускаем лист инструкции
                    if (worksheet.Name == "Инструкция")
                        continue;

                    // Извлекаем код станции из названия листа (первые 2 символа)
                    string sheetName = worksheet.Name;
                    if (sheetName.Length < 2)
                        continue;

                    if (!int.TryParse(sheetName.Substring(0, 2), out int stationCode))
                        continue;

                    // Парсим данные листа
                    var boilerRows = new List<string>();
                    var turbineRows = new List<string>();

                    bool inBoilers = false;
                    bool inTurbines = false;
                    int headerRow = 0;

                    int lastRow = worksheet.LastRowUsed()?.RowNumber() ?? 0;

                    for (int row = 1; row <= lastRow; row++)
                    {
                        string cellA = GetCellValue(worksheet, row, 1);

                        if (cellA == "КОТЛЫ")
                        {
                            inBoilers = true;
                            inTurbines = false;
                            headerRow = row + 1;
                            continue;
                        }

                        if (cellA == "ТУРБИНЫ")
                        {
                            inBoilers = false;
                            inTurbines = true;
                            headerRow = row + 1;
                            continue;
                        }

                        // Пропускаем заголовки и пустые строки
                        if (row == headerRow || string.IsNullOrWhiteSpace(cellA) || cellA.Contains("(код:"))
                            continue;

                        if (inBoilers)
                        {
                            // Читаем 9 параметров котла (колонки B-J)
                            var values = new List<string>();
                            for (int col = 2; col <= 10; col++)
                            {
                                values.Add(GetCellValue(worksheet, row, col));
                            }

                            if (values.Count > 0 && !string.IsNullOrWhiteSpace(values[0]))
                            {
                                boilerRows.Add("'" + string.Join(",", values) + "'");
                            }
                        }
                        else if (inTurbines)
                        {
                            // Читаем 5 параметров турбины (колонки B-F)
                            var values = new List<string>();
                            for (int col = 2; col <= 6; col++)
                            {
                                values.Add(GetCellValue(worksheet, row, col));
                            }

                            // Убираем пустые значения в конце
                            while (values.Count > 0 && string.IsNullOrWhiteSpace(values[values.Count - 1]))
                                values.RemoveAt(values.Count - 1);

                            if (values.Count > 0 && !string.IsNullOrWhiteSpace(values[0]))
                            {
                                turbineRows.Add("'" + string.Join(",", values) + "'");
                            }
                        }
                    }

                    // Добавляем данные в словари
                    if (boilerRows.Count > 0)
                    {
                        matching_dict_KA[stationCode] = boilerRows;
                    }

                    if (turbineRows.Count > 0)
                    {
                        matching_dict_TA[stationCode] = turbineRows;
                    }
                }
            }

            // Если акскоды стоимости ТУТ не загружены из config.xlsx — используем дефолтные из Книга1.xlsx
            if (matching_dict_FuelPrice.Count == 0)
            {
                InitializeDefaultFuelPriceCodes();
            }

            Console.WriteLine($"[Akscodes] Загружено станций КА: {matching_dict_KA.Count}, ТА: {matching_dict_TA.Count}, Стоимость ТУТ: {matching_dict_FuelPrice.Count}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[Akscodes] Ошибка загрузки конфигурации: {ex.Message}");
        }
    }

    /// <summary>
    /// Загрузка акскодов стоимости ТУТ с отдельного листа "Стоимость ТУТ"
    /// Формат: колонка A = код станции, колонка B = название, колонка C = акскод
    /// Первая строка — заголовки, данные со второй строки
    /// </summary>
    private static void LoadFuelPriceSheet(IXLWorksheet worksheet)
    {
        int lastRow = worksheet.LastRowUsed()?.RowNumber() ?? 0;

        for (int row = 2; row <= lastRow; row++) // пропускаем заголовок
        {
            string cellA = GetCellValue(worksheet, row, 1); // Код станции
            string cellC = GetCellValue(worksheet, row, 3); // Акскод

            if (string.IsNullOrWhiteSpace(cellA) || string.IsNullOrWhiteSpace(cellC))
                continue;

            if (int.TryParse(cellA, out int stationCode))
            {
                matching_dict_FuelPrice[stationCode] = "'" + cellC + "'";
            }
        }
    }

    /// <summary>
    /// Инициализация дефолтных акскодов стоимости ТУТ (из Книга1.xlsx)
    /// Используется как fallback, если в config.xlsx нет листа "Стоимость ТУТ"
    /// </summary>
    private static void InitializeDefaultFuelPriceCodes()
    {
        matching_dict_FuelPrice = new Dictionary<int, string>
        {
            { 14, "'00S230CT0014'" },  // Кемеровская ТЭЦ
            { 3,  "'00S200CT0003'" },  // Ново-Кемеровская ТЭЦ
            { 6,  "'00S200CT0006'" },  // Барнаульская ТЭЦ-2
            { 7,  "'00S200CT0007'" },  // Барнаульская ТЭЦ-3
            { 22, "'00S230CT0022'" },  // Бийская ТЭЦ
            { 4,  "'00S000CT0004'" },  // Красноярская ТЭЦ-1
            { 2,  "'00S000CT0002'" },  // Красноярская ТЭЦ-2
            { 12, "'00S200CT0012'" },  // Красноярская ТЭЦ-3
            { 13, "'00S200CT0013'" },  // Канская ТЭЦ
            { 8,  "'00S230CT0008'" },  // Абаканская ТЭЦ
            { 10, "'00S200CT0010'" },  // Минусинская ТЭЦ
            { 17, "'00S200CT0017'" },  // Новосибирская ТЭЦ-2
            { 18, "'00S230CT0018'" },  // Новосибирская ТЭЦ-3
            { 19, "'00S200CTG019'" },  // Новосибирская ТЭЦ-4
            { 20, "'00S700CT0020'" },  // Новосибирская ТЭЦ-5
            { 21, "'00S230CT0021'" },  // Барабинская ТЭЦ
            { 15, "'00S100CT0015'" },  // Беловская ГРЭС
            { 5,  "'00S200CT0005'" },  // Кемеровская ГРЭС
            { 24, "'00S230CT0024'" },  // Красноярская ГРЭС-2
            { 1,  "'00S100CT0001'" },  // Назаровская ГРЭС
            { 26, "'00S200CT0026'" },  // Приморская ГРЭС
            { 25, "'00S200CT0025'" },  // Рефтинская ГРЭС
            { 9,  "'00S200CT0009'" },  // Томь-Усинская ГРЭС
        };
        Console.WriteLine($"[Akscodes] Используются дефолтные акскоды стоимости ТУТ ({matching_dict_FuelPrice.Count} станций)");
    }

    /// <summary>
    /// Перезагружает данные из Excel файла
    /// </summary>
    public static void Reload()
    {
        matching_dict_KA.Clear();
        matching_dict_TA.Clear();
        matching_dict_FuelPrice.Clear();
        LoadFromExcel();
    }

    /// <summary>
    /// Возвращает путь к папке конфигурации
    /// </summary>
    public static string GetConfigPath() => _configBasePath;

    /// <summary>
    /// Получает список кодов котлов для станции
    /// </summary>
    public static List<string> GetBoilerCodes(int stationCode)
    {
        return matching_dict_KA.TryGetValue(stationCode, out var codes) ? codes : new List<string>();
    }

    /// <summary>
    /// Получает список кодов турбин для станции
    /// </summary>
    public static List<string> GetTurbineCodes(int stationCode)
    {
        return matching_dict_TA.TryGetValue(stationCode, out var codes) ? codes : new List<string>();
    }

    /// <summary>
    /// Получает акскод стоимости ТУТ для станции
    /// </summary>
    public static string? GetFuelPriceCode(int stationCode)
    {
        return matching_dict_FuelPrice.TryGetValue(stationCode, out var code) ? code : null;
    }

    /// <summary>
    /// Получает все акскоды стоимости ТУТ (станция → акскод)
    /// </summary>
    public static Dictionary<int, string> GetAllFuelPriceCodes()
    {
        return new Dictionary<int, string>(matching_dict_FuelPrice);
    }

    private static string GetCellValue(IXLWorksheet worksheet, int row, int col)
    {
        var cell = worksheet.Cell(row, col);
        if (cell == null || cell.IsEmpty())
            return "";

        var value = cell.Value;
        if (value.IsBlank)
            return "";

        return value.ToString()?.Trim() ?? "";
    }
}
}
