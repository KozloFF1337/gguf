using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;
using Npgsql;

public class DataService : IDataService
{
    private readonly IBoilerRepository _boilerRepository;
    private readonly ITurbinRepository _turbinRepository;
    private readonly IHomePageRepository _homePageRepository;
    private readonly IConfiguration _configuration;

    public DataService(IBoilerRepository boilerRepository, ITurbinRepository turbinRepository, IHomePageRepository homePageRepository, IConfiguration configuration)
    {
        _boilerRepository = boilerRepository;
        _turbinRepository = turbinRepository;
        _homePageRepository = homePageRepository;
        _configuration = configuration;
    }

    public async Task<List<Boiler>> GetBoilers(PeriodType periodType)
    {
        return await _boilerRepository.GetBoilers(periodType);
    }

    public async Task<List<Turbin>> GetTurbins(PeriodType periodType)
    {
        return await _turbinRepository.GetTurbins(periodType);
    }

    public async Task<List<Boiler>> GetBoilersByDate(PeriodType periodType, DateTime date)
    {
        return await _boilerRepository.GetBoilersByDate(periodType, date);
    }

    public async Task<List<Turbin>> GetTurbinsByDate(PeriodType periodType, DateTime date)
    {
        return await _turbinRepository.GetTurbinsByDate(periodType, date);
    }

    public async Task<List<DateTime>> GetAvailableDays()
    {
        // Берём даты из турбин (они должны совпадать с котлами)
        return await _turbinRepository.GetAvailableDates(PeriodType.Day);
    }

    public async Task<List<DateTime>> GetAvailableMonths()
    {
        return await _turbinRepository.GetAvailableDates(PeriodType.Month);
    }

    public async Task<List<int>> GetAvailableYears()
    {
        var dates = await _turbinRepository.GetAvailableDates(PeriodType.Year);
        return dates.Select(d => d.Year).Distinct().OrderByDescending(y => y).ToList();
    }

    public async Task<HomePage> GetHomePageData()
    {
        var homePages = await _homePageRepository.Get();
        return homePages?.Count > 0 ? homePages[0] : null!;
    }

    public async Task<Dictionary<int, double>> GetFuelPrices(PeriodType periodType)
    {
        string table = periodType switch
        {
            PeriodType.Day => "raw_fuel_prices",
            PeriodType.Month => "raw_fuel_prices_monthly",
            PeriodType.Year => "raw_fuel_prices_yearly",
            _ => "raw_fuel_prices"
        };
        string dateCol = periodType switch
        {
            PeriodType.Day => "date",
            PeriodType.Month => "month_date",
            PeriodType.Year => "year_date",
            _ => "date"
        };

        // Берём последнюю доступную дату и возвращаем стоимость по станциям
        string query = $@"
            SELECT stationid, price_per_tut
            FROM {table}
            WHERE {dateCol} = (SELECT MAX({dateCol}) FROM {table} WHERE price_per_tut > 0)
              AND price_per_tut > 0;";

        return await QueryFuelPrices(query);
    }

    public async Task<Dictionary<int, double>> GetFuelPricesByDate(PeriodType periodType, DateTime date)
    {
        string table = periodType switch
        {
            PeriodType.Day => "raw_fuel_prices",
            PeriodType.Month => "raw_fuel_prices_monthly",
            PeriodType.Year => "raw_fuel_prices_yearly",
            _ => "raw_fuel_prices"
        };
        string dateCol = periodType switch
        {
            PeriodType.Day => "date",
            PeriodType.Month => "month_date",
            PeriodType.Year => "year_date",
            _ => "date"
        };

        string query = $@"
            SELECT stationid, price_per_tut
            FROM {table}
            WHERE {dateCol} = @Date
              AND price_per_tut > 0;";

        return await QueryFuelPrices(query, date);
    }

    private async Task<Dictionary<int, double>> QueryFuelPrices(string query, DateTime? date = null)
    {
        var result = new Dictionary<int, double>();
        string connStr = _configuration.GetConnectionString("DefaultConnection") ?? "";

        await using var conn = new NpgsqlConnection(connStr);
        await conn.OpenAsync();
        await using var cmd = new NpgsqlCommand(query, conn);

        if (date.HasValue)
        {
            cmd.Parameters.AddWithValue("@Date", date.Value.Date);
        }

        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            int stationId = reader.GetInt16(0);
            double price = reader.GetDouble(1);
            result[stationId] = price;
        }

        return result;
    }
}
