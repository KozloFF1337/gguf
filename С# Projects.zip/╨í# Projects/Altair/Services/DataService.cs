using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;
using Npgsql;

public class DataService : IDataService
{
    private readonly IBoilerRepository _boilerRepository;
    private readonly ITurbinRepository _turbinRepository;
    private readonly IHomePageRepository _homePageRepository;
    private readonly IConfiguration _configuration;

    public DataService(IBoilerRepository boilerRepository, ITurbinRepository turbinRepository, IHomePageRepository homePageRepository, IConfiguration configuration)
    {
        _boilerRepository = boilerRepository;
        _turbinRepository = turbinRepository;
        _homePageRepository = homePageRepository;
        _configuration = configuration;
    }

    public async Task<List<Boiler>> GetBoilers(PeriodType periodType)
    {
        return await _boilerRepository.GetBoilers(periodType);
    }

    public async Task<List<Turbin>> GetTurbins(PeriodType periodType)
    {
        return await _turbinRepository.GetTurbins(periodType);
    }

    public async Task<List<Boiler>> GetBoilersByDate(PeriodType periodType, DateTime date)
    {
        return await _boilerRepository.GetBoilersByDate(periodType, date);
    }

    public async Task<List<Turbin>> GetTurbinsByDate(PeriodType periodType, DateTime date)
    {
        return await _turbinRepository.GetTurbinsByDate(periodType, date);
    }

    public async Task<List<DateTime>> GetAvailableDays()
    {
        // Берём даты из турбин (они должны совпадать с котлами)
        return await _turbinRepository.GetAvailableDates(PeriodType.Day);
    }

    public async Task<List<DateTime>> GetAvailableMonths()
    {
        return await _turbinRepository.GetAvailableDates(PeriodType.Month);
    }

    public async Task<List<int>> GetAvailableYears()
    {
        var dates = await _turbinRepository.GetAvailableDates(PeriodType.Year);
        return dates.Select(d => d.Year).Distinct().OrderByDescending(y => y).ToList();
    }

    public async Task<HomePage> GetHomePageData()
    {
        var homePages = await _homePageRepository.Get();
        return homePages?.Count > 0 ? homePages[0] : null!;
    }

    public async Task<double> GetReservesRub(PeriodType periodType)
    {
        short periodTypeValue = (short)periodType;

        // Берём последнюю доступную дату для данного типа периода и суммируем по всем станциям
        string query = @"
            SELECT COALESCE(SUM(reserves_total), 0)
            FROM reserves_rub
            WHERE period_type = @PeriodType
              AND date = (SELECT MAX(date) FROM reserves_rub WHERE period_type = @PeriodType);";

        return await QueryReservesRub(query, periodTypeValue, null);
    }

    public async Task<double> GetReservesRubByDate(PeriodType periodType, DateTime date)
    {
        short periodTypeValue = (short)periodType;

        string query = @"
            SELECT COALESCE(SUM(reserves_total), 0)
            FROM reserves_rub
            WHERE period_type = @PeriodType AND date = @Date;";

        return await QueryReservesRub(query, periodTypeValue, date);
    }

    private async Task<double> QueryReservesRub(string query, short periodType, DateTime? date)
    {
        string connStr = _configuration.GetConnectionString("DefaultConnection") ?? "";

        await using var conn = new NpgsqlConnection(connStr);
        await conn.OpenAsync();
        await using var cmd = new NpgsqlCommand(query, conn);

        cmd.Parameters.AddWithValue("@PeriodType", periodType);

        if (date.HasValue)
        {
            cmd.Parameters.AddWithValue("@Date", date.Value.Date);
        }

        var result = await cmd.ExecuteScalarAsync();
        return result != null && result != DBNull.Value ? Convert.ToDouble(result) : 0;
    }

    public async Task<(double[] Turbines, double[] Boilers, double[] Total)> GetMonthlyReservesRubByYear(int year)
    {
        var turbines = new double[12];
        var boilers = new double[12];
        var total = new double[12];

        string connStr = _configuration.GetConnectionString("DefaultConnection") ?? "";

        // Запрос месячных резервов (period_type=1) за указанный год, группируем по месяцу
        string query = @"
            SELECT
                EXTRACT(MONTH FROM date)::int as month,
                COALESCE(SUM(reserves_turbines), 0) as turbines,
                COALESCE(SUM(reserves_boilers), 0) as boilers,
                COALESCE(SUM(reserves_total), 0) as total
            FROM reserves_rub
            WHERE period_type = 1
              AND EXTRACT(YEAR FROM date) = @Year
            GROUP BY EXTRACT(MONTH FROM date)
            ORDER BY month;";

        await using var conn = new NpgsqlConnection(connStr);
        await conn.OpenAsync();
        await using var cmd = new NpgsqlCommand(query, conn);
        cmd.Parameters.AddWithValue("@Year", year);

        await using var reader = await cmd.ExecuteReaderAsync();
        while (await reader.ReadAsync())
        {
            int month = reader.GetInt32(0);
            if (month >= 1 && month <= 12)
            {
                int idx = month - 1;
                turbines[idx] = reader.GetDouble(1);
                boilers[idx] = reader.GetDouble(2);
                total[idx] = reader.GetDouble(3);
            }
        }

        return (turbines, boilers, total);
    }
}
