using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace Altair.Services
{
    /// <summary>
    /// Сервис автоматической загрузки данных за последние 30 дней каждые 12 часов (в 00:00 и 12:00)
    /// </summary>
    public class ScheduledDataLoadService : BackgroundService
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger<ScheduledDataLoadService> _logger;

        public ScheduledDataLoadService(IServiceProvider serviceProvider, ILogger<ScheduledDataLoadService> logger)
        {
            _serviceProvider = serviceProvider;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("Сервис автоматической загрузки данных запущен. Загрузка будет выполняться в 00:00 и 12:00");

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    // Вычисляем время до следующего запуска (00:00 или 12:00)
                    var now = DateTime.Now;
                    var nextRun = GetNextScheduledTime(now);
                    var delay = nextRun - now;

                    _logger.LogInformation($"Следующая автоматическая загрузка данных запланирована на {nextRun:dd.MM.yyyy HH:mm}");

                    // Ждём до следующего запланированного времени
                    await Task.Delay(delay, stoppingToken);

                    // Выполняем загрузку данных за последние 30 дней
                    await ExecuteScheduledLoad(stoppingToken);
                }
                catch (OperationCanceledException)
                {
                    // Сервис останавливается - это нормально
                    _logger.LogInformation("Сервис автоматической загрузки данных остановлен");
                    break;
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Ошибка в сервисе автоматической загрузки данных");

                    // При ошибке ждём 5 минут перед повторной попыткой
                    await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken);
                }
            }
        }

        /// <summary>
        /// Вычисляет следующее запланированное время выполнения (00:00 или 12:00)
        /// </summary>
        private DateTime GetNextScheduledTime(DateTime now)
        {
            var today = now.Date;

            // Время 00:00 и 12:00 сегодня
            var midnight = today;
            var noon = today.AddHours(12);

            // Определяем ближайшее будущее время
            if (now < midnight)
            {
                return midnight;
            }
            else if (now < noon)
            {
                return noon;
            }
            else
            {
                // Следующая полночь
                return today.AddDays(1);
            }
        }

        /// <summary>
        /// Выполняет загрузку данных за последние 30 дней
        /// </summary>
        private async Task ExecuteScheduledLoad(CancellationToken stoppingToken)
        {
            _logger.LogInformation("🕐 Начало автоматической загрузки данных за последние 30 дней");

            try
            {
                using var scope = _serviceProvider.CreateScope();
                var dbLoadService = scope.ServiceProvider.GetRequiredService<IDBLoadService>();
                var progressService = scope.ServiceProvider.GetRequiredService<IDataLoadProgressService>();

                // Проверяем, не выполняется ли уже загрузка
                if (progressService.IsLoading)
                {
                    _logger.LogWarning("Загрузка данных уже выполняется. Автоматическая загрузка пропущена.");
                    return;
                }

                var endDate = DateTime.Today;
                var startDate = endDate.AddDays(-30);

                _logger.LogInformation($"Автоматическая загрузка данных за период {startDate:dd.MM.yyyy} - {endDate:dd.MM.yyyy}");

                await dbLoadService.ExecuteLoadWithPeriodAsync(startDate, endDate);

                _logger.LogInformation("✅ Автоматическая загрузка данных завершена успешно");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "❌ Ошибка при автоматической загрузке данных");
            }
        }
    }
}
