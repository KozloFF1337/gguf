using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;

public interface IDataService
{
    Task<List<Boiler>> GetBoilers(PeriodType periodType);
    Task<List<Turbin>> GetTurbins(PeriodType periodType);
    Task<HomePage> GetHomePageData();
}
