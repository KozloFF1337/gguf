using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;

public interface IDataService
{
    Task<List<Boiler>> GetBoilers(PeriodType periodType);
    Task<List<Turbin>> GetTurbins(PeriodType periodType);
    Task<List<Boiler>> GetBoilersByDate(PeriodType periodType, DateTime date);
    Task<List<Turbin>> GetTurbinsByDate(PeriodType periodType, DateTime date);
    Task<List<DateTime>> GetAvailableDays();
    Task<List<DateTime>> GetAvailableMonths();
    Task<List<int>> GetAvailableYears();
    Task<HomePage> GetHomePageData();
    Task<double> GetReservesRub(PeriodType periodType);
    Task<double> GetReservesRubByDate(PeriodType periodType, DateTime date);
}
