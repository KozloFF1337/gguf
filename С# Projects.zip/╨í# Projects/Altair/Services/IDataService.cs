using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;

public interface IDataService
{
    Task<List<Boiler>> GetBoilers(PeriodType periodType);
    Task<List<Turbin>> GetTurbins(PeriodType periodType);
    Task<List<Boiler>> GetBoilersByDate(PeriodType periodType, DateTime date);
    Task<List<Turbin>> GetTurbinsByDate(PeriodType periodType, DateTime date);
    Task<List<DateTime>> GetAvailableDays();
    Task<List<DateTime>> GetAvailableMonths();
    Task<List<int>> GetAvailableYears();
    Task<HomePage> GetHomePageData();
    Task<double> GetReservesRub(PeriodType periodType);
    Task<double> GetReservesRubByDate(PeriodType periodType, DateTime date);

    /// <summary>
    /// Получает месячные резервы в рублях за указанный год (12 значений, по месяцам).
    /// Возвращает (turbines[12], boilers[12], total[12])
    /// </summary>
    Task<(double[] Turbines, double[] Boilers, double[] Total)> GetMonthlyReservesRubByYear(int year);
}
