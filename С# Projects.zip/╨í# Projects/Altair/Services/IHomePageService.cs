using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;

namespace Altair.Services
{
    public interface IHomePageService
    {
        Task<List<HomePage>> GetHomePages();
    }
}
