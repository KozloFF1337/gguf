using ClosedXML.Excel;
using Altair.Models;

namespace Altair.Services
{
    public interface ITechParamsService
    {
        TechParamsData GetData();
        void SaveData(Stream fileStream);
        byte[] GetFileBytes();
        bool FileExists();
        DateTime? GetLastModified();
    }

    public class TechParamsService : ITechParamsService
    {
        private readonly string _filePath;
        private readonly string _dataDirectory;
        private const string FileName = "tech_params.xlsm";

        public TechParamsService(IWebHostEnvironment env)
        {
            _dataDirectory = Path.Combine(env.ContentRootPath, "Data");
            _filePath = Path.Combine(_dataDirectory, FileName);

            // Создаем директорию если её нет
            if (!Directory.Exists(_dataDirectory))
            {
                Directory.CreateDirectory(_dataDirectory);
            }
        }

        public bool FileExists()
        {
            return File.Exists(_filePath);
        }

        public DateTime? GetLastModified()
        {
            if (!FileExists()) return null;
            return File.GetLastWriteTime(_filePath);
        }

        public TechParamsData GetData()
        {
            var data = new TechParamsData();

            if (!FileExists())
            {
                return data;
            }

            try
            {
                using var workbook = new XLWorkbook(_filePath);
                var worksheet = workbook.Worksheet("Свод");

                if (worksheet == null)
                {
                    return data;
                }

                // Читаем ГРЭС (левая таблица: колонки A-G, строки 2+)
                data.GresRecords = ReadTable(worksheet, 1, 2, 3, 4, 5, 6, 7);

                // Читаем ТЭЦ (правая таблица: колонки J-P, строки 2+)
                data.TecRecords = ReadTable(worksheet, 10, 11, 12, 13, 14, 15, 16);

                data.LastUpdated = GetLastModified();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading tech params file: {ex.Message}");
            }

            return data;
        }

        private List<TechParamsRecord> ReadTable(IXLWorksheet worksheet,
            int colNum, int colStation, int colEquip, int colActual, int colNorm, int colDate, int colDays)
        {
            var records = new List<TechParamsRecord>();
            int row = 2; // Начинаем со второй строки (первая - заголовок)

            while (true)
            {
                var numCell = worksheet.Cell(row, colNum);
                var stationCell = worksheet.Cell(row, colStation);

                // Если номер или станция пустые - конец таблицы
                if (numCell.IsEmpty() && stationCell.IsEmpty())
                {
                    break;
                }

                // Читаем данные
                var record = new TechParamsRecord
                {
                    RowNumber = GetIntValue(numCell) ?? row - 1,
                    StationName = GetStringValue(worksheet.Cell(row, colStation)),
                    EquipmentParameter = GetStringValue(worksheet.Cell(row, colEquip)),
                    ActualValue = GetDoubleValue(worksheet.Cell(row, colActual)),
                    NormValue = GetDoubleValue(worksheet.Cell(row, colNorm)),
                    DeviationStartDate = GetDateOrStringValue(worksheet.Cell(row, colDate)),
                    DaysCount = GetStringValue(worksheet.Cell(row, colDays))
                };

                // Добавляем только если есть хоть какие-то данные
                if (!string.IsNullOrWhiteSpace(record.StationName) ||
                    !string.IsNullOrWhiteSpace(record.EquipmentParameter))
                {
                    records.Add(record);
                }

                row++;

                // Защита от бесконечного цикла
                if (row > 1000) break;
            }

            return records;
        }

        private string GetStringValue(IXLCell cell)
        {
            if (cell.IsEmpty()) return string.Empty;
            return cell.GetString().Trim();
        }

        private int? GetIntValue(IXLCell cell)
        {
            if (cell.IsEmpty()) return null;
            if (cell.DataType == XLDataType.Number)
            {
                return (int)cell.GetDouble();
            }
            if (int.TryParse(cell.GetString(), out int result))
            {
                return result;
            }
            return null;
        }

        private double? GetDoubleValue(IXLCell cell)
        {
            if (cell.IsEmpty()) return null;
            if (cell.DataType == XLDataType.Number)
            {
                return cell.GetDouble();
            }
            if (double.TryParse(cell.GetString().Replace(",", "."),
                System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture,
                out double result))
            {
                return result;
            }
            return null;
        }

        private string GetDateOrStringValue(IXLCell cell)
        {
            if (cell.IsEmpty()) return string.Empty;

            if (cell.DataType == XLDataType.DateTime)
            {
                return cell.GetDateTime().ToString("dd.MM.yyyy");
            }

            return cell.GetString().Trim();
        }

        public void SaveData(Stream fileStream)
        {
            using var memoryStream = new MemoryStream();
            fileStream.CopyTo(memoryStream);
            File.WriteAllBytes(_filePath, memoryStream.ToArray());
        }

        public byte[] GetFileBytes()
        {
            if (!FileExists())
            {
                throw new FileNotFoundException("Tech params file not found");
            }
            return File.ReadAllBytes(_filePath);
        }
    }
}
