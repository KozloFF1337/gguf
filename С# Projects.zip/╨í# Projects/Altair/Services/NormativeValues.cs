using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using ClosedXML.Excel;

namespace Altair.Services
{
    /// <summary>
    /// Статический класс для хранения нормативных значений КПД котлов и УРТ турбин.
    /// Данные загружаются из Excel файла config/normative_config.xlsx
    /// </summary>
    public static class NormativeValues
    {
        // Словари для хранения нормативных значений КПД котлов по станциям
        // Ключ внешнего словаря - ID станции, ключ внутреннего - код котла, значение - норматив КПД
        public static Dictionary<int, Dictionary<string, double>> KpdValues { get; private set; } = new Dictionary<int, Dictionary<string, double>>();

        // Словари для хранения нормативных значений УРТ турбин по станциям
        // Ключ внешнего словаря - ID станции, ключ внутреннего - код турбины, значение - норматив УРТ
        public static Dictionary<int, Dictionary<string, double>> UrtValues { get; private set; } = new Dictionary<int, Dictionary<string, double>>();

        // Базовый путь к папке Services/config (устанавливается при инициализации)
        private static string _configBasePath = "";

        /// <summary>
        /// Инициализирует базовый путь для конфигурационных файлов
        /// </summary>
        public static void Initialize(string contentRootPath)
        {
            _configBasePath = Path.Combine(contentRootPath, "Services", "config");
            CreateTemplateIfNotExists();
            LoadFromExcel();
        }

        // Статический конструктор - пустой, загрузка происходит через Initialize
        static NormativeValues()
        {
            // Загрузка происходит через Initialize()
        }

        /// <summary>
        /// Загружает данные из Excel файла config/normative_config.xlsx
        /// </summary>
        private static void LoadFromExcel()
        {
            // Если путь не инициализирован, пробуем определить автоматически
            if (string.IsNullOrEmpty(_configBasePath))
            {
                string currentDir = Directory.GetCurrentDirectory();
                _configBasePath = Path.Combine(currentDir, "Services", "config");
            }

            string configPath = Path.Combine(_configBasePath, "normative_config.xlsx");

            if (!File.Exists(configPath))
            {
                Console.WriteLine($"[NormativeValues] Файл конфигурации не найден: {configPath}");
                return;
            }

            try
            {
                using (var workbook = new XLWorkbook(configPath))
                {
                    foreach (var worksheet in workbook.Worksheets)
                    {
                        // Пропускаем лист инструкции
                        if (worksheet.Name == "Инструкция")
                            continue;

                        // Извлекаем код станции из названия листа (первые 2 символа)
                        string sheetName = worksheet.Name;
                        if (sheetName.Length < 2)
                            continue;

                        if (!int.TryParse(sheetName.Substring(0, 2), out int stationCode))
                            continue;

                        // Парсим данные листа
                        var kpdDict = new Dictionary<string, double>();
                        var urtDict = new Dictionary<string, double>();

                        bool inKpd = false;
                        bool inUrt = false;
                        int headerRow = 0;

                        int lastRow = worksheet.LastRowUsed()?.RowNumber() ?? 0;

                        for (int row = 1; row <= lastRow; row++)
                        {
                            string cellA = GetCellValue(worksheet, row, 1);

                            if (cellA == "КПД_КОТЛЫ" || cellA == "КПД КОТЛЫ" || cellA == "КОТЛЫ_КПД")
                            {
                                inKpd = true;
                                inUrt = false;
                                headerRow = row + 1;
                                continue;
                            }

                            if (cellA == "УРТ_ТУРБИНЫ" || cellA == "УРТ ТУРБИНЫ" || cellA == "ТУРБИНЫ_УРТ")
                            {
                                inKpd = false;
                                inUrt = true;
                                headerRow = row + 1;
                                continue;
                            }

                            // Пропускаем заголовки и пустые строки
                            if (row == headerRow || string.IsNullOrWhiteSpace(cellA))
                                continue;

                            // Читаем код оборудования (колонка A) и значение (колонка B)
                            string code = cellA.Trim();
                            string valueStr = GetCellValue(worksheet, row, 2);

                            if (string.IsNullOrWhiteSpace(code) || string.IsNullOrWhiteSpace(valueStr))
                                continue;

                            // Пытаемся парсить значение
                            if (double.TryParse(valueStr.Replace(',', '.'), System.Globalization.NumberStyles.Any,
                                System.Globalization.CultureInfo.InvariantCulture, out double value))
                            {
                                if (inKpd)
                                {
                                    kpdDict[code] = value;
                                }
                                else if (inUrt)
                                {
                                    urtDict[code] = value;
                                }
                            }
                        }

                        // Добавляем данные в словари
                        if (kpdDict.Count > 0)
                        {
                            KpdValues[stationCode] = kpdDict;
                        }

                        if (urtDict.Count > 0)
                        {
                            UrtValues[stationCode] = urtDict;
                        }
                    }
                }

                Console.WriteLine($"[NormativeValues] Загружено станций КПД: {KpdValues.Count}, УРТ: {UrtValues.Count}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[NormativeValues] Ошибка загрузки конфигурации: {ex.Message}");
            }
        }

        /// <summary>
        /// Перезагружает данные из Excel файла
        /// </summary>
        public static void Reload()
        {
            KpdValues.Clear();
            UrtValues.Clear();
            LoadFromExcel();
        }

        /// <summary>
        /// Возвращает путь к папке конфигурации
        /// </summary>
        public static string GetConfigPath() => _configBasePath;

        /// <summary>
        /// Получает нормативное значение КПД для котла
        /// </summary>
        public static double? GetKpdValue(int stationCode, string boilerCode)
        {
            if (KpdValues.TryGetValue(stationCode, out var stationDict))
            {
                if (stationDict.TryGetValue(boilerCode, out double value))
                {
                    return value;
                }
            }
            return null;
        }

        /// <summary>
        /// Получает нормативное значение УРТ для турбины
        /// </summary>
        public static double? GetUrtValue(int stationCode, string turbineCode)
        {
            if (UrtValues.TryGetValue(stationCode, out var stationDict))
            {
                if (stationDict.TryGetValue(turbineCode, out double value))
                {
                    return value;
                }
            }
            return null;
        }

        /// <summary>
        /// Получает словарь всех КПД для станции
        /// </summary>
        public static Dictionary<string, double> GetKpdValuesForStation(int stationCode)
        {
            return KpdValues.TryGetValue(stationCode, out var dict) ? dict : new Dictionary<string, double>();
        }

        /// <summary>
        /// Получает словарь всех УРТ для станции
        /// </summary>
        public static Dictionary<string, double> GetUrtValuesForStation(int stationCode)
        {
            return UrtValues.TryGetValue(stationCode, out var dict) ? dict : new Dictionary<string, double>();
        }

        /// <summary>
        /// Сериализует все значения КПД в JSON-подобный формат для JavaScript
        /// </summary>
        public static string GetKpdValuesAsJson()
        {
            var result = new System.Text.StringBuilder();
            result.Append("{");

            bool firstStation = true;
            foreach (var station in KpdValues)
            {
                if (!firstStation) result.Append(",");
                firstStation = false;

                result.Append($"\n            {station.Key}: {{");

                bool firstValue = true;
                foreach (var kv in station.Value)
                {
                    if (!firstValue) result.Append(",");
                    firstValue = false;
                    result.Append($"\n                \"{kv.Key}\": {kv.Value.ToString(System.Globalization.CultureInfo.InvariantCulture)}");
                }
                result.Append("\n            }");
            }

            result.Append("\n        }");
            return result.ToString();
        }

        /// <summary>
        /// Сериализует все значения УРТ в JSON-подобный формат для JavaScript
        /// </summary>
        public static string GetUrtValuesAsJson()
        {
            var result = new System.Text.StringBuilder();
            result.Append("{");

            bool firstStation = true;
            foreach (var station in UrtValues)
            {
                if (!firstStation) result.Append(",");
                firstStation = false;

                result.Append($"\n            {station.Key}: {{");

                bool firstValue = true;
                foreach (var kv in station.Value)
                {
                    if (!firstValue) result.Append(",");
                    firstValue = false;
                    result.Append($"\n                \"{kv.Key}\": {kv.Value.ToString(System.Globalization.CultureInfo.InvariantCulture)}");
                }
                result.Append("\n            }");
            }

            result.Append("\n        }");
            return result.ToString();
        }

        private static string GetCellValue(IXLWorksheet worksheet, int row, int col)
        {
            var cell = worksheet.Cell(row, col);
            if (cell == null || cell.IsEmpty())
                return "";

            var value = cell.Value;
            if (value.IsBlank)
                return "";

            return value.ToString()?.Trim() ?? "";
        }

        /// <summary>
        /// Создает шаблон Excel файла с нормативными значениями, если файл не существует
        /// </summary>
        public static void CreateTemplateIfNotExists()
        {
            // Если путь не инициализирован, пробуем определить автоматически
            if (string.IsNullOrEmpty(_configBasePath))
            {
                string currentDir = Directory.GetCurrentDirectory();
                _configBasePath = Path.Combine(currentDir, "Services", "config");
            }

            string configDir = _configBasePath;
            string configPath = Path.Combine(configDir, "normative_config.xlsx");

            if (File.Exists(configPath))
                return;

            // Создаем директорию если не существует
            if (!Directory.Exists(configDir))
                Directory.CreateDirectory(configDir);

            // Начальные данные КПД по станциям
            var initialKpdData = new Dictionary<int, Dictionary<string, double>>
            {
                [25] = new Dictionary<string, double> { // РефГРЭС
                    ["01А"] = 90.28, ["01Б"] = 89.9, ["02А"] = 91.41, ["02Б"] = 91.29,
                    ["03А"] = 92.14, ["03Б"] = 92.12, ["04А"] = 91.56, ["04Б"] = 91.58,
                    ["05А"] = 91.37, ["05Б"] = 91.28, ["06А"] = 91.73, ["06Б"] = 91.22,
                    ["07"] = 90.08, ["08"] = 90.67, ["09"] = 90.61, ["10"] = 90.42
                },
                [9] = new Dictionary<string, double> { // ТуГРЭС
                    ["01"] = 90.86, ["02"] = 90.93, ["03"] = 90.94, ["04"] = 91.1, ["05"] = 91.03,
                    ["06"] = 91.04, ["07"] = 91.27, ["08"] = 89.96, ["09"] = 91.13,
                    ["10А"] = 89.99, ["10Б"] = 89.48, ["11А"] = 90.33, ["11Б"] = 89.8,
                    ["12А"] = 89.5, ["12Б"] = 89.62, ["13А"] = 89.34, ["13Б"] = 90.03,
                    ["14А"] = 89.32, ["14Б"] = 90.77
                },
                [15] = new Dictionary<string, double> { // БелГРЭС
                    ["01А"] = 90.6, ["01Б"] = 90.15, ["02А"] = 90.26, ["02Б"] = 90.55,
                    ["03А"] = 89.86, ["03Б"] = 89.96, ["04А"] = 90.14, ["04Б"] = 89.43,
                    ["05А"] = 89.53, ["05Б"] = 90.09, ["06А"] = 89.45, ["06Б"] = 89.03
                },
                [1] = new Dictionary<string, double> { // НазГРЭС
                    ["01А"] = 91.73, ["01Б"] = 89.06, ["02А"] = 87.93, ["02Б"] = 90.16,
                    ["03А"] = 90.22, ["03Б"] = 90.96, ["04А"] = 90.78, ["04Б"] = 90.18,
                    ["05А"] = 89.01, ["05Б"] = 88.54, ["06А"] = 88.47, ["06Б"] = 88.82,
                    ["07А"] = 87.92, ["07Б"] = 88.93
                },
                [24] = new Dictionary<string, double> { // КрГРЭС-2
                    ["01А"] = 91.42, ["01Б"] = 91.77, ["02А"] = 91.58, ["02Б"] = 91.72,
                    ["03А"] = 92.02, ["03Б"] = 91.62, ["04А"] = 91.11, ["04Б"] = 91.91,
                    ["05А"] = 91.91, ["05Б"] = 91.75, ["06А"] = 91.98, ["06Б"] = 91.77,
                    ["07А"] = 91.32, ["07Б"] = 91.82, ["08А"] = 91.84, ["08Б"] = 91.29,
                    ["09А"] = 91.47, ["09Б"] = 91.22, ["10А"] = 90.38, ["10Б"] = 88.83
                },
                [26] = new Dictionary<string, double> { // ПрГРЭС
                    ["01А"] = 84.35, ["01Б"] = 83.62, ["02А"] = 83.62, ["02Б"] = 83.35,
                    ["03А"] = 83.1, ["03Б"] = 82.26, ["04А"] = 85.27, ["04Б"] = 85.2,
                    ["05А"] = 83.62, ["05Б"] = 83.62, ["06"] = 85.97, ["07"] = 85.9,
                    ["08"] = 78.4, ["09"] = 83.62
                },
                [2] = new Dictionary<string, double> { // КрТЭЦ-2
                    ["01"] = 91.85, ["02"] = 92.69, ["03"] = 91.6, ["04"] = 90.84,
                    ["05"] = 91.13, ["06"] = 90.86
                },
                [3] = new Dictionary<string, double> { // НкТЭЦ
                    ["08"] = 91.09, ["09"] = 90.96, ["10"] = 90.7, ["11"] = 90.7,
                    ["12"] = 90.65, ["13"] = 91.26, ["14"] = 89.88, ["15"] = 90.4, ["16"] = 91.37
                },
                [4] = new Dictionary<string, double> { // КрТЭЦ-1
                    ["04"] = 89.08, ["05"] = 90.41, ["06"] = 88.42, ["07"] = 89.34,
                    ["08"] = 89.68, ["09"] = 89.77, ["10"] = 90.09, ["13"] = 89.93,
                    ["14"] = 89.84, ["15"] = 90.59, ["16"] = 90.05, ["18"] = 90.83
                },
                [6] = new Dictionary<string, double> { // БарТЭЦ-2
                    ["06"] = 91.49, ["07"] = 91.44, ["10"] = 91.45, ["11"] = 91.37,
                    ["12"] = 91.14, ["14"] = 91.26, ["15"] = 91.53, ["16"] = 91.15,
                    ["17"] = 91.58, ["18"] = 90.55
                },
                [7] = new Dictionary<string, double> { // БарТЭЦ-3
                    ["01"] = 91.65, ["02"] = 92.08, ["03"] = 91.87, ["04"] = 92.02, ["05"] = 91.55
                },
                [8] = new Dictionary<string, double> { // АбТЭЦ
                    ["01"] = 90.25, ["02"] = 91.9, ["03"] = 91.55, ["04"] = 92.61, ["05"] = 90.86
                },
                [10] = new Dictionary<string, double> { // МинТЭЦ
                    ["01"] = 91.46, ["02"] = 91.92
                },
                [12] = new Dictionary<string, double> { // КрТЭЦ-3
                    ["01"] = 91.03, ["02"] = 92.22
                },
                [13] = new Dictionary<string, double> { // КанТЭЦ
                    ["02"] = 93.26, ["03"] = 93.47, ["04"] = 92.74, ["05"] = 92.82,
                    ["06"] = 92.82, ["07"] = 93.16
                },
                [14] = new Dictionary<string, double> { // КемТЭЦ
                    ["01"] = 86.61, ["05"] = 87.3, ["08"] = 87.43, ["09"] = 90.8,
                    ["10"] = 90.76, ["11"] = 90.68
                },
                [17] = new Dictionary<string, double> { // НТЭЦ-2
                    ["04"] = 87.35, ["05"] = 88.93, ["06"] = 89.54, ["07"] = 89.54,
                    ["08"] = 90.01, ["09"] = 91.34, ["10"] = 92.21
                },
                [18] = new Dictionary<string, double> { // НТЭЦ-3
                    ["07"] = 89.53, ["08"] = 89.18, ["09"] = 90.97, ["10"] = 91.06,
                    ["11"] = 91.22, ["12"] = 90.67, ["13"] = 90.7, ["14"] = 91.43
                },
                [19] = new Dictionary<string, double> { // НТЭЦ-4
                    ["05"] = 88.65, ["06"] = 90.81, ["07"] = 91.71, ["08"] = 92.12,
                    ["09"] = 90.57, ["10"] = 89.06, ["11"] = 89.92, ["12"] = 89.77
                },
                [20] = new Dictionary<string, double> { // НТЭЦ-5
                    ["01"] = 90.81, ["02"] = 91.04, ["03"] = 90.66, ["04"] = 91.41,
                    ["05"] = 90.62, ["06"] = 90.21
                },
                [21] = new Dictionary<string, double> { // БбТЭЦ
                    ["01М"] = 90.13, ["02М"] = 91.73, ["03М"] = 92.23, ["04М"] = 90.17, ["05М"] = 89.84
                },
                [22] = new Dictionary<string, double> { // БиТЭЦ
                    ["07М"] = 92.2, ["10М"] = 91.76, ["11М"] = 90.9, ["12М"] = 91.5,
                    ["13М"] = 91.05, ["14М"] = 91.06, ["15М"] = 91.42, ["16М"] = 90.91
                },
                [5] = new Dictionary<string, double> { // КемГРЭС
                    ["03"] = 87.27, ["04"] = 88.08, ["10"] = 91.5, ["11"] = 91.85,
                    ["12"] = 91.69, ["13"] = 92.55, ["14"] = 91.87
                }
            };

            // Начальные данные УРТ по станциям
            var initialUrtData = new Dictionary<int, Dictionary<string, double>>
            {
                [25] = new Dictionary<string, double> { // РефГРЭС
                    ["1"] = 1930.4, ["2"] = 2006.3, ["3"] = 1966.9, ["4"] = 1977.7,
                    ["5"] = 1996.5, ["6"] = 1996.9, ["7"] = 1981.7, ["8"] = 1939.0,
                    ["9"] = 1932.2, ["10"] = 1925.7
                },
                [9] = new Dictionary<string, double> { // ТуГРЭС
                    ["1"] = 2476, ["2"] = 2295, ["3"] = 2282, ["4"] = 2192, ["5"] = 2246,
                    ["6"] = 2242, ["7"] = 2135, ["8"] = 2148, ["9"] = 2081
                },
                [15] = new Dictionary<string, double> { // БелГРЭС
                    ["1"] = 2004, ["2"] = 2060, ["3"] = 2048, ["4"] = 2106, ["5"] = 2102, ["6"] = 1953
                },
                [1] = new Dictionary<string, double> { // НазГРЭС
                    ["1"] = 2360.8, ["2"] = 2176.66, ["3"] = 2261.85, ["4"] = 2271.02,
                    ["5"] = 2173.04, ["6"] = 2280.1, ["7"] = 1934
                },
                [24] = new Dictionary<string, double> { // КрГРЭС-2
                    ["1"] = 2198.3, ["2"] = 2228.8, ["3"] = 2228.8, ["4"] = 2173.7,
                    ["5"] = 2173.7, ["6"] = 2215.7, ["7"] = 2215.7, ["8"] = 2416.9,
                    ["9"] = 2423.6, ["10"] = 2423.6
                },
                [26] = new Dictionary<string, double> { // ПрГРЭС
                    ["1"] = 2252.83, ["2"] = 2252.83, ["3"] = 2252.83, ["4"] = 2252.83,
                    ["5"] = 2234.42, ["6"] = 2245.46, ["7"] = 2227.39, ["8"] = 2252.83,
                    ["9"] = 2252.83, ["10"] = 2262.18, ["11"] = 2278.25
                },
                [2] = new Dictionary<string, double> { // КрТЭЦ-2
                    ["1"] = 1994.7, ["2"] = 1261.1, ["3"] = 1208.2, ["4"] = 1157.3
                },
                [3] = new Dictionary<string, double> { // НкТЭЦ
                    ["7"] = 900.0, ["9"] = 884.4, ["11"] = 2017.0, ["12"] = 1839.0,
                    ["13"] = 1899.0, ["14"] = 1884.0, ["15"] = 1813.0
                },
                [4] = new Dictionary<string, double> { // КрТЭЦ-1
                    ["3"] = 2963.7, ["4"] = 2963.7, ["5"] = 2963.7, ["6"] = 2963.7,
                    ["7"] = 2963.7, ["8"] = 1049.9, ["9"] = 1047.9, ["10"] = 1044.7,
                    ["11"] = 1041.0, ["12"] = 1041.0
                },
                [6] = new Dictionary<string, double> { // БарТЭЦ-2
                    ["5"] = 1025.0, ["6"] = 986.0, ["7"] = 1031.0, ["8"] = 1031.0, ["9"] = 1115.0
                },
                [7] = new Dictionary<string, double> { // БарТЭЦ-3
                    ["1"] = 1195.0, ["2"] = 1070.0, ["3"] = 1147.0
                },
                [8] = new Dictionary<string, double> { // АбТЭЦ
                    ["1"] = 2366.9, ["2"] = 2230.5, ["3"] = 2227.8, ["4"] = 2220.9
                },
                [10] = new Dictionary<string, double> { // МинТЭЦ
                    ["1"] = 2214.4
                },
                [12] = new Dictionary<string, double> { // КрТЭЦ-3
                },
                [13] = new Dictionary<string, double> { // КанТЭЦ
                    ["1"] = 3565.2, ["2"] = 969.3
                },
                [14] = new Dictionary<string, double> { // КемТЭЦ
                    ["2"] = 1034.0, ["3"] = 1007.0, ["4"] = 956.0, ["5"] = 906.0
                },
                [17] = new Dictionary<string, double> { // НТЭЦ-2
                    ["3"] = 3201.9, ["4"] = 3201.9, ["5"] = 3740.3, ["6"] = 3740.3,
                    ["7"] = 1060.3, ["8"] = 1038.0, ["9"] = 1002.0
                },
                [18] = new Dictionary<string, double> { // НТЭЦ-3
                    ["1"] = 3245.5, ["7"] = 1043.0, ["9"] = 854.2, ["10"] = 863.9,
                    ["11"] = 882.5, ["12"] = 884.7, ["13"] = 876.9
                },
                [19] = new Dictionary<string, double> { // НТЭЦ-4
                    ["4"] = 3159.9, ["5"] = 3273.9, ["6"] = 2235.5, ["7"] = 2207.9, ["8"] = 2221.0
                },
                [20] = new Dictionary<string, double> { // НТЭЦ-5
                    ["1"] = 2115.7, ["2"] = 2089.4, ["3"] = 2145.3, ["4"] = 2145.3,
                    ["5"] = 2093.6, ["6"] = 2160.2
                },
                [21] = new Dictionary<string, double> { // БбТЭЦ
                    ["2"] = 3290.0, ["3"] = 1387.0, ["4"] = 1387.0, ["5"] = 1387.0
                },
                [22] = new Dictionary<string, double> { // БиТЭЦ
                    ["1"] = 989.1, ["4"] = 1602.7, ["6"] = 1702.4, ["7"] = 1710.1
                },
                [5] = new Dictionary<string, double> { // КемГРЭС
                    ["3"] = 899, ["5"] = 910, ["6"] = 1451, ["7"] = 1451, ["8"] = 1451
                }
            };

            // Названия станций
            var stationNames = new Dictionary<int, string>
            {
                [25] = "РефГРЭС", [9] = "ТуГРЭС", [15] = "БелГРЭС", [1] = "НазГРЭС",
                [24] = "КрГРЭС-2", [26] = "ПрГРЭС", [2] = "КрТЭЦ-2", [3] = "НкТЭЦ",
                [4] = "КрТЭЦ-1", [6] = "БарТЭЦ-2", [7] = "БарТЭЦ-3", [8] = "АбТЭЦ",
                [10] = "МинТЭЦ", [12] = "КрТЭЦ-3", [13] = "КанТЭЦ", [14] = "КемТЭЦ",
                [17] = "НТЭЦ-2", [18] = "НТЭЦ-3", [19] = "НТЭЦ-4", [20] = "НТЭЦ-5",
                [21] = "БбТЭЦ", [22] = "БиТЭЦ", [5] = "КемГРЭС"
            };

            try
            {
                using (var workbook = new XLWorkbook())
                {
                    // Создаем лист инструкции
                    var instructionSheet = workbook.AddWorksheet("Инструкция");
                    instructionSheet.Cell(1, 1).Value = "ИНСТРУКЦИЯ ПО ЗАПОЛНЕНИЮ НОРМАТИВНЫХ ЗНАЧЕНИЙ";
                    instructionSheet.Cell(3, 1).Value = "Структура листов:";
                    instructionSheet.Cell(4, 1).Value = "- Каждый лист соответствует станции (код + название)";
                    instructionSheet.Cell(5, 1).Value = "- На каждом листе два раздела: КПД_КОТЛЫ и УРТ_ТУРБИНЫ";
                    instructionSheet.Cell(7, 1).Value = "Формат данных:";
                    instructionSheet.Cell(8, 1).Value = "- Колонка A: код оборудования (котла или турбины)";
                    instructionSheet.Cell(9, 1).Value = "- Колонка B: нормативное значение";
                    instructionSheet.Cell(11, 1).Value = "ВАЖНО: Не изменяйте структуру листов и заголовки разделов!";

                    // Создаем листы для каждой станции
                    foreach (var station in stationNames)
                    {
                        string sheetName = $"{station.Key:D2} {station.Value}";
                        var sheet = workbook.AddWorksheet(sheetName);

                        int row = 1;

                        // Заголовок КПД
                        sheet.Cell(row, 1).Value = "КПД_КОТЛЫ";
                        sheet.Cell(row, 1).Style.Font.Bold = true;
                        sheet.Cell(row, 1).Style.Fill.BackgroundColor = XLColor.LightGray;
                        row++;

                        sheet.Cell(row, 1).Value = "Код котла";
                        sheet.Cell(row, 2).Value = "КПД норматив, %";
                        sheet.Cell(row, 1).Style.Font.Bold = true;
                        sheet.Cell(row, 2).Style.Font.Bold = true;
                        row++;

                        // Данные КПД
                        if (initialKpdData.TryGetValue(station.Key, out var kpdData))
                        {
                            foreach (var kv in kpdData)
                            {
                                sheet.Cell(row, 1).Value = kv.Key;
                                sheet.Cell(row, 2).Value = kv.Value;
                                row++;
                            }
                        }

                        row += 2; // Пустая строка

                        // Заголовок УРТ
                        sheet.Cell(row, 1).Value = "УРТ_ТУРБИНЫ";
                        sheet.Cell(row, 1).Style.Font.Bold = true;
                        sheet.Cell(row, 1).Style.Fill.BackgroundColor = XLColor.LightGray;
                        row++;

                        sheet.Cell(row, 1).Value = "Код турбины";
                        sheet.Cell(row, 2).Value = "УРТ норматив, г/кВт*ч";
                        sheet.Cell(row, 1).Style.Font.Bold = true;
                        sheet.Cell(row, 2).Style.Font.Bold = true;
                        row++;

                        // Данные УРТ
                        if (initialUrtData.TryGetValue(station.Key, out var urtData))
                        {
                            foreach (var kv in urtData)
                            {
                                sheet.Cell(row, 1).Value = kv.Key;
                                sheet.Cell(row, 2).Value = kv.Value;
                                row++;
                            }
                        }

                        // Автоширина колонок
                        sheet.Column(1).AdjustToContents();
                        sheet.Column(2).AdjustToContents();
                    }

                    workbook.SaveAs(configPath);
                    Console.WriteLine($"[NormativeValues] Создан шаблон конфигурации: {configPath}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[NormativeValues] Ошибка создания шаблона: {ex.Message}");
            }
        }
    }
}
