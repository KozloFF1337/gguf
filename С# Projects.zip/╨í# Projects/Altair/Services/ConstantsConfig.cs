using System;
using System.Collections.Generic;
using System.IO;
using ClosedXML.Excel;

namespace Altair.Services
{
    /// <summary>
    /// Статический класс для хранения константных значений temp_nominal и temp_koef котлов.
    /// Используются как резервные значения когда АСТЭП не передаёт данные по этим параметрам.
    /// Данные загружаются из Excel файла config/constants_config.xlsx
    /// </summary>
    public static class ConstantsConfig
    {
        // Словарь: stationID → (boilerCode → (TempNominal, TempKoef))
        public static Dictionary<int, Dictionary<string, (double TempNominal, double TempKoef)>> Values { get; private set; }
            = new Dictionary<int, Dictionary<string, (double TempNominal, double TempKoef)>>();

        private static string _configBasePath = "";

        /// <summary>
        /// Инициализирует сервис и загружает данные из Excel
        /// </summary>
        public static void Initialize(string contentRootPath)
        {
            _configBasePath = Path.Combine(contentRootPath, "Services", "config");
            LoadFromExcel();
        }

        static ConstantsConfig() { }

        /// <summary>
        /// Загружает данные из constants_config.xlsx
        /// </summary>
        private static void LoadFromExcel()
        {
            if (string.IsNullOrEmpty(_configBasePath))
            {
                _configBasePath = Path.Combine(Directory.GetCurrentDirectory(), "Services", "config");
            }

            string configPath = Path.Combine(_configBasePath, "constants_config.xlsx");

            if (!File.Exists(configPath))
            {
                Console.WriteLine($"[ConstantsConfig] Файл констант не найден: {configPath}");
                return;
            }

            try
            {
                var newValues = new Dictionary<int, Dictionary<string, (double TempNominal, double TempKoef)>>();

                using (var workbook = new XLWorkbook(configPath))
                {
                    foreach (var worksheet in workbook.Worksheets)
                    {
                        if (worksheet.Name == "Инструкция")
                            continue;

                        string sheetName = worksheet.Name;
                        if (sheetName.Length < 2)
                            continue;

                        if (!int.TryParse(sheetName.Substring(0, 2), out int stationCode))
                            continue;

                        var boilerDict = new Dictionary<string, (double TempNominal, double TempKoef)>();
                        bool inSection = false;
                        int headerRow = 0;
                        int lastRow = worksheet.LastRowUsed()?.RowNumber() ?? 0;

                        for (int row = 1; row <= lastRow; row++)
                        {
                            string cellA = GetCellValue(worksheet, row, 1);

                            if (cellA == "КОНСТАНТЫ_КОТЛЫ")
                            {
                                inSection = true;
                                headerRow = row + 1;
                                continue;
                            }

                            if (!inSection || row == headerRow || string.IsNullOrWhiteSpace(cellA))
                                continue;

                            string code = cellA.Trim();
                            string tempNomStr = GetCellValue(worksheet, row, 2);
                            string tempKoefStr = GetCellValue(worksheet, row, 3);

                            double tempNom = 0, tempKoef = 0;

                            if (!string.IsNullOrWhiteSpace(tempNomStr))
                                double.TryParse(tempNomStr.Replace(',', '.'),
                                    System.Globalization.NumberStyles.Any,
                                    System.Globalization.CultureInfo.InvariantCulture,
                                    out tempNom);

                            if (!string.IsNullOrWhiteSpace(tempKoefStr))
                                double.TryParse(tempKoefStr.Replace(',', '.'),
                                    System.Globalization.NumberStyles.Any,
                                    System.Globalization.CultureInfo.InvariantCulture,
                                    out tempKoef);

                            if (tempNom != 0 || tempKoef != 0)
                            {
                                boilerDict[code] = (tempNom, tempKoef);
                            }
                        }

                        if (boilerDict.Count > 0)
                            newValues[stationCode] = boilerDict;
                    }
                }

                Values = newValues;
                Console.WriteLine($"[ConstantsConfig] Загружено станций: {Values.Count}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ConstantsConfig] Ошибка загрузки: {ex.Message}");
            }
        }

        /// <summary>
        /// Перезагружает данные из Excel файла
        /// </summary>
        public static void Reload()
        {
            Values.Clear();
            LoadFromExcel();
        }

        /// <summary>
        /// Возвращает путь к папке конфигурации
        /// </summary>
        public static string GetConfigPath() => _configBasePath;

        /// <summary>
        /// Получает константные значения для котла.
        /// Возвращает null если константы не найдены.
        /// Проверяет как точный код, так и код без суффикса А/Б.
        /// </summary>
        public static (double TempNominal, double TempKoef)? GetValues(int stationId, string boilerCode)
        {
            if (!Values.TryGetValue(stationId, out var stationDict))
                return null;

            // Точное совпадение
            if (stationDict.TryGetValue(boilerCode, out var val))
                return val;

            // Попробовать с суффиксом А (если код без суффикса)
            if (!boilerCode.EndsWith("А") && !boilerCode.EndsWith("Б"))
            {
                if (stationDict.TryGetValue(boilerCode + "А", out val))
                    return val;
            }

            return null;
        }

        private static string GetCellValue(IXLWorksheet worksheet, int row, int col)
        {
            var cell = worksheet.Cell(row, col);
            if (cell == null || cell.IsEmpty())
                return "";
            var value = cell.Value;
            if (value.IsBlank)
                return "";
            return value.ToString()?.Trim() ?? "";
        }
    }
}
