using System;
using System.Data;
using System.Globalization;
using Microsoft.Data.SqlClient;
using Npgsql;
using Altair.Models;

namespace Altair.Services
{
    public interface IDBLoadService
    {
        Task<string> ExecuteFullLoadAsync();
        Task<string> LoadBoilersAsync();
        Task<string> LoadTurbinesAsync();
        Task<string> ExecuteLoadWithPeriodAsync(DateTime startDate, DateTime endDate);
    }

    public class DBLoadService : IDBLoadService
    {
        private readonly ILogger<DBLoadService> _logger;
        private readonly IConfiguration _configuration;
        private readonly IDataLoadProgressService _progressService;

        public DBLoadService(ILogger<DBLoadService> logger, IConfiguration configuration, IDataLoadProgressService progressService)
        {
            _logger = logger;
            _configuration = configuration;
            _progressService = progressService;
        }

        public async Task<string> ExecuteLoadWithPeriodAsync(DateTime startDate, DateTime endDate)
        {
            if (_progressService.IsLoading)
            {
                return "⚠️ Загрузка уже выполняется. Дождитесь завершения.";
            }

            try
            {
                // 8 шагов: подключение, сырые данные сутки, сырые данные месяц,
                // обработка дней, обработка месяцев, расчет года, вставка данных, завершение
                _progressService.StartLoading($"Загрузка данных за период {startDate:dd.MM.yyyy} - {endDate:dd.MM.yyyy}", 8);

                var cancellationToken = _progressService.CancellationToken;

                await Task.Run(() =>
                {
                    _logger.LogInformation($"🚀 Начало загрузки данных за период {startDate:dd.MM.yyyy} - {endDate:dd.MM.yyyy}");

                    string pgConnection = _configuration.GetConnectionString("DefaultConnection") ?? "";
                    string sqlConnection = _configuration.GetConnectionString("ASTEPConnection") ?? "";

                    using (NpgsqlConnection pgConn = new NpgsqlConnection(pgConnection))
                    using (SqlConnection sqlConn = new SqlConnection(sqlConnection))
                    {
                        _progressService.UpdateProgress(1, "Подключение к базам данных...");
                        sqlConn.Open();
                        pgConn.Open();

                        // Создаем необходимые таблицы если их нет
                        EnsureTablesExist(pgConn);

                        // Проверка отмены после каждого этапа
                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        // === ЭТАП 1: Загрузка сырых ДНЕВНЫХ данных из АСТЭП (параметр 'Сутки') ===
                        _progressService.UpdateProgress(2, "Загрузка дневных данных из АСТЭП...");
                        _logger.LogInformation("🔥 Загрузка дневных данных котлов...");
                        LoadRawBoilersFromASTEP(pgConn, sqlConn, startDate, endDate, "Сутки");
                        _logger.LogInformation("✅ Дневные данные котлов загружены");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        _logger.LogInformation("⚙️ Загрузка дневных данных турбин...");
                        LoadRawTurbinsFromASTEP(pgConn, sqlConn, startDate, endDate, "Сутки");
                        _logger.LogInformation("✅ Дневные данные турбин загружены");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        // === ЭТАП 2: Загрузка сырых МЕСЯЧНЫХ данных из АСТЭП (параметр 'Месяц') ===
                        _progressService.UpdateProgress(3, "Загрузка месячных данных из АСТЭП...");
                        _logger.LogInformation("🔥 Загрузка месячных данных котлов...");
                        LoadRawBoilersFromASTEP(pgConn, sqlConn, startDate, endDate, "Месяц");
                        _logger.LogInformation("✅ Месячные данные котлов загружены");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        _logger.LogInformation("⚙️ Загрузка месячных данных турбин...");
                        LoadRawTurbinsFromASTEP(pgConn, sqlConn, startDate, endDate, "Месяц");
                        _logger.LogInformation("✅ Месячные данные турбин загружены");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        // === ЭТАП 3: Перенос ДНЕВНЫХ данных в Turbins/Boilers ===
                        _progressService.UpdateProgress(4, "Обработка дневных данных...");
                        _logger.LogInformation("📊 Перенос дневных данных в итоговые таблицы...");
                        ProcessDailyData(pgConn);
                        _logger.LogInformation("✅ Дневные данные обработаны");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        // === ЭТАП 4: Перенос МЕСЯЧНЫХ данных в Turbins/Boilers ===
                        _progressService.UpdateProgress(5, "Обработка месячных данных...");
                        _logger.LogInformation("📊 Перенос месячных данных в итоговые таблицы...");
                        ProcessMonthlyData(pgConn);
                        _logger.LogInformation("✅ Месячные данные обработаны");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        // === ЭТАП 5: Расчет ГОДОВЫХ данных из месячных ===
                        _progressService.UpdateProgress(6, "Расчет годовых данных...");
                        _logger.LogInformation("📊 Расчет годовых данных из месячных...");
                        CalculateYearlyData(pgConn);
                        _logger.LogInformation("✅ Годовые данные рассчитаны");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        // === ЭТАП 6: Очистка старых данных без даты ===
                        _progressService.UpdateProgress(7, "Очистка устаревших данных...");
                        CleanupOldData(pgConn);

                        _progressService.UpdateProgress(8, "Завершение...");
                        pgConn.Close();
                        sqlConn.Close();
                    }
                }, cancellationToken);

                if (cancellationToken.IsCancellationRequested)
                {
                    _progressService.CompleteLoading(false, "⛔ Загрузка отменена пользователем");
                    _logger.LogInformation("⛔ Загрузка отменена пользователем");
                    return "⛔ Загрузка была отменена пользователем.";
                }

                _progressService.CompleteLoading(true, "✅ Все данные успешно загружены!");
                _logger.LogInformation("🎉 Все данные успешно загружены!");
                return "✅ Все данные успешно загружены! Процесс завершен.";
            }
            catch (OperationCanceledException)
            {
                _progressService.CompleteLoading(false, "⛔ Загрузка отменена пользователем");
                _logger.LogInformation("⛔ Загрузка отменена пользователем");
                return "⛔ Загрузка была отменена пользователем.";
            }
            catch (Exception ex)
            {
                _progressService.CompleteLoading(false, $"❌ Ошибка: {ex.Message}");
                _logger.LogError(ex, "❌ Ошибка при загрузке данных");
                return $"❌ Ошибка: {ex.Message}";
            }
        }

        public async Task<string> ExecuteFullLoadAsync()
        {
            // По умолчанию загружаем данные за весь 2025 год
            return await ExecuteLoadWithPeriodAsync(new DateTime(2025, 1, 1), DateTime.Now);
        }

        public async Task<string> LoadBoilersAsync()
        {
            return await Task.Run(() =>
            {
                try
                {
                    string pgConnection = _configuration.GetConnectionString("DefaultConnection") ?? "";
                    string sqlConnection = _configuration.GetConnectionString("ASTEPConnection") ?? "";

                    using (NpgsqlConnection pgConn = new NpgsqlConnection(pgConnection))
                    using (SqlConnection sqlConn = new SqlConnection(sqlConnection))
                    {
                        sqlConn.Open();
                        pgConn.Open();

                        EnsureTablesExist(pgConn);
                        LoadRawBoilersFromASTEP(pgConn, sqlConn, new DateTime(2025, 1, 1), DateTime.Now, "Сутки");
                        LoadRawBoilersFromASTEP(pgConn, sqlConn, new DateTime(2025, 1, 1), DateTime.Now, "Месяц");
                        ProcessDailyData(pgConn);
                        ProcessMonthlyData(pgConn);
                        CalculateYearlyData(pgConn);

                        pgConn.Close();
                        sqlConn.Close();
                    }

                    return "✅ Котлы загружены";
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Ошибка при загрузке котлов");
                    return $"❌ Ошибка: {ex.Message}";
                }
            });
        }

        public async Task<string> LoadTurbinesAsync()
        {
            return await Task.Run(() =>
            {
                try
                {
                    string pgConnection = _configuration.GetConnectionString("DefaultConnection") ?? "";
                    string sqlConnection = _configuration.GetConnectionString("ASTEPConnection") ?? "";

                    using (NpgsqlConnection pgConn = new NpgsqlConnection(pgConnection))
                    using (SqlConnection sqlConn = new SqlConnection(sqlConnection))
                    {
                        sqlConn.Open();
                        pgConn.Open();

                        EnsureTablesExist(pgConn);
                        LoadRawTurbinsFromASTEP(pgConn, sqlConn, new DateTime(2025, 1, 1), DateTime.Now, "Сутки");
                        LoadRawTurbinsFromASTEP(pgConn, sqlConn, new DateTime(2025, 1, 1), DateTime.Now, "Месяц");
                        ProcessDailyData(pgConn);
                        ProcessMonthlyData(pgConn);
                        CalculateYearlyData(pgConn);

                        pgConn.Close();
                        sqlConn.Close();
                    }

                    return "✅ Турбины загружены";
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Ошибка при загрузке турбин");
                    return $"❌ Ошибка: {ex.Message}";
                }
            });
        }

        /// <summary>
        /// Создает необходимые таблицы если их нет
        /// </summary>
        private void EnsureTablesExist(NpgsqlConnection pgConn)
        {
            using (var cmd = new NpgsqlCommand(SQL_config.createMonthlyTablesQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Загружает сырые данные котлов из АСТЭП
        /// </summary>
        private void LoadRawBoilersFromASTEP(NpgsqlConnection pgConn, SqlConnection sqlConn, DateTime startDate, DateTime endDate, string periodType)
        {
            var boilerCodes = BuildBoilerCodes();
            string insertQuery = periodType == "Месяц" ? SQL_config.insertQuerry_KA_monthly_upsert : SQL_config.insertQuerry_KA_upsert;

            foreach (var dic in boilerCodes)
            {
                foreach (string code in dic.Value)
                {
                    string sql_start = $"exec dbo.p_GetParamValuePivot '{DBFunctions.Correct(dic.Key)}','Основная', ";
                    string sql_end = $", '{startDate:yyyy-MM-dd} 00:00:00', '{endDate:yyyy-MM-dd} 23:00:00', '{periodType}';";

                    string boilerID = code.Substring(1, 2) + ((code[9] == '0') ? "" : code[9].ToString());
                    boilerID = boilerID.Replace("A", "А").Replace("B", "Б");
                    short stationID = short.Parse(code.Substring(11, 2));

                    string query = sql_start + code + sql_end;
                    SqlCommand command = new SqlCommand(query, sqlConn);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        try
                        {
                            DateTime date = DateTime.ParseExact(reader[0].ToString()!.Substring(0, 10), SQL_config.format, CultureInfo.InvariantCulture);
                            double consumption = TryParseDouble(reader[1]);
                            double kpd = TryParseDouble(reader[2]);
                            double production = TryParseDouble(reader[3]);
                            int hours = int.TryParse(reader[4]?.ToString(), out var h) ? h : 0;
                            double humidity = TryParseDouble(reader[5]);
                            double ash = TryParseDouble(reader[6]);
                            double temp_fact = TryParseDouble(reader[7]);
                            double temp_nominal = TryParseDouble(reader[8]);
                            double temp_koef = TryParseDouble(reader[9]);

                            using (var insertCommand = new NpgsqlCommand(insertQuery, pgConn))
                            {
                                insertCommand.Parameters.AddWithValue("@BoilerID", boilerID);
                                insertCommand.Parameters.AddWithValue("@StationID", stationID);
                                insertCommand.Parameters.AddWithValue("@Production", production);
                                insertCommand.Parameters.AddWithValue("@KPD", kpd);
                                insertCommand.Parameters.AddWithValue("@Date", date);
                                insertCommand.Parameters.AddWithValue("@Consumption", consumption);
                                insertCommand.Parameters.AddWithValue("@Hours", hours);
                                insertCommand.Parameters.AddWithValue("@Temp_fact", temp_fact);
                                insertCommand.Parameters.AddWithValue("@Temp_nominal", temp_nominal);
                                insertCommand.Parameters.AddWithValue("@Temp_koef", temp_koef);
                                insertCommand.Parameters.AddWithValue("@Humidity", humidity);
                                insertCommand.Parameters.AddWithValue("@Ash", ash);

                                insertCommand.ExecuteNonQuery();
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.LogWarning($"Ошибка при обработке строки котла: {ex.Message}");
                        }
                    }
                    reader.Close();
                }
            }
        }

        /// <summary>
        /// Загружает сырые данные турбин из АСТЭП
        /// </summary>
        private void LoadRawTurbinsFromASTEP(NpgsqlConnection pgConn, SqlConnection sqlConn, DateTime startDate, DateTime endDate, string periodType)
        {
            var turbinCodes = BuildTurbinCodes();
            string insertQuery = periodType == "Месяц" ? SQL_config.insertQuerry_TA_monthly_upsert : SQL_config.insertQuerry_TA_upsert;

            foreach (var dic in turbinCodes)
            {
                foreach (string code in dic.Value)
                {
                    string sql_start = $"exec dbo.p_GetParamValuePivot '{DBFunctions.Correct(dic.Key)}','Основная', ";
                    string sql_end = $", '{startDate:yyyy-MM-dd} 00:00:00', '{endDate:yyyy-MM-dd} 23:00:00', '{periodType}';";

                    string turbinID = code.Substring(1, 2) + ((code[9] == '0') ? "" : code[9].ToString());
                    turbinID = turbinID.Replace("A", "А").Replace("B", "Б");
                    short stationID = short.Parse(code.Substring(11, 2));

                    string query = sql_start + code + sql_end;
                    SqlCommand command = new SqlCommand(query, sqlConn);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        try
                        {
                            DateTime date = DateTime.ParseExact(reader[0].ToString()!.Substring(0, 10), SQL_config.format, CultureInfo.InvariantCulture);
                            double urt = TryParseDouble(reader[1]);
                            double consumption = TryParseDouble(reader[2]);
                            int hours = int.TryParse(reader[3]?.ToString(), out var h) ? h : 0;
                            double variation = TryParseDouble(reader[4]);
                            double nominalURT = reader.FieldCount > 5 ? TryParseDouble(reader[5]) : 0;

                            using (var insertCommand = new NpgsqlCommand(insertQuery, pgConn))
                            {
                                insertCommand.Parameters.AddWithValue("@TurbinID", turbinID);
                                insertCommand.Parameters.AddWithValue("@StationID", stationID);
                                insertCommand.Parameters.AddWithValue("@URT", urt);
                                insertCommand.Parameters.AddWithValue("@Date", date);
                                insertCommand.Parameters.AddWithValue("@Consumption", consumption);
                                insertCommand.Parameters.AddWithValue("@Hours", hours);
                                insertCommand.Parameters.AddWithValue("@Variation", variation);
                                insertCommand.Parameters.AddWithValue("@NominalURT", nominalURT);

                                insertCommand.ExecuteNonQuery();
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.LogWarning($"Ошибка при обработке строки турбины: {ex.Message}");
                        }
                    }
                    reader.Close();
                }
            }
        }

        /// <summary>
        /// Переносит дневные данные из raw_* в Turbins/Boilers
        /// Данные переносятся напрямую с той же датой
        /// </summary>
        private void ProcessDailyData(NpgsqlConnection pgConn)
        {
            // Перенос дневных данных турбин
            string insertTurbinsQuery = @"
                INSERT INTO ""Turbins""(""TurbinID"", ""StationID"", ""URT"", ""Consumption"", ""PeriodType"", ""PeriodValue"", ""NominalURT"", ""Date"")
                SELECT
                    turbinid,
                    stationid,
                    urt + variation as urt,
                    consumption,
                    0 as periodtype,
                    hours as periodvalue,
                    nominal_urt,
                    date
                FROM raw_turbins
                WHERE hours = 24 AND consumption > 0
                ON CONFLICT (""TurbinID"", ""StationID"", ""PeriodType"", ""Date"")
                WHERE ""Date"" IS NOT NULL
                DO UPDATE SET
                    ""URT"" = EXCLUDED.""URT"",
                    ""Consumption"" = EXCLUDED.""Consumption"",
                    ""PeriodValue"" = EXCLUDED.""PeriodValue"",
                    ""NominalURT"" = EXCLUDED.""NominalURT"";";

            using (var cmd = new NpgsqlCommand(insertTurbinsQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }

            // Перенос дневных данных котлов (с корректировкой КПД)
            string insertBoilersQuery = @"
                INSERT INTO ""Boilers""(""BoilerID"", ""StationID"", ""KPD"", ""Production"", ""Consumption"", ""PeriodType"", ""PeriodValue"", ""Date"")
                SELECT
                    boilerid,
                    stationid,
                    kpd + humidity + ash - (temp_fact - temp_nominal) * temp_koef as kpd,
                    production,
                    consumption,
                    0 as periodtype,
                    hours as periodvalue,
                    date
                FROM raw_boilers
                WHERE consumption > 0 AND kpd > 0 and hours = 24
                ON CONFLICT (""BoilerID"", ""StationID"", ""PeriodType"", ""Date"")
                WHERE ""Date"" IS NOT NULL
                DO UPDATE SET
                    ""KPD"" = EXCLUDED.""KPD"",
                    ""Production"" = EXCLUDED.""Production"",
                    ""Consumption"" = EXCLUDED.""Consumption"",
                    ""PeriodValue"" = EXCLUDED.""PeriodValue"";";

            using (var cmd = new NpgsqlCommand(insertBoilersQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Переносит месячные данные из raw_*_monthly в Turbins/Boilers
        /// Включая текущий месяц (данные за месяц приходят с датой первого числа этого месяца)
        /// </summary>
        private void ProcessMonthlyData(NpgsqlConnection pgConn)
        {
            // Перенос месячных данных турбин (включая текущий месяц)
            string insertTurbinsQuery = @"
                INSERT INTO ""Turbins""(""TurbinID"", ""StationID"", ""URT"", ""Consumption"", ""PeriodType"", ""PeriodValue"", ""NominalURT"", ""Date"")
                SELECT
                    turbinid,
                    stationid,
                    urt + variation as urt,
                    consumption,
                    1 as periodtype,
                    hours as periodvalue,
                    nominal_urt,
                    month_date
                FROM raw_turbins_monthly
                WHERE hours > 0 AND consumption > 0
                ON CONFLICT (""TurbinID"", ""StationID"", ""PeriodType"", ""Date"")
                WHERE ""Date"" IS NOT NULL
                DO UPDATE SET
                    ""URT"" = EXCLUDED.""URT"",
                    ""Consumption"" = EXCLUDED.""Consumption"",
                    ""PeriodValue"" = EXCLUDED.""PeriodValue"",
                    ""NominalURT"" = EXCLUDED.""NominalURT"";";

            using (var cmd = new NpgsqlCommand(insertTurbinsQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }

            // Перенос месячных данных котлов (включая текущий месяц)
            string insertBoilersQuery = @"
                INSERT INTO ""Boilers""(""BoilerID"", ""StationID"", ""KPD"", ""Production"", ""Consumption"", ""PeriodType"", ""PeriodValue"", ""Date"")
                SELECT
                    boilerid,
                    stationid,
                    kpd,
                    production,
                    consumption,
                    1 as periodtype,
                    hours as periodvalue,
                    month_date
                FROM raw_boilers_monthly
                WHERE hours > 0 AND production > 0 AND consumption > 0
                ON CONFLICT (""BoilerID"", ""StationID"", ""PeriodType"", ""Date"")
                WHERE ""Date"" IS NOT NULL
                DO UPDATE SET
                    ""KPD"" = EXCLUDED.""KPD"",
                    ""Production"" = EXCLUDED.""Production"",
                    ""Consumption"" = EXCLUDED.""Consumption"",
                    ""PeriodValue"" = EXCLUDED.""PeriodValue"";";

            using (var cmd = new NpgsqlCommand(insertBoilersQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Расчет годовых данных из месячных данных
        /// Турбины: URT и NominalURT взвешиваются по Consumption
        /// Котлы: KPD взвешивается по Production
        /// </summary>
        private void CalculateYearlyData(NpgsqlConnection pgConn)
        {
            // Расчет годовых данных турбин из raw_turbins_monthly
            // (включая все месяцы, даже если год ещё не завершён)
            string calculateYearlyTurbinsQuery = @"
                INSERT INTO ""Turbins""(""TurbinID"", ""StationID"", ""URT"", ""Consumption"", ""PeriodType"", ""PeriodValue"", ""NominalURT"", ""Date"")
                SELECT
                    turbinid,
                    stationid,
                    SUM((urt + variation) * consumption) / NULLIF(SUM(consumption), 0) as urt,
                    SUM(consumption) as consumption,
                    2 as periodtype,
                    COUNT(*) as periodvalue,
                    SUM(nominal_urt * consumption) / NULLIF(SUM(consumption), 0) as nominal_urt,
                    DATE_TRUNC('year', month_date)::date as year_date
                FROM raw_turbins_monthly
                WHERE hours > 0 AND consumption > 0
                GROUP BY turbinid, stationid, DATE_TRUNC('year', month_date)
                ON CONFLICT (""TurbinID"", ""StationID"", ""PeriodType"", ""Date"")
                WHERE ""Date"" IS NOT NULL
                DO UPDATE SET
                    ""URT"" = EXCLUDED.""URT"",
                    ""Consumption"" = EXCLUDED.""Consumption"",
                    ""PeriodValue"" = EXCLUDED.""PeriodValue"",
                    ""NominalURT"" = EXCLUDED.""NominalURT"";";

            using (var cmd = new NpgsqlCommand(calculateYearlyTurbinsQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }

            // Расчет годовых данных котлов из raw_boilers_monthly
            // (включая все месяцы, даже если год ещё не завершён)
            string calculateYearlyBoilersQuery = @"
                INSERT INTO ""Boilers""(""BoilerID"", ""StationID"", ""KPD"", ""Production"", ""Consumption"", ""PeriodType"", ""PeriodValue"", ""Date"")
                SELECT
                    boilerid,
                    stationid,
                    SUM(kpd * production) / NULLIF(SUM(production), 0) as kpd,
                    SUM(production) as production,
                    SUM(consumption) as consumption,
                    2 as periodtype,
                    COUNT(*) as periodvalue,
                    DATE_TRUNC('year', month_date)::date as year_date
                FROM raw_boilers_monthly
                WHERE hours > 0 AND consumption > 0 AND production > 0
                GROUP BY boilerid, stationid, DATE_TRUNC('year', month_date)
                ON CONFLICT (""BoilerID"", ""StationID"", ""PeriodType"", ""Date"")
                WHERE ""Date"" IS NOT NULL
                DO UPDATE SET
                    ""KPD"" = EXCLUDED.""KPD"",
                    ""Production"" = EXCLUDED.""Production"",
                    ""Consumption"" = EXCLUDED.""Consumption"",
                    ""PeriodValue"" = EXCLUDED.""PeriodValue"";";

            using (var cmd = new NpgsqlCommand(calculateYearlyBoilersQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Очищает старые данные без даты (для обратной совместимости)
        /// </summary>
        private void CleanupOldData(NpgsqlConnection pgConn)
        {
            using (var cmd = new NpgsqlCommand(SQL_config.truncate_week_TA, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
            using (var cmd = new NpgsqlCommand(SQL_config.truncate_week_KA, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        private static double TryParseDouble(object value)
        {
            if (value is DBNull || string.IsNullOrWhiteSpace(value?.ToString()))
                return 0;

            string normalizedValue = value.ToString()!.Trim().Replace(',', '.');

            if (!double.TryParse(normalizedValue, NumberStyles.Float | NumberStyles.AllowThousands, CultureInfo.InvariantCulture, out var result))
                return 0;

            return Math.Round(result, 3);
        }

        private Dictionary<int, List<string>> BuildBoilerCodes()
        {
            return new Dictionary<int, List<string>>
            {
                { 1, Akscodes.GetBoilerCodes(1) },
                { 2, Akscodes.GetBoilerCodes(2) },
                { 3, Akscodes.GetBoilerCodes(3) },
                { 4, Akscodes.GetBoilerCodes(4) },
                { 5, Akscodes.GetBoilerCodes(5) },
                { 6, Akscodes.GetBoilerCodes(6) },
                { 7, Akscodes.GetBoilerCodes(7) },
                { 8, Akscodes.GetBoilerCodes(8) },
                { 9, Akscodes.GetBoilerCodes(9) },
                { 10, Akscodes.GetBoilerCodes(10) },
                { 12, Akscodes.GetBoilerCodes(12) },
                { 13, Akscodes.GetBoilerCodes(13) },
                { 14, Akscodes.GetBoilerCodes(14) },
                { 15, Akscodes.GetBoilerCodes(15) },
                { 17, Akscodes.GetBoilerCodes(17) },
                { 18, Akscodes.GetBoilerCodes(18) },
                { 19, Akscodes.GetBoilerCodes(19) },
                { 20, Akscodes.GetBoilerCodes(20) },
                { 21, Akscodes.GetBoilerCodes(21) },
                { 22, Akscodes.GetBoilerCodes(22) },
                { 24, Akscodes.GetBoilerCodes(24) },
                { 25, Akscodes.GetBoilerCodes(25) },
                { 26, Akscodes.GetBoilerCodes(26) }
            };
        }

        private Dictionary<int, List<string>> BuildTurbinCodes()
        {
            return new Dictionary<int, List<string>>
            {
                { 1, Akscodes.GetTurbineCodes(1) },
                { 2, Akscodes.GetTurbineCodes(2) },
                { 3, Akscodes.GetTurbineCodes(3) },
                { 4, Akscodes.GetTurbineCodes(4) },
                { 5, Akscodes.GetTurbineCodes(5) },
                { 6, Akscodes.GetTurbineCodes(6) },
                { 7, Akscodes.GetTurbineCodes(7) },
                { 8, Akscodes.GetTurbineCodes(8) },
                { 9, Akscodes.GetTurbineCodes(9) },
                { 10, Akscodes.GetTurbineCodes(10) },
                { 12, Akscodes.GetTurbineCodes(12) },
                { 13, Akscodes.GetTurbineCodes(13) },
                { 14, Akscodes.GetTurbineCodes(14) },
                { 15, Akscodes.GetTurbineCodes(15) },
                { 17, Akscodes.GetTurbineCodes(17) },
                { 18, Akscodes.GetTurbineCodes(18) },
                { 19, Akscodes.GetTurbineCodes(19) },
                { 20, Akscodes.GetTurbineCodes(20) },
                { 21, Akscodes.GetTurbineCodes(21) },
                { 22, Akscodes.GetTurbineCodes(22) },
                { 24, Akscodes.GetTurbineCodes(24) },
                { 25, Akscodes.GetTurbineCodes(25) },
                { 26, Akscodes.GetTurbineCodes(26) }
            };
        }
    }
}
