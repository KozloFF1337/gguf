using System;
using System.Data;
using System.Globalization;
using Microsoft.Data.SqlClient;
using Npgsql;
using Altair.Models;

namespace Altair.Services
{
    public interface IDBLoadService
    {
        Task<string> ExecuteFullLoadAsync();
        Task<string> LoadBoilersAsync();
        Task<string> LoadTurbinesAsync();
        Task<string> ExecuteLoadWithPeriodAsync(DateTime startDate, DateTime endDate);
    }

    public class DBLoadService : IDBLoadService
    {
        private readonly ILogger<DBLoadService> _logger;
        private readonly IConfiguration _configuration;
        private readonly IDataLoadProgressService _progressService;

        public DBLoadService(ILogger<DBLoadService> logger, IConfiguration configuration, IDataLoadProgressService progressService)
        {
            _logger = logger;
            _configuration = configuration;
            _progressService = progressService;
        }

        public async Task<string> ExecuteLoadWithPeriodAsync(DateTime startDate, DateTime endDate)
        {
            if (_progressService.IsLoading)
            {
                return "⚠️ Загрузка уже выполняется. Дождитесь завершения.";
            }

            try
            {
                // 12 шагов: подключение, сырые данные сутки, сырые данные месяц,
                // обработка дней, расчёт месяцев из дней, обработка месяцев, расчёт года из месяцев, обработка года,
                // загрузка стоимости ТУТ, расчёт стоимости ТУТ, очистка данных, завершение
                _progressService.StartLoading($"Загрузка данных за период {startDate:dd.MM.yyyy} - {endDate:dd.MM.yyyy}", 12);

                var cancellationToken = _progressService.CancellationToken;

                await Task.Run(() =>
                {
                    _logger.LogInformation($"🚀 Начало загрузки данных за период {startDate:dd.MM.yyyy} - {endDate:dd.MM.yyyy}");

                    string pgConnection = _configuration.GetConnectionString("DefaultConnection") ?? "";
                    string sqlConnection = _configuration.GetConnectionString("ASTEPConnection") ?? "";

                    using (NpgsqlConnection pgConn = new NpgsqlConnection(pgConnection))
                    using (SqlConnection sqlConn = new SqlConnection(sqlConnection))
                    {
                        _progressService.UpdateProgress(1, "Подключение к базам данных...");
                        sqlConn.Open();
                        pgConn.Open();

                        // Создаем необходимые таблицы если их нет
                        EnsureTablesExist(pgConn);

                        // Проверка отмены после каждого этапа
                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        // === ЭТАП 1: Загрузка сырых ДНЕВНЫХ данных из АСТЭП (параметр 'Сутки') ===
                        _progressService.UpdateProgress(2, "Загрузка дневных данных из АСТЭП...");
                        _logger.LogInformation("🔥 Загрузка дневных данных котлов...");
                        LoadRawBoilersFromASTEP(pgConn, sqlConn, startDate, endDate, "Сутки");
                        _logger.LogInformation("✅ Дневные данные котлов загружены");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        _logger.LogInformation("⚙️ Загрузка дневных данных турбин...");
                        LoadRawTurbinsFromASTEP(pgConn, sqlConn, startDate, endDate, "Сутки");
                        _logger.LogInformation("✅ Дневные данные турбин загружены");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        // === ЭТАП 2: Загрузка сырых МЕСЯЧНЫХ данных из АСТЭП (параметр 'Месяц') ===
                        _progressService.UpdateProgress(3, "Загрузка месячных данных из АСТЭП...");

                        // Удаляем данные за текущий месяц перед загрузкой (могли быть рассчитаны из дневных ранее)
                        _logger.LogInformation("🗑️ Удаление старых месячных данных за текущий месяц...");
                        ClearCurrentMonthData(pgConn);

                        _logger.LogInformation("🔥 Загрузка месячных данных котлов...");
                        LoadRawBoilersFromASTEP(pgConn, sqlConn, startDate, endDate, "Месяц");
                        _logger.LogInformation("✅ Месячные данные котлов загружены");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        _logger.LogInformation("⚙️ Загрузка месячных данных турбин...");
                        LoadRawTurbinsFromASTEP(pgConn, sqlConn, startDate, endDate, "Месяц");
                        _logger.LogInformation("✅ Месячные данные турбин загружены");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        // === ЭТАП 3: Перенос ДНЕВНЫХ данных в Turbins/Boilers ===
                        _progressService.UpdateProgress(4, "Обработка дневных данных...");
                        _logger.LogInformation("📊 Перенос дневных данных в итоговые таблицы...");
                        ProcessDailyData(pgConn);
                        _logger.LogInformation("✅ Дневные данные обработаны");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        // === ЭТАП 4: Расчёт месячных данных текущего месяца из дневных ===
                        _progressService.UpdateProgress(5, "Расчёт месячных данных из дневных...");
                        _logger.LogInformation("📊 Расчёт месячных данных текущего месяца из дневных...");
                        CalculateCurrentMonthFromDaily(pgConn);
                        _logger.LogInformation("✅ Месячные данные текущего месяца рассчитаны");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        // === ЭТАП 5: Перенос МЕСЯЧНЫХ данных в Turbins/Boilers ===
                        _progressService.UpdateProgress(6, "Обработка месячных данных...");
                        _logger.LogInformation("📊 Перенос месячных данных в итоговые таблицы...");
                        ProcessMonthlyData(pgConn);
                        _logger.LogInformation("✅ Месячные данные обработаны");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        // === ЭТАП 6: Расчёт годовых данных текущего года из месячных ===
                        _progressService.UpdateProgress(7, "Расчёт годовых данных из месячных...");

                        // Удаляем данные за текущий год перед пересчётом
                        _logger.LogInformation("🗑️ Удаление старых годовых данных за текущий год...");
                        ClearCurrentYearData(pgConn);

                        _logger.LogInformation("📊 Расчёт годовых данных текущего года из месячных...");
                        CalculateCurrentYearFromMonthly(pgConn);
                        _logger.LogInformation("✅ Годовые данные текущего года рассчитаны");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        // === ЭТАП 7: Перенос ГОДОВЫХ данных в Turbins/Boilers ===
                        _progressService.UpdateProgress(8, "Обработка годовых данных...");
                        _logger.LogInformation("📊 Перенос годовых данных в итоговые таблицы...");
                        ProcessYearlyData(pgConn);
                        _logger.LogInformation("✅ Годовые данные обработаны");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        // === ЭТАП 8: Загрузка стоимости ТУТ из АСТЭП ===
                        _progressService.UpdateProgress(9, "Загрузка стоимости ТУТ из АСТЭП...");
                        _logger.LogInformation("💰 Загрузка стоимости ТУТ...");
                        LoadFuelPricesFromASTEP(pgConn, sqlConn, startDate, endDate, "Сутки");
                        _logger.LogInformation("✅ Стоимость ТУТ загружена");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        // === ЭТАП 9: Расчёт резервов в рублях ===
                        _progressService.UpdateProgress(10, "Расчёт резервов в рублях...");
                        _logger.LogInformation("📊 Расчёт дневных резервов в рублях...");
                        CalculateDailyReservesRub(pgConn);
                        _logger.LogInformation("📊 Расчёт месячных и годовых резервов в рублях...");
                        ClearMonthlyYearlyReservesRub(pgConn);
                        CalculateMonthlyReservesRub(pgConn);
                        CalculateYearlyReservesRub(pgConn);
                        _logger.LogInformation("✅ Резервы в рублях рассчитаны");

                        if (cancellationToken.IsCancellationRequested)
                        {
                            _logger.LogInformation("⛔ Загрузка отменена пользователем");
                            return;
                        }

                        // === ЭТАП 10: Очистка старых данных без даты ===
                        _progressService.UpdateProgress(11, "Очистка устаревших данных...");
                        CleanupOldData(pgConn);

                        _progressService.UpdateProgress(12, "Завершение...");
                        pgConn.Close();
                        sqlConn.Close();
                    }
                }, cancellationToken);

                if (cancellationToken.IsCancellationRequested)
                {
                    _progressService.CompleteLoading(false, "⛔ Загрузка отменена пользователем");
                    _logger.LogInformation("⛔ Загрузка отменена пользователем");
                    return "⛔ Загрузка была отменена пользователем.";
                }

                _progressService.CompleteLoading(true, "✅ Все данные успешно загружены!");
                _logger.LogInformation("🎉 Все данные успешно загружены!");
                return "✅ Все данные успешно загружены! Процесс завершен.";
            }
            catch (OperationCanceledException)
            {
                _progressService.CompleteLoading(false, "⛔ Загрузка отменена пользователем");
                _logger.LogInformation("⛔ Загрузка отменена пользователем");
                return "⛔ Загрузка была отменена пользователем.";
            }
            catch (Exception ex)
            {
                _progressService.CompleteLoading(false, $"❌ Ошибка: {ex.Message}");
                _logger.LogError(ex, "❌ Ошибка при загрузке данных");
                return $"❌ Ошибка: {ex.Message}";
            }
        }

        public async Task<string> ExecuteFullLoadAsync()
        {
            // По умолчанию загружаем данные за весь 2025 год
            return await ExecuteLoadWithPeriodAsync(new DateTime(2025, 1, 1), DateTime.Now);
        }

        public async Task<string> LoadBoilersAsync()
        {
            return await Task.Run(() =>
            {
                try
                {
                    string pgConnection = _configuration.GetConnectionString("DefaultConnection") ?? "";
                    string sqlConnection = _configuration.GetConnectionString("ASTEPConnection") ?? "";

                    using (NpgsqlConnection pgConn = new NpgsqlConnection(pgConnection))
                    using (SqlConnection sqlConn = new SqlConnection(sqlConnection))
                    {
                        sqlConn.Open();
                        pgConn.Open();

                        EnsureTablesExist(pgConn);
                        ClearCurrentMonthData(pgConn);
                        LoadRawBoilersFromASTEP(pgConn, sqlConn, new DateTime(2025, 1, 1), DateTime.Now, "Сутки");
                        LoadRawBoilersFromASTEP(pgConn, sqlConn, new DateTime(2025, 1, 1), DateTime.Now, "Месяц");
                        ProcessDailyData(pgConn);
                        CalculateCurrentMonthFromDaily(pgConn);
                        ProcessMonthlyData(pgConn);
                        ClearCurrentYearData(pgConn);
                        CalculateCurrentYearFromMonthly(pgConn);
                        ProcessYearlyData(pgConn);

                        // Стоимость ТУТ и резервы в рублях
                        LoadFuelPricesFromASTEP(pgConn, sqlConn, new DateTime(2025, 1, 1), DateTime.Now, "Сутки");
                        CalculateDailyReservesRub(pgConn);
                        ClearMonthlyYearlyReservesRub(pgConn);
                        CalculateMonthlyReservesRub(pgConn);
                        CalculateYearlyReservesRub(pgConn);

                        pgConn.Close();
                        sqlConn.Close();
                    }

                    return "✅ Котлы загружены";
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Ошибка при загрузке котлов");
                    return $"❌ Ошибка: {ex.Message}";
                }
            });
        }

        public async Task<string> LoadTurbinesAsync()
        {
            return await Task.Run(() =>
            {
                try
                {
                    string pgConnection = _configuration.GetConnectionString("DefaultConnection") ?? "";
                    string sqlConnection = _configuration.GetConnectionString("ASTEPConnection") ?? "";

                    using (NpgsqlConnection pgConn = new NpgsqlConnection(pgConnection))
                    using (SqlConnection sqlConn = new SqlConnection(sqlConnection))
                    {
                        sqlConn.Open();
                        pgConn.Open();

                        EnsureTablesExist(pgConn);
                        ClearCurrentMonthData(pgConn);
                        LoadRawTurbinsFromASTEP(pgConn, sqlConn, new DateTime(2025, 1, 1), DateTime.Now, "Сутки");
                        LoadRawTurbinsFromASTEP(pgConn, sqlConn, new DateTime(2025, 1, 1), DateTime.Now, "Месяц");
                        ProcessDailyData(pgConn);
                        CalculateCurrentMonthFromDaily(pgConn);
                        ProcessMonthlyData(pgConn);
                        ClearCurrentYearData(pgConn);
                        CalculateCurrentYearFromMonthly(pgConn);
                        ProcessYearlyData(pgConn);

                        // Стоимость ТУТ и резервы в рублях
                        LoadFuelPricesFromASTEP(pgConn, sqlConn, new DateTime(2025, 1, 1), DateTime.Now, "Сутки");
                        CalculateDailyReservesRub(pgConn);
                        ClearMonthlyYearlyReservesRub(pgConn);
                        CalculateMonthlyReservesRub(pgConn);
                        CalculateYearlyReservesRub(pgConn);

                        pgConn.Close();
                        sqlConn.Close();
                    }

                    return "✅ Турбины загружены";
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Ошибка при загрузке турбин");
                    return $"❌ Ошибка: {ex.Message}";
                }
            });
        }

        /// <summary>
        /// Создает необходимые таблицы если их нет
        /// </summary>
        private void EnsureTablesExist(NpgsqlConnection pgConn)
        {
            using (var cmd = new NpgsqlCommand(SQL_config.createMonthlyTablesQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Загружает сырые данные котлов из АСТЭП
        /// </summary>
        private void LoadRawBoilersFromASTEP(NpgsqlConnection pgConn, SqlConnection sqlConn, DateTime startDate, DateTime endDate, string periodType)
        {
            var boilerCodes = BuildBoilerCodes();
            string insertQuery = periodType == "Месяц" ? SQL_config.insertQuerry_KA_monthly_upsert : SQL_config.insertQuerry_KA_upsert;

            foreach (var dic in boilerCodes)
            {
                foreach (string code in dic.Value)
                {
                    string sql_start = $"exec dbo.p_GetParamValuePivot '{DBFunctions.Correct(dic.Key)}','Основная', ";
                    string sql_end = $", '{startDate:yyyy-MM-dd} 00:00:00', '{endDate:yyyy-MM-dd} 23:00:00', '{periodType}';";

                    string boilerID = code.Substring(1, 2) + ((code[9] == '0') ? "" : code[9].ToString());
                    boilerID = boilerID.Replace("A", "А").Replace("B", "Б");
                    short stationID = short.Parse(code.Substring(11, 2));

                    string query = sql_start + code + sql_end;
                    SqlCommand command = new SqlCommand(query, sqlConn);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        try
                        {
                            DateTime date = DateTime.ParseExact(reader[0].ToString()!.Substring(0, 10), SQL_config.format, CultureInfo.InvariantCulture);
                            double consumption = TryParseDouble(reader[1]);
                            double kpd = TryParseDouble(reader[2]);
                            double production = TryParseDouble(reader[3]);
                            int hours = int.TryParse(reader[4]?.ToString(), out var h) ? h : 0;
                            double humidity = TryParseDouble(reader[5]);
                            double ash = TryParseDouble(reader[6]);
                            double temp_fact = TryParseDouble(reader[7]);
                            double temp_nominal = TryParseDouble(reader[8]);
                            double temp_koef = TryParseDouble(reader[9]);

                            using (var insertCommand = new NpgsqlCommand(insertQuery, pgConn))
                            {
                                insertCommand.Parameters.AddWithValue("@BoilerID", boilerID);
                                insertCommand.Parameters.AddWithValue("@StationID", stationID);
                                insertCommand.Parameters.AddWithValue("@Production", production);
                                insertCommand.Parameters.AddWithValue("@KPD", kpd);
                                insertCommand.Parameters.AddWithValue("@Date", date);
                                insertCommand.Parameters.AddWithValue("@Consumption", consumption);
                                insertCommand.Parameters.AddWithValue("@Hours", hours);
                                insertCommand.Parameters.AddWithValue("@Temp_fact", temp_fact);
                                insertCommand.Parameters.AddWithValue("@Temp_nominal", temp_nominal);
                                insertCommand.Parameters.AddWithValue("@Temp_koef", temp_koef);
                                insertCommand.Parameters.AddWithValue("@Humidity", humidity);
                                insertCommand.Parameters.AddWithValue("@Ash", ash);

                                insertCommand.ExecuteNonQuery();
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.LogWarning($"Ошибка при обработке строки котла: {ex.Message}");
                        }
                    }
                    reader.Close();
                }
            }
        }

        /// <summary>
        /// Загружает сырые данные турбин из АСТЭП
        /// </summary>
        private void LoadRawTurbinsFromASTEP(NpgsqlConnection pgConn, SqlConnection sqlConn, DateTime startDate, DateTime endDate, string periodType)
        {
            var turbinCodes = BuildTurbinCodes();
            string insertQuery = periodType == "Месяц" ? SQL_config.insertQuerry_TA_monthly_upsert : SQL_config.insertQuerry_TA_upsert;

            foreach (var dic in turbinCodes)
            {
                foreach (string code in dic.Value)
                {
                    string sql_start = $"exec dbo.p_GetParamValuePivot '{DBFunctions.Correct(dic.Key)}','Основная', ";
                    string sql_end = $", '{startDate:yyyy-MM-dd} 00:00:00', '{endDate:yyyy-MM-dd} 23:00:00', '{periodType}';";

                    string turbinID = code.Substring(1, 2) + ((code[9] == '0') ? "" : code[9].ToString());
                    turbinID = turbinID.Replace("A", "А").Replace("B", "Б");
                    short stationID = short.Parse(code.Substring(11, 2));

                    string query = sql_start + code + sql_end;
                    SqlCommand command = new SqlCommand(query, sqlConn);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        try
                        {
                            DateTime date = DateTime.ParseExact(reader[0].ToString()!.Substring(0, 10), SQL_config.format, CultureInfo.InvariantCulture);
                            double urt = TryParseDouble(reader[1]);
                            double consumption = TryParseDouble(reader[2]);
                            int hours = int.TryParse(reader[3]?.ToString(), out var h) ? h : 0;
                            double variation = TryParseDouble(reader[4]);
                            double nominalURT = reader.FieldCount > 5 ? TryParseDouble(reader[5]) : 0;

                            using (var insertCommand = new NpgsqlCommand(insertQuery, pgConn))
                            {
                                insertCommand.Parameters.AddWithValue("@TurbinID", turbinID);
                                insertCommand.Parameters.AddWithValue("@StationID", stationID);
                                insertCommand.Parameters.AddWithValue("@URT", urt);
                                insertCommand.Parameters.AddWithValue("@Date", date);
                                insertCommand.Parameters.AddWithValue("@Consumption", consumption);
                                insertCommand.Parameters.AddWithValue("@Hours", hours);
                                insertCommand.Parameters.AddWithValue("@Variation", variation);
                                insertCommand.Parameters.AddWithValue("@NominalURT", nominalURT);

                                insertCommand.ExecuteNonQuery();
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.LogWarning($"Ошибка при обработке строки турбины: {ex.Message}");
                        }
                    }
                    reader.Close();
                }
            }
        }

        /// <summary>
        /// Переносит дневные данные из raw_* в Turbins/Boilers
        /// Данные переносятся напрямую с той же датой
        /// </summary>
        private void ProcessDailyData(NpgsqlConnection pgConn)
        {
            // Перенос дневных данных турбин
            string insertTurbinsQuery = @"
                INSERT INTO ""Turbins""(""TurbinID"", ""StationID"", ""URT"", ""Consumption"", ""PeriodType"", ""PeriodValue"", ""NominalURT"", ""Date"")
                SELECT
                    turbinid,
                    stationid,
                    urt + variation as urt,
                    consumption,
                    0 as periodtype,
                    hours as periodvalue,
                    nominal_urt,
                    date
                FROM raw_turbins
                WHERE hours = 24 AND consumption > 0
                ON CONFLICT (""TurbinID"", ""StationID"", ""PeriodType"", ""Date"")
                WHERE ""Date"" IS NOT NULL
                DO UPDATE SET
                    ""URT"" = EXCLUDED.""URT"",
                    ""Consumption"" = EXCLUDED.""Consumption"",
                    ""PeriodValue"" = EXCLUDED.""PeriodValue"",
                    ""NominalURT"" = EXCLUDED.""NominalURT"";";

            using (var cmd = new NpgsqlCommand(insertTurbinsQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }

            // Перенос дневных данных котлов (с корректировкой КПД)
            string insertBoilersQuery = @"
                INSERT INTO ""Boilers""(""BoilerID"", ""StationID"", ""KPD"", ""Production"", ""Consumption"", ""PeriodType"", ""PeriodValue"", ""Date"")
                SELECT
                    boilerid,
                    stationid,
                    kpd + humidity + ash - (temp_fact - temp_nominal) * temp_koef as kpd,
                    production,
                    consumption,
                    0 as periodtype,
                    hours as periodvalue,
                    date
                FROM raw_boilers
                WHERE consumption > 0 AND kpd > 0 and hours = 24
                ON CONFLICT (""BoilerID"", ""StationID"", ""PeriodType"", ""Date"")
                WHERE ""Date"" IS NOT NULL
                DO UPDATE SET
                    ""KPD"" = EXCLUDED.""KPD"",
                    ""Production"" = EXCLUDED.""Production"",
                    ""Consumption"" = EXCLUDED.""Consumption"",
                    ""PeriodValue"" = EXCLUDED.""PeriodValue"";";

            using (var cmd = new NpgsqlCommand(insertBoilersQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Переносит месячные данные из raw_*_monthly в Turbins/Boilers
        /// Включая текущий месяц (данные за месяц приходят с датой первого числа этого месяца)
        /// </summary>
        private void ProcessMonthlyData(NpgsqlConnection pgConn)
        {
            // Перенос месячных данных турбин (включая текущий месяц)
            string insertTurbinsQuery = @"
                INSERT INTO ""Turbins""(""TurbinID"", ""StationID"", ""URT"", ""Consumption"", ""PeriodType"", ""PeriodValue"", ""NominalURT"", ""Date"")
                SELECT
                    turbinid,
                    stationid,
                    urt + variation as urt,
                    consumption,
                    1 as periodtype,
                    hours as periodvalue,
                    nominal_urt,
                    month_date
                FROM raw_turbins_monthly
                WHERE hours > 0 AND consumption > 0
                ON CONFLICT (""TurbinID"", ""StationID"", ""PeriodType"", ""Date"")
                WHERE ""Date"" IS NOT NULL
                DO UPDATE SET
                    ""URT"" = EXCLUDED.""URT"",
                    ""Consumption"" = EXCLUDED.""Consumption"",
                    ""PeriodValue"" = EXCLUDED.""PeriodValue"",
                    ""NominalURT"" = EXCLUDED.""NominalURT"";";

            using (var cmd = new NpgsqlCommand(insertTurbinsQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }

            // Перенос месячных данных котлов (включая текущий месяц)
            string insertBoilersQuery = @"
                INSERT INTO ""Boilers""(""BoilerID"", ""StationID"", ""KPD"", ""Production"", ""Consumption"", ""PeriodType"", ""PeriodValue"", ""Date"")
                SELECT
                    boilerid,
                    stationid,
                    kpd,
                    production,
                    consumption,
                    1 as periodtype,
                    hours as periodvalue,
                    month_date
                FROM raw_boilers_monthly
                WHERE hours > 0 AND production > 0 AND consumption > 0
                ON CONFLICT (""BoilerID"", ""StationID"", ""PeriodType"", ""Date"")
                WHERE ""Date"" IS NOT NULL
                DO UPDATE SET
                    ""KPD"" = EXCLUDED.""KPD"",
                    ""Production"" = EXCLUDED.""Production"",
                    ""Consumption"" = EXCLUDED.""Consumption"",
                    ""PeriodValue"" = EXCLUDED.""PeriodValue"";";

            using (var cmd = new NpgsqlCommand(insertBoilersQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Расчёт месячных данных текущего месяца из дневных данных (накопительный итог)
        /// Турбины: URT и NominalURT - средневзвешенные по Consumption, остальные поля - сумма
        /// Котлы: KPD - средневзвешенный по Production, остальные поля - сумма
        /// Данные записываются в raw_turbins_monthly и raw_boilers_monthly
        /// ВАЖНО: Расчёт производится только для тех турбин/котлов, для которых НЕТ данных из АСТЭП за текущий месяц
        /// (данные за текущий месяц удаляются перед загрузкой из АСТЭП в ClearCurrentMonthData)
        /// </summary>
        private void CalculateCurrentMonthFromDaily(NpgsqlConnection pgConn)
        {
            // Расчёт месячных данных турбин из дневных данных текущего месяца
            // Только для тех турбин, для которых НЕТ данных в raw_turbins_monthly за текущий месяц
            // (если АСТЭП вернул данные - они уже загружены, если нет - рассчитываем из дневных)
            // Формулы:
            // - URT = SUM(urt * consumption) / SUM(consumption)
            // - NominalURT = SUM(nominal_urt * consumption) / SUM(consumption)
            // - Consumption = SUM(consumption)
            // - Hours = SUM(hours)
            // - Variation = SUM(variation * consumption) / SUM(consumption) (средневзвешенный)
            string calculateMonthlyTurbinsQuery = @"
                INSERT INTO raw_turbins_monthly(turbinid, stationid, urt, consumption, month_date, hours, variation, nominal_urt)
                SELECT
                    rt.turbinid,
                    rt.stationid,
                    SUM(rt.urt * rt.consumption) / NULLIF(SUM(rt.consumption), 0) as urt,
                    SUM(rt.consumption) as consumption,
                    DATE_TRUNC('month', rt.date)::date as month_date,
                    SUM(rt.hours) as hours,
                    SUM(rt.variation * rt.consumption) / NULLIF(SUM(rt.consumption), 0) as variation,
                    SUM(rt.nominal_urt * rt.consumption) / NULLIF(SUM(rt.consumption), 0) as nominal_urt
                FROM raw_turbins rt
                WHERE rt.hours > 0 AND rt.consumption > 0
                    AND DATE_TRUNC('month', rt.date) = DATE_TRUNC('month', CURRENT_DATE)
                    AND NOT EXISTS (
                        SELECT 1 FROM raw_turbins_monthly rtm
                        WHERE rtm.turbinid = rt.turbinid
                          AND rtm.stationid = rt.stationid
                          AND rtm.month_date = DATE_TRUNC('month', CURRENT_DATE)::date
                    )
                GROUP BY rt.turbinid, rt.stationid, DATE_TRUNC('month', rt.date)
                ON CONFLICT (turbinid, stationid, month_date)
                DO UPDATE SET
                    urt = EXCLUDED.urt,
                    consumption = EXCLUDED.consumption,
                    hours = EXCLUDED.hours,
                    variation = EXCLUDED.variation,
                    nominal_urt = EXCLUDED.nominal_urt;";

            using (var cmd = new NpgsqlCommand(calculateMonthlyTurbinsQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }

            // Расчёт месячных данных котлов из дневных данных текущего месяца
            // Только для тех котлов, для которых НЕТ данных в raw_boilers_monthly за текущий месяц
            // Формулы:
            // - KPD = SUM(kpd_corrected * production) / SUM(production), где kpd_corrected = kpd + humidity + ash - (temp_fact - temp_nominal) * temp_koef
            // - Production = SUM(production)
            // - Consumption = SUM(consumption)
            // - Hours = SUM(hours)
            // - Остальные поля temp_fact, temp_nominal, temp_koef, humidity, ash - средневзвешенные по production
            string calculateMonthlyBoilersQuery = @"
                INSERT INTO raw_boilers_monthly(boilerid, stationid, kpd, production, month_date, consumption, hours, temp_fact, temp_nominal, temp_koef, humidity, ash)
                SELECT
                    rb.boilerid,
                    rb.stationid,
                    SUM((rb.kpd + rb.humidity + rb.ash - (rb.temp_fact - rb.temp_nominal) * rb.temp_koef) * rb.production) / NULLIF(SUM(rb.production), 0) as kpd,
                    SUM(rb.production) as production,
                    DATE_TRUNC('month', rb.date)::date as month_date,
                    SUM(rb.consumption) as consumption,
                    SUM(rb.hours) as hours,
                    SUM(rb.temp_fact * rb.production) / NULLIF(SUM(rb.production), 0) as temp_fact,
                    SUM(rb.temp_nominal * rb.production) / NULLIF(SUM(rb.production), 0) as temp_nominal,
                    SUM(rb.temp_koef * rb.production) / NULLIF(SUM(rb.production), 0) as temp_koef,
                    SUM(rb.humidity * rb.production) / NULLIF(SUM(rb.production), 0) as humidity,
                    SUM(rb.ash * rb.production) / NULLIF(SUM(rb.production), 0) as ash
                FROM raw_boilers rb
                WHERE rb.hours > 0 AND rb.consumption > 0 AND rb.kpd > 0 AND rb.production > 0
                    AND DATE_TRUNC('month', rb.date) = DATE_TRUNC('month', CURRENT_DATE)
                    AND NOT EXISTS (
                        SELECT 1 FROM raw_boilers_monthly rbm
                        WHERE rbm.boilerid = rb.boilerid
                          AND rbm.stationid = rb.stationid
                          AND rbm.month_date = DATE_TRUNC('month', CURRENT_DATE)::date
                    )
                GROUP BY rb.boilerid, rb.stationid, DATE_TRUNC('month', rb.date)
                ON CONFLICT (boilerid, stationid, month_date)
                DO UPDATE SET
                    kpd = EXCLUDED.kpd,
                    production = EXCLUDED.production,
                    consumption = EXCLUDED.consumption,
                    hours = EXCLUDED.hours,
                    temp_fact = EXCLUDED.temp_fact,
                    temp_nominal = EXCLUDED.temp_nominal,
                    temp_koef = EXCLUDED.temp_koef,
                    humidity = EXCLUDED.humidity,
                    ash = EXCLUDED.ash;";

            using (var cmd = new NpgsqlCommand(calculateMonthlyBoilersQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Расчёт годовых данных текущего года из месячных данных (накопительный итог)
        /// Турбины: URT и NominalURT - средневзвешенные по Consumption, остальные поля - сумма
        /// Котлы: KPD - средневзвешенный по Production, остальные поля - сумма
        /// Данные записываются в raw_turbins_yearly и raw_boilers_yearly
        /// </summary>
        private void CalculateCurrentYearFromMonthly(NpgsqlConnection pgConn)
        {
            // Расчёт годовых данных турбин из месячных данных текущего года
            // Формулы:
            // - URT = SUM((urt + variation) * consumption) / SUM(consumption)
            // - NominalURT = SUM(nominal_urt * consumption) / SUM(consumption)
            // - Consumption = SUM(consumption)
            // - Hours = SUM(hours)
            // - Variation = SUM(variation * consumption) / SUM(consumption) (средневзвешенный)
            string calculateYearlyTurbinsQuery = @"
                INSERT INTO raw_turbins_yearly(turbinid, stationid, urt, consumption, year_date, hours, variation, nominal_urt)
                SELECT
                    turbinid,
                    stationid,
                    SUM((urt + variation) * consumption) / NULLIF(SUM(consumption), 0) as urt,
                    SUM(consumption) as consumption,
                    DATE_TRUNC('year', month_date)::date as year_date,
                    SUM(hours) as hours,
                    SUM(variation * consumption) / NULLIF(SUM(consumption), 0) as variation,
                    SUM(nominal_urt * consumption) / NULLIF(SUM(consumption), 0) as nominal_urt
                FROM raw_turbins_monthly
                WHERE hours > 0 AND consumption > 0
                    AND DATE_TRUNC('year', month_date) = DATE_TRUNC('year', CURRENT_DATE)
                GROUP BY turbinid, stationid, DATE_TRUNC('year', month_date)
                ON CONFLICT (turbinid, stationid, year_date)
                DO UPDATE SET
                    urt = EXCLUDED.urt,
                    consumption = EXCLUDED.consumption,
                    hours = EXCLUDED.hours,
                    variation = EXCLUDED.variation,
                    nominal_urt = EXCLUDED.nominal_urt;";

            using (var cmd = new NpgsqlCommand(calculateYearlyTurbinsQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }

            // Расчёт годовых данных котлов из месячных данных текущего года
            // Формулы:
            // - KPD = SUM(kpd * production) / SUM(production)
            // - Production = SUM(production)
            // - Consumption = SUM(consumption)
            // - Hours = SUM(hours)
            string calculateYearlyBoilersQuery = @"
                INSERT INTO raw_boilers_yearly(boilerid, stationid, kpd, production, year_date, consumption, hours)
                SELECT
                    boilerid,
                    stationid,
                    SUM(kpd * production) / NULLIF(SUM(production), 0) as kpd,
                    SUM(production) as production,
                    DATE_TRUNC('year', month_date)::date as year_date,
                    SUM(consumption) as consumption,
                    SUM(hours) as hours
                FROM raw_boilers_monthly
                WHERE hours > 0 AND consumption > 0 AND production > 0
                    AND DATE_TRUNC('year', month_date) = DATE_TRUNC('year', CURRENT_DATE)
                GROUP BY boilerid, stationid, DATE_TRUNC('year', month_date)
                ON CONFLICT (boilerid, stationid, year_date)
                DO UPDATE SET
                    kpd = EXCLUDED.kpd,
                    production = EXCLUDED.production,
                    consumption = EXCLUDED.consumption,
                    hours = EXCLUDED.hours;";

            using (var cmd = new NpgsqlCommand(calculateYearlyBoilersQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Перенос годовых данных из raw_*_yearly в Turbins/Boilers
        /// </summary>
        private void ProcessYearlyData(NpgsqlConnection pgConn)
        {
            // Перенос годовых данных турбин
            string insertTurbinsQuery = @"
                INSERT INTO ""Turbins""(""TurbinID"", ""StationID"", ""URT"", ""Consumption"", ""PeriodType"", ""PeriodValue"", ""NominalURT"", ""Date"")
                SELECT
                    turbinid,
                    stationid,
                    urt,
                    consumption,
                    2 as periodtype,
                    hours as periodvalue,
                    nominal_urt,
                    year_date
                FROM raw_turbins_yearly
                WHERE hours > 0 AND consumption > 0
                ON CONFLICT (""TurbinID"", ""StationID"", ""PeriodType"", ""Date"")
                WHERE ""Date"" IS NOT NULL
                DO UPDATE SET
                    ""URT"" = EXCLUDED.""URT"",
                    ""Consumption"" = EXCLUDED.""Consumption"",
                    ""PeriodValue"" = EXCLUDED.""PeriodValue"",
                    ""NominalURT"" = EXCLUDED.""NominalURT"";";

            using (var cmd = new NpgsqlCommand(insertTurbinsQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }

            // Перенос годовых данных котлов
            string insertBoilersQuery = @"
                INSERT INTO ""Boilers""(""BoilerID"", ""StationID"", ""KPD"", ""Production"", ""Consumption"", ""PeriodType"", ""PeriodValue"", ""Date"")
                SELECT
                    boilerid,
                    stationid,
                    kpd,
                    production,
                    consumption,
                    2 as periodtype,
                    hours as periodvalue,
                    year_date
                FROM raw_boilers_yearly
                WHERE hours > 0 AND production > 0 AND consumption > 0
                ON CONFLICT (""BoilerID"", ""StationID"", ""PeriodType"", ""Date"")
                WHERE ""Date"" IS NOT NULL
                DO UPDATE SET
                    ""KPD"" = EXCLUDED.""KPD"",
                    ""Production"" = EXCLUDED.""Production"",
                    ""Consumption"" = EXCLUDED.""Consumption"",
                    ""PeriodValue"" = EXCLUDED.""PeriodValue"";";

            using (var cmd = new NpgsqlCommand(insertBoilersQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Удаляет данные за текущий месяц из raw_*_monthly таблиц
        /// Это нужно чтобы при загрузке данных из АСТЭП они заменяли ранее рассчитанные из дневных
        /// </summary>
        private void ClearCurrentMonthData(NpgsqlConnection pgConn)
        {
            // Удаляем месячные данные турбин за текущий месяц
            string deleteTurbinsQuery = @"
                DELETE FROM raw_turbins_monthly
                WHERE month_date = DATE_TRUNC('month', CURRENT_DATE)::date;";

            using (var cmd = new NpgsqlCommand(deleteTurbinsQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }

            // Удаляем месячные данные котлов за текущий месяц
            string deleteBoilersQuery = @"
                DELETE FROM raw_boilers_monthly
                WHERE month_date = DATE_TRUNC('month', CURRENT_DATE)::date;";

            using (var cmd = new NpgsqlCommand(deleteBoilersQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Удаляет данные за текущий год из raw_*_yearly таблиц
        /// Это нужно чтобы при пересчёте годовых данных они обновлялись корректно
        /// </summary>
        private void ClearCurrentYearData(NpgsqlConnection pgConn)
        {
            // Удаляем годовые данные турбин за текущий год
            string deleteTurbinsQuery = @"
                DELETE FROM raw_turbins_yearly
                WHERE year_date = DATE_TRUNC('year', CURRENT_DATE)::date;";

            using (var cmd = new NpgsqlCommand(deleteTurbinsQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }

            // Удаляем годовые данные котлов за текущий год
            string deleteBoilersQuery = @"
                DELETE FROM raw_boilers_yearly
                WHERE year_date = DATE_TRUNC('year', CURRENT_DATE)::date;";

            using (var cmd = new NpgsqlCommand(deleteBoilersQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Загружает стоимость ТУТ из АСТЭП для всех станций
        /// Для каждой станции один акскод, возвращает дату и цену (руб/тут)
        /// </summary>
        private void LoadFuelPricesFromASTEP(NpgsqlConnection pgConn, SqlConnection sqlConn, DateTime startDate, DateTime endDate, string periodType)
        {
            var fuelPriceCodes = Akscodes.GetAllFuelPriceCodes();
            string insertQuery = periodType == "Месяц" ? SQL_config.insertQuerry_FuelPrice_monthly_upsert : SQL_config.insertQuerry_FuelPrice_upsert;

            foreach (var kvp in fuelPriceCodes)
            {
                int stationKey = kvp.Key;
                string code = kvp.Value; // формат: '00S230CT0014'

                string sql_start = $"exec dbo.p_GetParamValuePivot '{DBFunctions.Correct(stationKey)}','Основная', ";
                string sql_end = $", '{startDate:yyyy-MM-dd} 00:00:00', '{endDate:yyyy-MM-dd} 23:00:00', '{periodType}';";

                string query = sql_start + code + sql_end;

                try
                {
                    SqlCommand command = new SqlCommand(query, sqlConn);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        try
                        {
                            DateTime date = DateTime.ParseExact(reader[0].ToString()!.Substring(0, 10), SQL_config.format, CultureInfo.InvariantCulture);
                            double pricePerTut = TryParseDouble(reader[1]);

                            if (pricePerTut <= 0) continue;

                            using (var insertCommand = new NpgsqlCommand(insertQuery, pgConn))
                            {
                                insertCommand.Parameters.AddWithValue("@StationID", (short)stationKey);
                                insertCommand.Parameters.AddWithValue("@PricePerTut", pricePerTut);
                                insertCommand.Parameters.AddWithValue("@Date", date);

                                insertCommand.ExecuteNonQuery();
                            }
                        }
                        catch (Exception ex)
                        {
                            _logger.LogWarning($"Ошибка при обработке стоимости ТУТ станции {stationKey}: {ex.Message}");
                        }
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    _logger.LogWarning($"Ошибка при загрузке стоимости ТУТ станции {stationKey}: {ex.Message}");
                }
            }
        }

        /// <summary>
        /// Рассчитывает резервы в рублях за каждый день (per-station).
        /// Формула:
        ///   Для турбин: ∆ВТА = (URTфакт - URTнорм) * Consumption / 7000 / (85/100) / (98/100)
        ///   Для котлов: ∆ВКА = (КПД_норм - КПД_факт) / 100 * Consumption
        ///   reserves_rub_day = (SUM(∆ВТА) + SUM(∆ВКА)) * price_per_tut_day
        /// Хранится по станциям в таблице reserves_rub (period_type=0).
        /// </summary>
        private void CalculateDailyReservesRub(NpgsqlConnection pgConn)
        {
            const double ETA_KN = 85.0;
            const double ETA_TP = 98.0;

            // Получаем все уникальные станции и даты, для которых есть дневные данные
            var stationDates = new List<(short stationId, DateTime date)>();
            string queryDates = @"
                SELECT DISTINCT stationid, date FROM (
                    SELECT stationid, date FROM raw_turbins WHERE hours = 24 AND consumption > 0
                    UNION
                    SELECT stationid, date FROM raw_boilers WHERE consumption > 0 AND kpd > 0 AND hours = 24
                ) sub
                ORDER BY stationid, date;";

            using (var cmd = new NpgsqlCommand(queryDates, pgConn))
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    stationDates.Add((reader.GetInt16(0), reader.GetDateTime(1)));
                }
            }

            foreach (var (stationId, date) in stationDates)
            {
                // Получаем цену ТУТ за этот день и станцию
                double pricePerTut = 0;
                string priceQuery = "SELECT price_per_tut FROM raw_fuel_prices WHERE stationid = @StationID AND date = @Date AND price_per_tut > 0;";
                using (var cmd = new NpgsqlCommand(priceQuery, pgConn))
                {
                    cmd.Parameters.AddWithValue("@StationID", stationId);
                    cmd.Parameters.AddWithValue("@Date", date);
                    var result = cmd.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                        pricePerTut = Convert.ToDouble(result);
                }

                if (pricePerTut <= 0) continue; // нет цены — пропускаем

                // Считаем резервы турбин за этот день
                double reservesTurbines = 0;
                string turbQuery = @"
                    SELECT turbinid, stationid, urt + variation as urt_fact, consumption, nominal_urt
                    FROM raw_turbins
                    WHERE stationid = @StationID AND date = @Date AND hours = 24 AND consumption > 0;";

                using (var cmd = new NpgsqlCommand(turbQuery, pgConn))
                {
                    cmd.Parameters.AddWithValue("@StationID", stationId);
                    cmd.Parameters.AddWithValue("@Date", date);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string turbinId = reader.GetString(0);
                            double urtFact = reader.GetDouble(2);
                            double consumption = reader.GetDouble(3);
                            double nominalUrt = reader.IsDBNull(4) ? 0 : reader.GetDouble(4);

                            // Берём нормативный УРТ из конфига (если есть)
                            double urtNorm = NormativeValues.GetUrtValue(stationId, turbinId) ?? nominalUrt;
                            if (urtNorm <= 0) continue;

                            double deltaQ = urtFact - urtNorm;
                            double deltaBTA = deltaQ * consumption / 7000.0 / (ETA_KN / 100.0) / (ETA_TP / 100.0);
                            reservesTurbines += deltaBTA;
                        }
                    }
                }

                // Считаем резервы котлов за этот день
                double reservesBoilers = 0;
                string boilQuery = @"
                    SELECT boilerid, stationid,
                           kpd + humidity + ash - (temp_fact - temp_nominal) * temp_koef as kpd_fact,
                           consumption
                    FROM raw_boilers
                    WHERE stationid = @StationID AND date = @Date AND consumption > 0 AND kpd > 0 AND hours = 24;";

                using (var cmd = new NpgsqlCommand(boilQuery, pgConn))
                {
                    cmd.Parameters.AddWithValue("@StationID", stationId);
                    cmd.Parameters.AddWithValue("@Date", date);
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string boilerId = reader.GetString(0);
                            double kpdFact = reader.GetDouble(2);
                            double consumption = reader.GetDouble(3);

                            // Берём нормативный КПД из конфига
                            double? kpdNorm = NormativeValues.GetKpdValue(stationId, boilerId);
                            if (kpdNorm == null || kpdNorm <= 0) continue;

                            double deltaBKA = (kpdNorm.Value - kpdFact) / 100.0 * consumption;
                            reservesBoilers += deltaBKA;
                        }
                    }
                }

                double reservesTotal = (reservesTurbines + reservesBoilers) * pricePerTut;
                double resTurbRub = reservesTurbines * pricePerTut;
                double resBoilRub = reservesBoilers * pricePerTut;

                // Записываем в reserves_rub (period_type=0 = день)
                using (var cmd = new NpgsqlCommand(SQL_config.insertQuerry_ReservesRub_upsert, pgConn))
                {
                    cmd.Parameters.AddWithValue("@StationID", stationId);
                    cmd.Parameters.AddWithValue("@PeriodType", (short)0);
                    cmd.Parameters.AddWithValue("@Date", date);
                    cmd.Parameters.AddWithValue("@ReservesTurbines", resTurbRub);
                    cmd.Parameters.AddWithValue("@ReservesBoilers", resBoilRub);
                    cmd.Parameters.AddWithValue("@ReservesTotal", reservesTotal);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        /// <summary>
        /// Рассчитывает месячные резервы в рублях как SUM дневных reserves_rub.
        /// Записывает в reserves_rub (period_type=1, date = первое число месяца).
        /// </summary>
        private void CalculateMonthlyReservesRub(NpgsqlConnection pgConn)
        {
            string calculateQuery = @"
                INSERT INTO reserves_rub(stationid, period_type, date, reserves_turbines, reserves_boilers, reserves_total)
                SELECT
                    stationid,
                    1 as period_type,
                    DATE_TRUNC('month', date)::date as month_date,
                    SUM(reserves_turbines) as reserves_turbines,
                    SUM(reserves_boilers) as reserves_boilers,
                    SUM(reserves_total) as reserves_total
                FROM reserves_rub
                WHERE period_type = 0
                GROUP BY stationid, DATE_TRUNC('month', date)
                ON CONFLICT (stationid, period_type, date) DO UPDATE SET
                    reserves_turbines = EXCLUDED.reserves_turbines,
                    reserves_boilers = EXCLUDED.reserves_boilers,
                    reserves_total = EXCLUDED.reserves_total;";

            using (var cmd = new NpgsqlCommand(calculateQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Рассчитывает годовые резервы в рублях как SUM месячных reserves_rub.
        /// Записывает в reserves_rub (period_type=2, date = 1 января года).
        /// </summary>
        private void CalculateYearlyReservesRub(NpgsqlConnection pgConn)
        {
            string calculateQuery = @"
                INSERT INTO reserves_rub(stationid, period_type, date, reserves_turbines, reserves_boilers, reserves_total)
                SELECT
                    stationid,
                    2 as period_type,
                    DATE_TRUNC('year', date)::date as year_date,
                    SUM(reserves_turbines) as reserves_turbines,
                    SUM(reserves_boilers) as reserves_boilers,
                    SUM(reserves_total) as reserves_total
                FROM reserves_rub
                WHERE period_type = 1
                GROUP BY stationid, DATE_TRUNC('year', date)
                ON CONFLICT (stationid, period_type, date) DO UPDATE SET
                    reserves_turbines = EXCLUDED.reserves_turbines,
                    reserves_boilers = EXCLUDED.reserves_boilers,
                    reserves_total = EXCLUDED.reserves_total;";

            using (var cmd = new NpgsqlCommand(calculateQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Очищает месячные и годовые резервы в рублях перед пересчётом
        /// (дневные остаются, их пересчитывает CalculateDailyReservesRub через UPSERT)
        /// </summary>
        private void ClearMonthlyYearlyReservesRub(NpgsqlConnection pgConn)
        {
            string deleteQuery = @"DELETE FROM reserves_rub WHERE period_type IN (1, 2);";
            using (var cmd = new NpgsqlCommand(deleteQuery, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Очищает старые данные без даты (для обратной совместимости)
        /// </summary>
        private void CleanupOldData(NpgsqlConnection pgConn)
        {
            using (var cmd = new NpgsqlCommand(SQL_config.truncate_week_TA, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
            using (var cmd = new NpgsqlCommand(SQL_config.truncate_week_KA, pgConn))
            {
                cmd.ExecuteNonQuery();
            }
        }

        private static double TryParseDouble(object value)
        {
            if (value is DBNull || string.IsNullOrWhiteSpace(value?.ToString()))
                return 0;

            string normalizedValue = value.ToString()!.Trim().Replace(',', '.');

            if (!double.TryParse(normalizedValue, NumberStyles.Float | NumberStyles.AllowThousands, CultureInfo.InvariantCulture, out var result))
                return 0;

            return Math.Round(result, 3);
        }

        private Dictionary<int, List<string>> BuildBoilerCodes()
        {
            return new Dictionary<int, List<string>>
            {
                { 1, Akscodes.GetBoilerCodes(1) },
                { 2, Akscodes.GetBoilerCodes(2) },
                { 3, Akscodes.GetBoilerCodes(3) },
                { 4, Akscodes.GetBoilerCodes(4) },
                { 5, Akscodes.GetBoilerCodes(5) },
                { 6, Akscodes.GetBoilerCodes(6) },
                { 7, Akscodes.GetBoilerCodes(7) },
                { 8, Akscodes.GetBoilerCodes(8) },
                { 9, Akscodes.GetBoilerCodes(9) },
                { 10, Akscodes.GetBoilerCodes(10) },
                { 12, Akscodes.GetBoilerCodes(12) },
                { 13, Akscodes.GetBoilerCodes(13) },
                { 14, Akscodes.GetBoilerCodes(14) },
                { 15, Akscodes.GetBoilerCodes(15) },
                { 17, Akscodes.GetBoilerCodes(17) },
                { 18, Akscodes.GetBoilerCodes(18) },
                { 19, Akscodes.GetBoilerCodes(19) },
                { 20, Akscodes.GetBoilerCodes(20) },
                { 21, Akscodes.GetBoilerCodes(21) },
                { 22, Akscodes.GetBoilerCodes(22) },
                { 24, Akscodes.GetBoilerCodes(24) },
                { 25, Akscodes.GetBoilerCodes(25) },
                { 26, Akscodes.GetBoilerCodes(26) }
            };
        }

        private Dictionary<int, List<string>> BuildTurbinCodes()
        {
            return new Dictionary<int, List<string>>
            {
                { 1, Akscodes.GetTurbineCodes(1) },
                { 2, Akscodes.GetTurbineCodes(2) },
                { 3, Akscodes.GetTurbineCodes(3) },
                { 4, Akscodes.GetTurbineCodes(4) },
                { 5, Akscodes.GetTurbineCodes(5) },
                { 6, Akscodes.GetTurbineCodes(6) },
                { 7, Akscodes.GetTurbineCodes(7) },
                { 8, Akscodes.GetTurbineCodes(8) },
                { 9, Akscodes.GetTurbineCodes(9) },
                { 10, Akscodes.GetTurbineCodes(10) },
                { 12, Akscodes.GetTurbineCodes(12) },
                { 13, Akscodes.GetTurbineCodes(13) },
                { 14, Akscodes.GetTurbineCodes(14) },
                { 15, Akscodes.GetTurbineCodes(15) },
                { 17, Akscodes.GetTurbineCodes(17) },
                { 18, Akscodes.GetTurbineCodes(18) },
                { 19, Akscodes.GetTurbineCodes(19) },
                { 20, Akscodes.GetTurbineCodes(20) },
                { 21, Akscodes.GetTurbineCodes(21) },
                { 22, Akscodes.GetTurbineCodes(22) },
                { 24, Akscodes.GetTurbineCodes(24) },
                { 25, Akscodes.GetTurbineCodes(25) },
                { 26, Akscodes.GetTurbineCodes(26) }
            };
        }
    }
}
