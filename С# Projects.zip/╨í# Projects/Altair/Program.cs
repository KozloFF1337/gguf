using Altair;
using Microsoft.EntityFrameworkCore;
using Altair.Models;
using Microsoft.Data.SqlClient;
using Altair.Controllers;
using Microsoft.AspNetCore.Connections;
using Npgsql;
using Altair.Services;
using Altair.Data;

// Настройка Npgsql для корректной работы с датами без конвертации в UTC
// Это позволяет читать даты из БД "как есть" без сдвига часовых поясов
AppContext.SetSwitch("Npgsql.EnableLegacyTimestampBehavior", true);

var builder = WebApplication.CreateBuilder(args);

// Проверяем флаг автозагрузки из командной строки
// Использование: dotnet run -- --autoload или dotnet run -- --no-autoload
bool enableAutoLoad = !args.Contains("--no-autoload");
if (args.Contains("--autoload"))
{
    enableAutoLoad = true;
}

Console.WriteLine($"[Startup] Автозагрузка данных: {(enableAutoLoad ? "ВКЛЮЧЕНА" : "ОТКЛЮЧЕНА")}");

// Add services to the container.
builder.Services.AddControllersWithViews();

// Универсальные репозитории и сервисы
builder.Services.AddScoped<IBoilerRepository, BoilerRepository>();
builder.Services.AddScoped<ITurbinRepository, TurbinRepository>();
builder.Services.AddScoped<IHomePageRepository, HomePageRepository>();
builder.Services.AddScoped<IDataService, DataService>();
builder.Services.AddScoped<IHomePageService, HomePageService>();
builder.Services.AddScoped<IConfigValidationService, ConfigValidationService>();

// Singleton для отслеживания прогресса загрузки данных (общий для всех пользователей)
builder.Services.AddSingleton<IDataLoadProgressService, DataLoadProgressService>();

// DBLoadService зависит от DataLoadProgressService, поэтому регистрируем его после
builder.Services.AddScoped<IDBLoadService, DBLoadService>();

// Сервис для работы с файлом контроля тех параметров
builder.Services.AddScoped<ITechParamsService, TechParamsService>();

// Автозагрузка данных при старте приложения (только если включена)
if (enableAutoLoad)
{
    builder.Services.AddHostedService<AutoLoadDataService>();
}

// Сервис автоматической загрузки данных за последние 30 дней каждые 12 часов (в 00:00 и 12:00)
builder.Services.AddHostedService<ScheduledDataLoadService>();

builder.Services.AddDbContext<BoilerDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddDbContext<TurbinDbContext>(options => 
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddDbContext<HomePageDBContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));
var app = builder.Build();

// Инициализируем конфигурационные сервисы с правильным путём к файлам
// Используем ContentRootPath для определения корневой папки проекта
string contentRoot = app.Environment.ContentRootPath;

// Инициализируем Akscodes - загружает коды оборудования из Excel
Akscodes.Initialize(contentRoot);
Console.WriteLine($"[Akscodes] Загружено станций КА: {Akscodes.matching_dict_KA.Count}, ТА: {Akscodes.matching_dict_TA.Count}");

// Инициализируем NormativeValues - загружает нормативные значения КПД и УРТ из Excel
NormativeValues.Initialize(contentRoot);
Console.WriteLine($"[NormativeValues] Загружено станций КПД: {NormativeValues.KpdValues.Count}, УРТ: {NormativeValues.UrtValues.Count}");

// Инициализируем ConstantsConfig - загружает константы temp_nominal/temp_koef из Excel
ConstantsConfig.Initialize(contentRoot);
Console.WriteLine($"[ConstantsConfig] Загружено станций констант: {ConstantsConfig.Values.Count}");

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run("http://localhost:5000");