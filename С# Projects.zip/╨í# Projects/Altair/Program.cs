using Altair;
using Microsoft.EntityFrameworkCore;
using Altair.Models;
using Microsoft.Data.SqlClient;
using Altair.Controllers;
using Microsoft.AspNetCore.Connections;
using Npgsql;
using Altair.Services;
using Altair.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Универсальные репозитории и сервисы
builder.Services.AddScoped<IBoilerRepository, BoilerRepository>();
builder.Services.AddScoped<ITurbinRepository, TurbinRepository>();
builder.Services.AddScoped<IHomePageRepository, HomePageRepository>();
builder.Services.AddScoped<IDataService, DataService>();
builder.Services.AddScoped<IHomePageService, HomePageService>();
builder.Services.AddScoped<IConfigValidationService, ConfigValidationService>();

// Singleton для отслеживания прогресса загрузки данных (общий для всех пользователей)
builder.Services.AddSingleton<IDataLoadProgressService, DataLoadProgressService>();

// DBLoadService зависит от DataLoadProgressService, поэтому регистрируем его после
builder.Services.AddScoped<IDBLoadService, DBLoadService>();

builder.Services.AddDbContext<BoilerDbContext>(options => 
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddDbContext<TurbinDbContext>(options => 
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddDbContext<HomePageDBContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));
var app = builder.Build();

// Инициализируем Akscodes при запуске приложения
// Это вызовет статический конструктор и загрузит данные из Excel
var akscodes_ka = Akscodes.matching_dict_KA;
var akscodes_ta = Akscodes.matching_dict_TA;

// Инициализируем NormativeValues - загружаем нормативные значения КПД и УРТ из Excel
// Сначала создаём шаблон файла, если он не существует
NormativeValues.CreateTemplateIfNotExists();
// Затем загружаем данные (вызов любого свойства вызовет статический конструктор)
var normative_kpd = NormativeValues.KpdValues;
var normative_urt = NormativeValues.UrtValues;

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run("http://localhost:5000");