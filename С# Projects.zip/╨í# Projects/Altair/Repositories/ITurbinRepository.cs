using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;

public interface ITurbinRepository
{
    Task<List<Turbin>> GetTurbins(PeriodType periodType);
    Task<List<Turbin>> GetTurbinsByDate(PeriodType periodType, DateTime date);
    Task<List<DateTime>> GetAvailableDates(PeriodType periodType);
}
