using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;
using Microsoft.EntityFrameworkCore;

using Altair.Data;
public class BoilerRepository : IBoilerRepository
{
    private readonly BoilerDbContext _context;
    public BoilerRepository(BoilerDbContext context)
    {
        _context = context;
    }
    public async Task<List<Boiler>> GetBoilers(PeriodType periodType)
    {
        return await _context.Set<Boiler>()
            .Where(b => b.PeriodType == periodType)
            .ToListAsync();
    }
}
