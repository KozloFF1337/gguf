using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Altair.Models;

public class HomePageRepository : IHomePageRepository
{
    private readonly HomePageDBContext _context;
    public HomePageRepository(HomePageDBContext context)
    {
        _context = context;
    }
    public async Task<List<HomePage>> Get()
    {
        var homePageEntities = await _context.HomePages
            .AsNoTracking()
            .ToListAsync();

        var homePages = homePageEntities
            .Select(h => HomePage.Create(h.year, h.boilers_total, h.turbins_total, h.reservs_total_rub, h.reservs_total_tut, h.boilers_prisosi, h.boilers_nedozhogi, h.boilers_rs, h.boilers_temp, h.boilers_consumption, h.turbins_vac, h.turbins_rezhim, h.turbins_temp_pv, h.turbins_steam_temp, h.turbins_steam_pressure, h.turbins_steam_after_pp, h.turbins_steam_in_reg, h.turbins_neplan, h.boilers_final_1, h.boilers_final_2, h.boilers_final_3, h.boilers_final_4, h.boilers_final_5, h.boilers_final_6, h.boilers_final_7, h.boilers_final_8, h.boilers_final_9, h.boilers_final_10, h.boilers_final_11, h.boilers_final_12, h.boilers_final_1_rub, h.boilers_final_2_rub, h.boilers_final_3_rub, h.boilers_final_4_rub, h.boilers_final_5_rub, h.boilers_final_6_rub, h.boilers_final_7_rub, h.boilers_final_8_rub, h.boilers_final_9_rub, h.boilers_final_10_rub, h.boilers_final_11_rub, h.boilers_final_12_rub, h.turbins_final_1, h.turbins_final_2, h.turbins_final_3, h.turbins_final_4, h.turbins_final_5, h.turbins_final_6, h.turbins_final_7, h.turbins_final_8, h.turbins_final_9, h.turbins_final_10, h.turbins_final_11, h.turbins_final_12, h.turbins_final_1_rub, h.turbins_final_2_rub, h.turbins_final_3_rub, h.turbins_final_4_rub, h.turbins_final_5_rub, h.turbins_final_6_rub, h.turbins_final_7_rub, h.turbins_final_8_rub, h.turbins_final_9_rub, h.turbins_final_10_rub, h.turbins_final_11_rub, h.turbins_final_12_rub).homepage)
            .ToList();

        return homePages;
    }
}