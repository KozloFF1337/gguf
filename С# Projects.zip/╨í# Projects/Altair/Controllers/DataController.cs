using Microsoft.AspNetCore.Mvc;
using Altair.Models;

namespace Altair.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DataController : ControllerBase
    {
        private readonly IDataService _dataService;
        private readonly ILogger<DataController> _logger;

        public DataController(IDataService dataService, ILogger<DataController> logger)
        {
            _dataService = dataService;
            _logger = logger;
        }

        /// <summary>
        /// Получает данные по котлам и турбинам для указанного типа периода и даты
        /// </summary>
        [HttpGet("period")]
        public async Task<IActionResult> GetDataByPeriod(
            [FromQuery] PeriodType periodType,
            [FromQuery] DateTime? date = null)
        {
            try
            {
                List<Boiler> boilers;
                List<Turbin> turbins;

                if (date.HasValue)
                {
                    boilers = await _dataService.GetBoilersByDate(periodType, date.Value);
                    turbins = await _dataService.GetTurbinsByDate(periodType, date.Value);
                }
                else
                {
                    boilers = await _dataService.GetBoilers(periodType);
                    turbins = await _dataService.GetTurbins(periodType);
                }

                return Ok(new
                {
                    success = true,
                    boilers = boilers,
                    turbins = turbins,
                    periodType = periodType,
                    date = date
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при получении данных по периоду");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        /// <summary>
        /// Получает список доступных дней (только дни с данными)
        /// </summary>
        [HttpGet("available-days")]
        public async Task<IActionResult> GetAvailableDays()
        {
            try
            {
                var days = await _dataService.GetAvailableDays();

                return Ok(new
                {
                    success = true,
                    dates = days.Select(d => new
                    {
                        date = d.ToString("yyyy-MM-dd"),
                        displayText = d.ToString("dd.MM.yyyy")
                    })
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при получении доступных дней");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        /// <summary>
        /// Получает список доступных месяцев (включая текущий месяц, если есть данные)
        /// </summary>
        [HttpGet("available-months")]
        public async Task<IActionResult> GetAvailableMonths()
        {
            try
            {
                var months = await _dataService.GetAvailableMonths();
                // Показываем все месяцы с данными (включая текущий)
                // Фильтр убран - пользователь сам решает, какой месяц смотреть

                return Ok(new
                {
                    success = true,
                    dates = months.Select(d => new
                    {
                        date = d.ToString("yyyy-MM-dd"),
                        displayText = GetMonthDisplayText(d)
                    })
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при получении доступных месяцев");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        /// <summary>
        /// Получает список доступных годов (только годы с данными)
        /// </summary>
        [HttpGet("available-years")]
        public async Task<IActionResult> GetAvailableYears()
        {
            try
            {
                var years = await _dataService.GetAvailableYears();

                return Ok(new
                {
                    success = true,
                    years = years.Select(y => new
                    {
                        year = y,
                        displayText = y.ToString(),
                        date = $"{y}-01-01"
                    })
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при получении доступных годов");
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        private static string GetMonthDisplayText(DateTime date)
        {
            var monthNames = new[] {
                "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
                "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"
            };
            return $"{monthNames[date.Month - 1]} {date.Year}";
        }
    }
}
