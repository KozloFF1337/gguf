using System;
using System.Diagnostics;
using System.Globalization;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Altair.Models;

namespace Altair.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IDataService _dataService;

        public HomeController(ILogger<HomeController> logger, IDataService dataService)
        {
            _logger = logger;
            _dataService = dataService;
        }

        public async Task<IActionResult> Index(PeriodType? selectedPeriod, DateTime? selectedDate)
        {
            int currentWeek = ISOWeek.GetWeekOfYear(DateTime.Now);
            // По умолчанию месяц вместо дня
            var period = selectedPeriod ?? PeriodType.Month;

            List<Turbin> turbins;
            List<Boiler> boilers;

            // Если дата не указана и это первое открытие - получаем последний доступный месяц
            if (!selectedDate.HasValue && !selectedPeriod.HasValue)
            {
                var availableMonths = await _dataService.GetAvailableMonths();
                if (availableMonths.Any())
                {
                    selectedDate = availableMonths.First(); // Первый = самый последний (отсортировано по убыванию)
                }
            }

            if (selectedDate.HasValue)
            {
                turbins = await _dataService.GetTurbinsByDate(period, selectedDate.Value);
                boilers = await _dataService.GetBoilersByDate(period, selectedDate.Value);
            }
            else
            {
                turbins = await _dataService.GetTurbins(period);
                boilers = await _dataService.GetBoilers(period);
            }

            double reservesRub;
            if (selectedDate.HasValue)
            {
                reservesRub = await _dataService.GetReservesRubByDate(period, selectedDate.Value);
            }
            else
            {
                reservesRub = await _dataService.GetReservesRub(period);
            }

            // Данные для графика по месяцам (текущий и предыдущий год)
            int currentYear = DateTime.Now.Year;
            var (turbinesCurrent, boilersCurrent, totalCurrent) = await _dataService.GetMonthlyReservesRubByYear(currentYear);
            var (turbinesPrev, boilersPrev, totalPrev) = await _dataService.GetMonthlyReservesRubByYear(currentYear - 1);

            var homePage = await _dataService.GetHomePageData();
            var model = new HomeIndexViewModel
            {
                Turbines = turbins,
                Boilers = boilers,
                HomePage = homePage,
                SelectedPeriod = period,
                SelectedDate = selectedDate,
                ReservesRub = reservesRub,
                MonthlyTurbinesRub = turbinesCurrent,
                MonthlyBoilersRub = boilersCurrent,
                MonthlyTotalRub = totalCurrent,
                MonthlyTurbinesRubPrev = turbinesPrev,
                MonthlyBoilersRubPrev = boilersPrev,
                MonthlyTotalRubPrev = totalPrev
            };
            return View(model);
        }

        public async Task<IActionResult> Visualisation(PeriodType? selectedPeriod, DateTime? selectedDate)
        {
            // По умолчанию месяц вместо дня
            var period = selectedPeriod ?? PeriodType.Month;

            List<Turbin> turbins;
            List<Boiler> boilers;

            // Если дата не указана и это первое открытие - получаем последний доступный месяц
            if (!selectedDate.HasValue && !selectedPeriod.HasValue)
            {
                var availableMonths = await _dataService.GetAvailableMonths();
                if (availableMonths.Any())
                {
                    selectedDate = availableMonths.First(); // Первый = самый последний (отсортировано по убыванию)
                }
            }

            if (selectedDate.HasValue)
            {
                turbins = await _dataService.GetTurbinsByDate(period, selectedDate.Value);
                boilers = await _dataService.GetBoilersByDate(period, selectedDate.Value);
            }
            else
            {
                turbins = await _dataService.GetTurbins(period);
                boilers = await _dataService.GetBoilers(period);
            }

            var model = new VisualisationViewModel
            {
                Turbins = turbins,
                Boilers = boilers,
                SelectedPeriod = period,
                SelectedDate = selectedDate
            };
            return View(model);
        }

        public IActionResult Contacts() => View();
        public IActionResult Params() => View();
        public IActionResult Optimizator() => View();
        public IActionResult QuicklyNotification() => View();
        public IActionResult NewService() => View();

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}