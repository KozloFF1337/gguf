using Microsoft.AspNetCore.Mvc;
using Altair.Services;
using Altair.Models;

namespace Altair.Controllers
{
    public class TechParamsController : Controller
    {
        private readonly ITechParamsService _techParamsService;
        private const string UploadPassword = "altair2024"; // Пароль для загрузки файла

        public TechParamsController(ITechParamsService techParamsService)
        {
            _techParamsService = techParamsService;
        }

        // Страница просмотра данных
        public IActionResult Index(string type = "GRES")
        {
            var data = _techParamsService.GetData();
            var model = new TechParamsViewModel
            {
                Data = data,
                SelectedType = type
            };
            return View(model);
        }

        // API для получения данных (JSON)
        [HttpGet]
        [Route("api/TechParams/data")]
        public IActionResult GetData()
        {
            var data = _techParamsService.GetData();
            return Json(data);
        }

        // API для скачивания файла
        [HttpGet]
        [Route("api/TechParams/download")]
        public IActionResult Download()
        {
            if (!_techParamsService.FileExists())
            {
                return NotFound(new { success = false, message = "Файл не найден" });
            }

            try
            {
                var fileBytes = _techParamsService.GetFileBytes();
                return File(fileBytes,
                    "application/vnd.ms-excel.sheet.macroEnabled.12",
                    "tech_params.xlsm");
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = ex.Message });
            }
        }

        // API для загрузки файла (с проверкой пароля)
        [HttpPost]
        [Route("api/TechParams/upload")]
        public async Task<IActionResult> Upload(IFormFile file, [FromForm] string password)
        {
            if (password != UploadPassword)
            {
                return Unauthorized(new { success = false, message = "Неверный пароль" });
            }

            if (file == null || file.Length == 0)
            {
                return BadRequest(new { success = false, message = "Файл не выбран" });
            }

            var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
            if (extension != ".xlsm" && extension != ".xlsx" && extension != ".xls")
            {
                return BadRequest(new { success = false, message = "Допустимы только файлы Excel (.xlsx, .xlsm, .xls)" });
            }

            try
            {
                using var stream = file.OpenReadStream();
                _techParamsService.SaveData(stream);
                return Ok(new { success = true, message = "Файл успешно загружен" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { success = false, message = $"Ошибка при сохранении файла: {ex.Message}" });
            }
        }

        // API для проверки существования файла
        [HttpGet]
        [Route("api/TechParams/exists")]
        public IActionResult FileExists()
        {
            return Json(new
            {
                exists = _techParamsService.FileExists(),
                lastModified = _techParamsService.GetLastModified()?.ToString("dd.MM.yyyy HH:mm")
            });
        }
    }
}
