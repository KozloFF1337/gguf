using Microsoft.AspNetCore.Mvc;
using Altair.Services;
using ClosedXML.Excel;

namespace Altair.Controllers
{
    public class ConfigController : Controller
    {
        private readonly ILogger<ConfigController> _logger;
        private readonly IConfigValidationService _configValidationService;

        public ConfigController(ILogger<ConfigController> logger, IConfigValidationService configValidationService)
        {
            _logger = logger;
            _configValidationService = configValidationService;
        }

        [HttpGet]
        public IActionResult Download()
        {
            try
            {
                string configPath = GetConfigPath();
                if (!System.IO.File.Exists(configPath))
                {
                    _logger.LogError($"Конфигурационный файл не найден: {configPath}");
                    return NotFound("Конфигурационный файл не найден");
                }
                var fileBytes = System.IO.File.ReadAllBytes(configPath);
                var fileName = $"config_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";
                _logger.LogInformation("Пользователь скачал конфигурационный файл");
                return File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при скачивании конфигурационного файла");
                return StatusCode(500, "Ошибка при скачивании файла");
            }
        }
        private const string UploadPassword = "179846";    

        [HttpPost]
        public async Task<IActionResult> Upload(IFormFile file, string password)
        {
            try
            {
                if (string.IsNullOrEmpty(password) || password != UploadPassword)
                {
                    return Json(new { success = false, message = "Неверный пароль" });
                }

                if (file == null || file.Length == 0)
                {
                    return Json(new { success = false, message = "Файл не выбран" });
                }

                if (!file.FileName.EndsWith(".xlsx", StringComparison.OrdinalIgnoreCase))
                {
                    return Json(new { success = false, message = "Допускаются только файлы формата .xlsx" });
                }

                // Сохраняем временный файл для валидации
                var tempPath = Path.GetTempFileName() + ".xlsx";
                try
                {
                    using (var stream = new FileStream(tempPath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }

                    // Валидация файла
                    var validationResult = _configValidationService.ValidateConfigFile(tempPath);
                    if (!validationResult.IsValid)
                    {
                        return Json(new { success = false, message = validationResult.ErrorMessage });
                    }

                    // Если валидация прошла успешно, копируем файл в рабочую директорию
                    string configPath = GetConfigPath();

                    // Создаём резервную копию текущего файла
                    if (System.IO.File.Exists(configPath))
                    {
                        var backupPath = configPath.Replace(".xlsx", $"_backup_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx");
                        System.IO.File.Copy(configPath, backupPath, true);
                        _logger.LogInformation($"Создана резервная копия: {backupPath}");
                    }

                    // Копируем новый файл
                    System.IO.File.Copy(tempPath, configPath, true);
                    _logger.LogInformation($"Загружен новый конфигурационный файл: {file.FileName}");

                    // Перезагружаем конфигурацию
                    Akscodes.Reload();
                    _logger.LogInformation("Конфигурация перезагружена");

                    return Json(new { success = true, message = "Конфигурационный файл успешно загружен и применён. Все пользователи теперь видят обновлённую конфигурацию." });
                }
                finally
                {
                    // Удаляем временный файл
                    if (System.IO.File.Exists(tempPath))
                    {
                        System.IO.File.Delete(tempPath);
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при загрузке конфигурационного файла");
                return Json(new { success = false, message = $"Ошибка при загрузке файла: {ex.Message}" });
            }
        }

        private string GetConfigPath()
        {
            // Используем путь из Akscodes, который был инициализирован с ContentRootPath
            return Path.Combine(Akscodes.GetConfigPath(), "config.xlsx");
        }
    }
}
