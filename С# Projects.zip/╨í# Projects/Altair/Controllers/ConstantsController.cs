using Microsoft.AspNetCore.Mvc;
using Altair.Services;

namespace Altair.Controllers
{
    public class ConstantsController : Controller
    {
        private readonly ILogger<ConstantsController> _logger;
        private const string UploadPassword = "179846";

        public ConstantsController(ILogger<ConstantsController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        public IActionResult Download()
        {
            try
            {
                string configPath = GetConfigPath();

                if (!System.IO.File.Exists(configPath))
                {
                    _logger.LogError($"Файл констант не найден: {configPath}");
                    return NotFound("Файл констант не найден");
                }

                var fileBytes = System.IO.File.ReadAllBytes(configPath);
                var fileName = $"constants_config_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx";

                _logger.LogInformation("Пользователь скачал файл констант температур");
                return File(fileBytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при скачивании файла констант");
                return StatusCode(500, "Ошибка при скачивании файла");
            }
        }

        [HttpPost]
        public async Task<IActionResult> Upload(IFormFile file, string password)
        {
            try
            {
                if (string.IsNullOrEmpty(password) || password != UploadPassword)
                    return Json(new { success = false, message = "Неверный пароль" });

                if (file == null || file.Length == 0)
                    return Json(new { success = false, message = "Файл не выбран" });

                if (!file.FileName.EndsWith(".xlsx", StringComparison.OrdinalIgnoreCase))
                    return Json(new { success = false, message = "Допускаются только файлы формата .xlsx" });

                var tempPath = Path.GetTempFileName() + ".xlsx";
                try
                {
                    using (var stream = new FileStream(tempPath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }

                    // Валидация
                    var validation = ValidateFile(tempPath);
                    if (!validation.IsValid)
                        return Json(new { success = false, message = validation.ErrorMessage });

                    string configPath = GetConfigPath();
                    string? configDir = Path.GetDirectoryName(configPath);
                    if (configDir != null && !Directory.Exists(configDir))
                        Directory.CreateDirectory(configDir);

                    // Резервная копия
                    if (System.IO.File.Exists(configPath))
                    {
                        var backupPath = configPath.Replace(".xlsx", $"_backup_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx");
                        System.IO.File.Copy(configPath, backupPath, true);
                    }

                    System.IO.File.Copy(tempPath, configPath, true);
                    _logger.LogInformation($"Загружен новый файл констант: {file.FileName}");

                    ConstantsConfig.Reload();

                    return Json(new {
                        success = true,
                        message = $"Файл констант успешно загружен. Загружено станций: {ConstantsConfig.Values.Count}."
                    });
                }
                finally
                {
                    if (System.IO.File.Exists(tempPath))
                        System.IO.File.Delete(tempPath);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Ошибка при загрузке файла констант");
                return Json(new { success = false, message = $"Ошибка: {ex.Message}" });
            }
        }

        private string GetConfigPath()
        {
            return Path.Combine(ConstantsConfig.GetConfigPath(), "constants_config.xlsx");
        }

        private (bool IsValid, string ErrorMessage) ValidateFile(string filePath)
        {
            try
            {
                using (var workbook = new ClosedXML.Excel.XLWorkbook(filePath))
                {
                    int validSheets = 0;
                    foreach (var worksheet in workbook.Worksheets)
                    {
                        if (worksheet.Name == "Инструкция") continue;
                        if (worksheet.Name.Length < 2) continue;
                        if (!int.TryParse(worksheet.Name.Substring(0, 2), out _)) continue;

                        int lastRow = worksheet.LastRowUsed()?.RowNumber() ?? 0;
                        for (int row = 1; row <= lastRow; row++)
                        {
                            string cellA = worksheet.Cell(row, 1).GetString().Trim();
                            if (cellA == "КОНСТАНТЫ_КОТЛЫ") { validSheets++; break; }
                        }
                    }

                    if (validSheets == 0)
                        return (false, "Файл не содержит валидных листов. Убедитесь, что листы начинаются с кода станции и содержат секцию КОНСТАНТЫ_КОТЛЫ.");

                    return (true, $"Найдено {validSheets} станций.");
                }
            }
            catch (Exception ex)
            {
                return (false, $"Ошибка при чтении файла: {ex.Message}");
            }
        }
    }
}
