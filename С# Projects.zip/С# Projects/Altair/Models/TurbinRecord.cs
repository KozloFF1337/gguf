using System;

namespace Altair.Models
{
    public class TurbinRecord
    {
        public int StationID { get; set; }
        public string TurbinID { get; set; } = string.Empty;
        public double URT { get; set; }
        public double Consumption { get; set; }
        public double Hours { get; set; }
        public DateTime Date { get; set; }
    }
}
