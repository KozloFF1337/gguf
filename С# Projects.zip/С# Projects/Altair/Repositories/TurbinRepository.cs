using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;
using Microsoft.EntityFrameworkCore;

public class TurbinRepository : ITurbinRepository
{
    private readonly DbContext _context;
    public TurbinRepository(DbContext context)
    {
        _context = context;
    }
    public async Task<List<Turbin>> GetTurbins(PeriodType periodType, int periodValue)
    {
        return await _context.Set<Turbin>()
            .Where(t => t.PeriodType == periodType && t.PeriodValue == periodValue)
            .ToListAsync();
    }
}
