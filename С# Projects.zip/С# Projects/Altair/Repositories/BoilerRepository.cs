using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;
using Microsoft.EntityFrameworkCore;

public class BoilerRepository : IBoilerRepository
{
    private readonly DbContext _context;
    public BoilerRepository(DbContext context)
    {
        _context = context;
    }
    public async Task<List<Boiler>> GetBoilers(PeriodType periodType, int periodValue)
    {
        return await _context.Set<Boiler>()
            .Where(b => b.PeriodType == periodType && b.PeriodValue == periodValue)
            .ToListAsync();
    }
}
