using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Altair.Models;

namespace Altair.Data
{
    public class TurbinConfig : IEntityTypeConfiguration<Turbin>
    {
        public void Configure(EntityTypeBuilder<Turbin> builder)
        {
            builder.HasKey(t => t.Id);
            builder.Property(t => t.StationID).IsRequired();
            builder.Property(t => t.TurbinID).IsRequired();
            builder.Property(t => t.PeriodType).IsRequired();
            builder.Property(t => t.PeriodValue).IsRequired();
            builder.Property(t => t.URT).IsRequired();
            builder.Property(t => t.Consumption).IsRequired();
            // Добавьте остальные нужные поля
        }
    }
}
