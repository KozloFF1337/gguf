using Microsoft.EntityFrameworkCore;
using Altair.Models;

namespace Altair.Data
{
    public class BoilerDbContext : DbContext
    {
        public BoilerDbContext(DbContextOptions<BoilerDbContext> options) : base(options) { }

        public DbSet<Boiler> Boilers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new BoilerConfig());
        }
    }
}
