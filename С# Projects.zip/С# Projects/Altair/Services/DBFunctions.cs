using Microsoft.Data.SqlClient;
using Npgsql;

public static class DBFunctions
{
    public static string Correct(int x)
    {
        if (x < 10)
            return "0" + x;
        else
            return x.ToString();
    }

    public static void GenerateDB_KA(BoilerRecord rec_KA, Dictionary<int, List<string>> matching_dict_KA, string insertQuerry_KA, string format, NpgsqlConnection connection1, SqlConnection connection)
    {
        foreach (var dic in matching_dict_KA)
        {
            foreach (string code in dic.Value)
            {
                string sql_start = $"exec dbo.p_GetParamValuePivot '{Correct(dic.Key)}','Основная', ";
                string sql_end = ", '2025-07-01 00:00:00',  '2025-07-30 00:00:00',  'Сутки';";
                rec_KA.StationID = short.Parse(code.Substring(11, 2));
                rec_KA.BoilerID = code.Substring(1, 2) + ((code[9] == '0') ? "" : code[9].ToString());
                rec_KA.BoilerID.Replace('A', 'А');
                rec_KA.BoilerID.Replace('B', 'Б');
                string a = sql_start + code + sql_end;
                SqlCommand command = new SqlCommand(a, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    rec_KA.Date = DateTime.ParseExact(reader[0].ToString().Substring(0, 10), format, null);
                    rec_KA.Consumption = Math.Round(double.Parse(reader[1].ToString()), 3);
                    rec_KA.KPD = Math.Round(double.Parse(reader[2].ToString()), 3);
                    rec_KA.Production = Math.Round(double.Parse(reader[3].ToString()), 3);
                    rec_KA.Hours = double.Parse(reader[4].ToString());
                    using (var insertCommand = new NpgsqlCommand(insertQuerry_KA, connection1))
                    {
                        insertCommand.Parameters.AddWithValue("@BoilerID", rec_KA.BoilerID);
                        insertCommand.Parameters.AddWithValue("@StationID", rec_KA.StationID);
                        insertCommand.Parameters.AddWithValue("@Production", rec_KA.Production);
                        insertCommand.Parameters.AddWithValue("@KPD", rec_KA.KPD);
                        insertCommand.Parameters.AddWithValue("@Date", rec_KA.Date);
                        insertCommand.Parameters.AddWithValue("@Consumption", rec_KA.Consumption);
                        insertCommand.Parameters.AddWithValue("@Hours", (int)rec_KA.Hours);
                        insertCommand.ExecuteNonQuery();
                    }
                }
                reader.Close();
            }
        }
    }

    public static void GenerateDB_TA(TurbinRecord rec_TA, Dictionary<int, List<string>> matching_dict_TA, string insertQuerry_TA, string format, NpgsqlConnection connection1, SqlConnection connection)
    {
        foreach (var dic in matching_dict_TA)
        {
            foreach (string code in dic.Value)
            {
                string sql_start = $"exec dbo.p_GetParamValuePivot '{Correct(dic.Key)}','Основная', ";
                string sql_end = ", '2025-07-01 00:00:00',  '2025-07-30 00:00:00',  'Сутки';";
                rec_TA.StationID = short.Parse(code.Substring(11, 2));
                rec_TA.TurbinID = code.Substring(1, 2) + ((code[9] == '0') ? "" : code[9].ToString());
                rec_TA.TurbinID.Replace('A', 'А');
                rec_TA.TurbinID.Replace('B', 'Б');
                string a = sql_start + code + sql_end;
                SqlCommand command = new SqlCommand(a, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    rec_TA.Date = DateTime.ParseExact(reader[0].ToString().Substring(0, 10), format, null);
                    rec_TA.URT = Math.Round(double.Parse(reader[1].ToString()), 3);
                    rec_TA.Consumption = Math.Round(double.Parse(reader[2].ToString()), 3);
                    rec_TA.Hours = double.Parse(reader[3].ToString());
                    using (var insertCommand = new NpgsqlCommand(insertQuerry_TA, connection1))
                    {
                        insertCommand.Parameters.AddWithValue("@TurbinID", rec_TA.TurbinID);
                        insertCommand.Parameters.AddWithValue("@StationID", rec_TA.StationID);
                        insertCommand.Parameters.AddWithValue("@URT", rec_TA.URT);
                        insertCommand.Parameters.AddWithValue("@Date", rec_TA.Date);
                        insertCommand.Parameters.AddWithValue("@Consumption", rec_TA.Consumption);
                        insertCommand.Parameters.AddWithValue("@Hours", (int)rec_TA.Hours);
                        insertCommand.ExecuteNonQuery();
                    }
                }
                reader.Close();
            }
        }
    }

    public static void GetRelevantData_TA(WeekTurbin rec_WT, List<WeekTurbin> weekTurbins, string select_TA, NpgsqlConnection connection1, SqlConnection connection)
    {
        int temp_stationid = 0;
        string temp_turbinid = "0";
        double sum_cons = 0;
        double sum_multi_urt_cons = 0;
        double last_consumption = 0;
        DateTime temp_dt = new DateTime(2000, 1, 1);
        using (var command = new NpgsqlCommand(select_TA, connection1))
        {
            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (temp_stationid == reader.GetInt32(reader.GetOrdinal("stationID")) && temp_turbinid == reader.GetString(reader.GetOrdinal("turbinID")))
                    {
                        sum_cons += reader.GetDouble(reader.GetOrdinal("consumption"));
                        sum_multi_urt_cons += reader.GetDouble(reader.GetOrdinal("URT")) * reader.GetDouble(reader.GetOrdinal("consumption"));
                        last_consumption = reader.GetDouble(reader.GetOrdinal("consumption"));
                        temp_dt = reader.GetDateTime(reader.GetOrdinal("date"));
                    }
                    else
                    {
                        if (DateTime.Now.AddDays(-7).Date <= temp_dt.Date)
                        {
                            rec_WT.turbinID = temp_turbinid;
                            rec_WT.stationID = temp_stationid;
                            rec_WT.URT = (sum_multi_urt_cons / sum_cons);
                            rec_WT.Consumption = last_consumption;
                        }
                        weekTurbins.Add(rec_WT);
                        rec_WT = new WeekTurbin();
                        temp_stationid = reader.GetInt32(reader.GetOrdinal("stationID"));
                        temp_turbinid = reader.GetString(reader.GetOrdinal("turbinID"));
                        sum_cons = reader.GetDouble(reader.GetOrdinal("consumption"));
                        sum_multi_urt_cons = reader.GetDouble(reader.GetOrdinal("URT")) * reader.GetDouble(reader.GetOrdinal("consumption"));
                        last_consumption = reader.GetDouble(reader.GetOrdinal("consumption"));
                        temp_dt = reader.GetDateTime(reader.GetOrdinal("date"));
                    }
                }
            }
        }
        weekTurbins.RemoveAt(0);
    }

    public static void GetRelevantData_KA(WeekBoiler rec_WB, List<WeekBoiler> weekBoilers, string select_KA, NpgsqlConnection connection1, SqlConnection connection)
    {
        int temp_stationid = 0;
        string temp_boilerid = "0";
        double sum_multi_kpd_cons = 0;
        double last_production = 0;
        double sum_cons = 0;

        DateTime temp_dt = new DateTime(2000, 1, 1);
        using (var command = new NpgsqlCommand(select_KA, connection1))
        {
            using (var reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (temp_stationid == reader.GetInt32(reader.GetOrdinal("stationID")) && temp_boilerid == reader.GetString(reader.GetOrdinal("boilerID")))
                    {
                        sum_cons += reader.GetDouble(reader.GetOrdinal("consumption"));
                        sum_multi_kpd_cons += reader.GetDouble(reader.GetOrdinal("KPD")) * reader.GetDouble(reader.GetOrdinal("consumption"));
                        last_production = reader.GetDouble(reader.GetOrdinal("production"));
                        temp_dt = reader.GetDateTime(reader.GetOrdinal("date"));
                    }
                    else
                    {
                        if (DateTime.Now.AddDays(-7).Date <= temp_dt.Date)
                        {
                            rec_WB.BoilerID = temp_boilerid;
                            rec_WB.StationID = temp_stationid;
                            rec_WB.KPD = (sum_multi_kpd_cons / sum_cons);
                            rec_WB.Production = last_production;
                        }
                        weekBoilers.Add(rec_WB);
                        rec_WB = new WeekBoiler();
                        temp_stationid = reader.GetInt32(reader.GetOrdinal("stationID"));
                        temp_boilerid = reader.GetString(reader.GetOrdinal("boilerID"));
                        sum_cons = reader.GetDouble(reader.GetOrdinal("consumption"));
                        sum_multi_kpd_cons = reader.GetDouble(reader.GetOrdinal("KPD")) * reader.GetDouble(reader.GetOrdinal("consumption"));
                        last_production = reader.GetDouble(reader.GetOrdinal("production"));
                        temp_dt = reader.GetDateTime(reader.GetOrdinal("date"));
                    }
                }
            }
            
        }
        weekBoilers.RemoveAt(0);
    }

    public static void InsertFinalData_TA(string truncate_week_TA, string insertQuerry_week_TA, List<WeekTurbin> weekTurbins, NpgsqlConnection connection1)
    {
        using (var trunc = new NpgsqlCommand(truncate_week_TA, connection1))
        {
            trunc.ExecuteNonQuery();
        }
        foreach (var WT in weekTurbins)
        {
            using (var week_ins = new NpgsqlCommand(insertQuerry_week_TA, connection1))
            {
                week_ins.Parameters.AddWithValue("@TurbinID", WT.turbinID);
                week_ins.Parameters.AddWithValue("@StationID", WT.stationID);
                week_ins.Parameters.AddWithValue("@URT", WT.URT);
                week_ins.Parameters.AddWithValue("@Consumption", WT.Consumption);
                week_ins.ExecuteNonQuery();
            }
        }
    }

    public static void InsertFinalData_KA(string truncate_week_KA, string insertQuerry_week_KA, List<WeekBoiler> weekBoilers, NpgsqlConnection connection1)
    {
        using (var trunc = new NpgsqlCommand(truncate_week_KA, connection1))
        {
            trunc.ExecuteNonQuery();
        }
        foreach (var WB in weekBoilers)
        {
            using (var week_ins = new NpgsqlCommand(insertQuerry_week_KA, connection1))
            {
                week_ins.Parameters.AddWithValue("@BoilerID", WB.BoilerID);
                week_ins.Parameters.AddWithValue("@StationID", WB.StationID);
                week_ins.Parameters.AddWithValue("@KPD", WB.KPD);
                week_ins.Parameters.AddWithValue("@Production", WB.Production);
                week_ins.ExecuteNonQuery();
            }
        }
    }
}
