using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;

public class DataService : IDataService
{
    private readonly IBoilerRepository _boilerRepository;
    private readonly ITurbinRepository _turbinRepository;
    private readonly IHomePageRepository _homePageRepository;
    public DataService(IBoilerRepository boilerRepository, ITurbinRepository turbinRepository, IHomePageRepository homePageRepository)
    {
        _boilerRepository = boilerRepository;
        _turbinRepository = turbinRepository;
        _homePageRepository = homePageRepository;
    }
    public async Task<List<Boiler>> GetBoilers(PeriodType periodType, int periodValue)
    {
        return await _boilerRepository.GetBoilers(periodType, periodValue);
    }
    public async Task<List<Turbin>> GetTurbins(PeriodType periodType, int periodValue)
    {
        return await _turbinRepository.GetTurbins(periodType, periodValue);
    }
    public async Task<HomePage> GetHomePageData()
    {
        var homePages = await _homePageRepository.Get();
        return homePages?.Count > 0 ? homePages[0] : null;
    }
}
