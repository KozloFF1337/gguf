using Altair;
using Microsoft.EntityFrameworkCore;
using Altair.Models;
using Microsoft.Data.SqlClient;
using Altair.Controllers;
using Microsoft.AspNetCore.Connections;
using Npgsql;
using Altair.Services;
using Altair.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Универсальные репозитории и сервисы
builder.Services.AddScoped<IBoilerRepository, BoilerRepository>();
builder.Services.AddScoped<ITurbinRepository, TurbinRepository>();
builder.Services.AddScoped<IHomePageRepository, HomePageRepository>();
builder.Services.AddScoped<IDataService, DataService>();
builder.Services.AddScoped<IHomePageService, HomePageService>();

builder.Services.AddDbContext<BoilerDbContext>(options => 
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddDbContext<TurbinDbContext>(options => 
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddDbContext<HomePageDBContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run("http://10.251.0.149:5000");