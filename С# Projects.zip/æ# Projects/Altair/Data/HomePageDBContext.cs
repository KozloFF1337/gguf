using Altair.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

public class HomePageDBContext : DbContext
{
    public HomePageDBContext(DbContextOptions<HomePageDBContext> options) : base(options) { }

    public DbSet<HomePageEntity> HomePages { get; set; }
}