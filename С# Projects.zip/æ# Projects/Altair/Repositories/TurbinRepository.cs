using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;
using Microsoft.EntityFrameworkCore;

using Altair.Data;
public class TurbinRepository : ITurbinRepository
{
    private readonly TurbinDbContext _context;
    public TurbinRepository(TurbinDbContext context)
    {
        _context = context;
    }
    public async Task<List<Turbin>> GetTurbins(PeriodType periodType)
    {
        return await _context.Set<Turbin>()
            .Where(t => t.PeriodType == periodType)
            .ToListAsync();
    }
}
