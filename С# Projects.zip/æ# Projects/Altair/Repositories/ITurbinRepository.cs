using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;

public interface ITurbinRepository
{
    Task<List<Turbin>> GetTurbins(PeriodType periodType);
}
