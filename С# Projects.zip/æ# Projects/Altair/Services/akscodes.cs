
using Altair.Models;
public static class Akscodes
{
    //akscode пример 01K000GBAD25 первые две, 9 и 10 отвечают за номер котла "01" и "AD" (котел 01A, для "01" и "BD" котел будет 01B, для "01" и "00" котел будет 01)
    //akscode для станции Рефтинская ГРЭС
    public static List<string> aks_codes_KA_25 = new List<string>() {"'01K000GBAD25,01K000KJAD25,01K000SQAD25,01K000LHAD25'",
                                                    "'01K000GBBD25,01K000KJBD25,01K000SQBD25,01K000LHBD25'",
                                                    "'02K000GBAD25,02K000KJAD25,02K000SQAD25,02K000LHAD25'",
                                                    "'02K000GBBD25,02K000KJBD25,02K000SQBD25,02K000LHBD25'",
                                                    "'03K000GBAD25,03K000KJAD25,03K000SQAD25,03K000LHAD25'",
                                                    "'03K000GBBD25,03K000KJBD25,03K000SQBD25,03K000LHBD25'",
                                                    "'04K000GBAD25,04K000KJAD25,04K000SQAD25,04K000LHAD25'",
                                                    "'04K000GBBD25,04K000KJBD25,04K000SQBD25,04K000LHBD25'",
                                                    "'05K000GBAD25,05K000KJAD25,05K000SQAD25,05K000LHAD25'",
                                                    "'05K000GBBD25,05K000KJBD25,05K000SQBD25,05K000LHBD25'",
                                                    "'06K000GBAD25,06K000KJAD25,06K000SQAD25,06K000LHAD25'",
                                                    "'06K000GBBD25,06K000KJBD25,06K000SQBD25,06K000LHBD25'",
                                                    "'07K000GB0C25,07K000KJ0C25,07K000SQ0C25,07K000LH0C25'",
                                                    "'08K000GB0C25,08K000KJ0C25,08K000SQ0C25,08K000LH0C25'",
                                                    "'09K000GB0C25,09K000KJ0C25,09K000SQ0C25,09K000LH0C25'",
                                                    "'10K000GB0C25,10K000KJ0C25,10K000SQ0C25,10K000LH0C25'", };
    public static List<string> aks_codes_TA_25 = new List<string>() {"'01T000DU0D25,01T000DD0D25,01T000LH0D25'",
                                                    "'02T000DU0D25,02T000DD0D25,02T000LH0D25'",
                                                    "'03T000DU0D25,03T000DD0D25,03T000LH0D25'",
                                                    "'04T000DU0D25,04T000DD0D25,04T000LH0D25'",
                                                    "'05T000DU0D25,05T000DD0D25,05T000LH0D25'",
                                                    "'06T000DU0D25,06T000DD0D25,06T000LH0D25'",
                                                    "'07T000DU0C25,07T000DD0C25,07T000LH0C25'",
                                                    "'08T000DU0C25,08T000DD0C25,08T000LH0C25'",
                                                    "'09T000DU0C25,09T000DD0C25,09T000LH0C25'",
                                                    "'10T000DU0C25,10T000DD0C25,10T000LH0C25'" };
    //akscode для станции Томь-Усинская ГРЭС
    public static List<string> aks_codes_KA_09 = new List<string>() {"'01K000GB0009,01K000KJ0009,01K000SQ0909,01K000LH0009'",
                        "'02K000GB0009,02K000KJ0009,02K000SQ0909,02K000LH0009'",
                        "'03K000GB0009,03K000KJ0009,03K000SQ0909,03K000LH0009'",
                        "'04K000GB0009,04K000KJ0009,04K000SQ0909,04K000LH0009'",
                        "'05K000GB0009,05K000KJ0009,05K000SQ0909,05K000LH0009'",
                        "'06K000GB0009,06K000KJ0009,06K000SQ0909,06K000LH0009'",
                        "'07K000GB0009,07K000KJ0009,07K000SQ0909,07K000LH0009'",
                        "'08K000GB0009,08K000KJ0009,08K000SQ0909,08K000LH0009'",
                        "'09K000GB0009,09K000KJ0009,09K000SQ0909,09K000LH0009'",
                        "'10K000GB0009,10K000KJ0009,10K000SQ0909,10K000LH0009'",
                        "'11K000GB0009,11K000KJ0009,11K000SQ0909,11K000LH0009'",
                        "'12K000GB0009,12K000KJ0009,12K000SQ0909,12K000LH0009'",
                        "'13K000GB0A09,13K000KJ0A09,13K000SQIA09,13K000LH0A09'",
                        "'13K000GB0B09,13K000KJ0B09,13K000SQIB09,13K000LH0B09'",
                        "'14K000GB0A09,14K000KJ0A09,14K000SQIA09,14K000LH0A09'",
                        "'14K000GB0B09,14K000KJ0B09,14K000SQIB09,14K000LH0B09'"};
    public static List<string> aks_codes_TA_09 = new List<string>() { "'01T010DU0009,01T000DD0009,01T000LH0009'",
                                                    "'02T010DU0009,02T000DD0009,02T000LH0009'",
                                                    "'03T010DU0009,03T000DD0009,03T000LH0009'",
                                                    "'04T010DU0009,04T000DD0009,04T000LH0009'",
                                                    "'05T010DU0009,05T000DD0009,05T000LH0009'",
                                                    "'06T010DU0009,06T000DD0009,06T000LH0009'",
                                                    "'07T010DU0009,07T000DD0009,07T000LH0009'",
                                                    "'08T010DU0009,08T000DD0009,08T000LH0009'",
                                                    "'09T010DU0009,09T000DD0009,09T000LH0009'"};
    //akscode для станции Беловская ГРЭС    
    public static List<string> aks_codes_KA_15 = new List<string>() {"'01S000GBA015,01K000KJA015,01K000SQA015,01K000LHB015'",
                        "'01S000GBB015,01K000KJB015,01K000SQB015,01K000LHB015'",
                        "'02S000GBA015,02K000KJA015,02K000SQA015,02K000LHA015'",
                        "'02S000GBB015,02K000KJB015,02K000SQB015,02K000LHB015'",
                        "'03S000GBA015,03K000KJA015,03K000SQA015,03K000LHA015'",
                        "'03S000GBB015,03K000KJB015,03K000SQB015,03K000LHB015'",
                        "'04S000GBA015,04K000KJA015,04K000SQA015,04K000LHA015'",
                        "'04S000GBB015,04K000KJB015,04K000SQB015,04K000LHB015'",
                        "'05S000GBA015,05K000KJA015,05K000SQA015,05K000LHA015'",
                        "'05S000GBB015,05K000KJB015,05K000SQB015,05K000LHB015'",
                        "'06S000GBA015,06K000KJA015,06K000SQA015,06K000LHA015'",
                        "'06S000GBB015,06K000KJB015,06K000SQB015,06K000LHB015'"};
    public static List<string> aks_codes_TA_15 = new List<string>() {"'01T000DU0015,01T000DD0015,01T000LH0015'",
                                                    "'02T000DU0015,02T000DD0015,02T000LH0015'",
                                                    "'03T000DU0015,03T000DD0015,03T000LH0015'",
                                                    "'04T000DU0015,04T000DD0015,04T000LH0015'",
                                                    "'05T000DU0015,05T000DD0015,05T000LH0015'",
                                                    "'06T000DU0015,06T000DD0015,06T000LH0015'"};
    //akscode для станции Назаровская ГРЭС
    public static List<string> aks_codes_KA_01 = new List<string>() {"'01K000GBAI01,01K000KJAI01,01K000SQAI01,01K000LHAI01'",
                        "'01K000GBBI01,01K000KJBI01,01K000SQBI01,01K000LHBI01'",
                        "'02K000GBAI01,02K000KJAI01,02K000SQAI01,02K000LHAI01'",
                        "'02K000GBBI01,02K000KJBI01,02K000SQBI01,02K000LHBI01'",
                        "'03K000GBAI01,03K000KJAI01,03K000SQAI01,03K000LHAI01'",
                        "'03K000GBBI01,03K000KJBI01,03K000SQBI01,03K000LHBI01'",
                        "'04K000GBAI01,04K000KJAI01,04K000SQAI01,04K000LHAI01'",
                        "'04K000GBBI01,04K000KJBI01,04K000SQBI01,04K000LHBI01'",
                        "'05K000GBAI01,05K000KJAI01,05K000SQAI01,05K000LHAI01'",
                        "'05K000GBBI01,05K000KJBI01,05K000SQBI01,05K000LHBI01'",
                        "'06K000GBAI01,06K000KJAI01,06K000SQAI01,06K000LHAI01'",
                        "'06K000GBBI01,06K000KJBI01,06K000SQBI01,06K000LHBI01'",
                        "'07K000SQAC01,07K000KJAC01,07K000GBAC01,07K000LHAC01'",
                        "'07K000SQBC01,07K000KJBC01,07K000GBBC01,07K000LHBC01'",};
    public static List<string> aks_codes_TA_01 = new List<string>() {"'01T000DU0I01,01T000DD0I01,01T000LH0I01'",
                                                    "'02T000DU0I01,02T000DD0I01,02T000LH0I01'",
                                                    "'03T000DU0I01,03T000DD0I01,03T000LH0I01'",
                                                    "'04T000DU0I01,04T000DD0I01,04T000LH0I01'",
                                                    "'05T000DU0I01,05T000DD0I01,05T000LH0I01'",
                                                    "'06T000DU0I01,06T000DD0I01,06T000LH0I01'",
                                                    "'07T000DU0C01,07T000DD0C01,07T000LH0C01'" };
    //akscode для станции Красноярская ГРЭС-2
    public static List<string> aks_codes_KA_24 = new List<string>() {"'01K000GBAF24,01K000KJAF24,01K000SQAF24,01K000LHAF24'",
                        "'01K000GBBF24,01K000KJBF24,01K000SQBF24,01K000LHBF24'",
                        "'02K000GBAF24,02K000KJAF24,02K000SQAF24,02K000LHAF24'",
                        "'02K000GBBF24,02K000KJBF24,02K000SQBF24,02K000LHBF24'",
                        "'04K000GBAF24,04K000KJAF24,04K000SQAF24,04K000LHAF24'",
                        "'04K000GBBF24,04K000KJBF24,04K000SQBF24,04K000LHBF24'",
                        "'05K000GBAN24,05K000KJAN24,05K000SQAN24,05K000LHAN24'",
                        "'05K000GBBN24,05K000KJBN24,05K000SQBN24,05K000LHBN24'",
                        "'06K000GBAF24,06K000KJAF24,06K000SQAF24,06K000LHAF24'",
                        "'06K000GBBF24,06K000KJBF24,06K000SQBF24,06K000LHBF24'",
                        "'07K000GBAF24,07K000KJAF24,07K000SQAF24,07K000LHAF24'",
                        "'07K000GBBF24,07K000KJBF24,07K000SQBF24,07K000LHBF24'",
                        "'08K000GBAF24,08K000KJAF24,08K000SQAF24,08K000LHAF24'",
                        "'08K000GBBF24,08K000KJBF24,08K000SQBF24,08K000LHBF24'",
                        "'09K000GBAL24,09K000KJAL24,09K000SQAL24,09K000LHAL24'",
                        "'09K000GBBL24,09K000KJBL24,09K000SQBL24,09K000LHBL24'",
                        "'10K000GBAL24,10K000KJAL24,10K000SQAL24,10K000LHAL24'",
                        "'10K000GBBL24,10K000KJBL24,10K000SQBL24,10K000LHBL24'"};
    public static List<string> aks_codes_TA_24 = new List<string>() {"'01T000DU0F24,01T000DD0F24,01T000LH0F24'",
                                                    "'02T000DU0F24,02T000DD0F24,02T000LH0F24'",
                                                    "'04T000DU0F24,04T000DD0F24,04T000LH0F24'",
                                                    "'05T000DU0N24,05T000DD0N24,05T000LH0N24'",
                                                    "'06T000DU0F24,06T000DD0F24,06T000LH0F24'",
                                                    "'07T000DU0F24,07T000DD0F24,07T000LH0F24'",
                                                    "'08T000DU0F24,08T000DD0F24,08T000LH0F24'",
                                                    "'09T000DU0L24,09T000DD0L24,09T000LH0L24'",
                                                    "'10T000DU0L24,10T000DD0L24,10T000LH0L24'" };
    //akscode для станции Приморская ГРЭС
    public static List<string> aks_codes_KA_26 = new List<string>() {"'01K000GBAN26,01K000KJAN26,01K040SQAN26,01K000LHAN26'",
                        "'01K000GBBN26,01K000KJBN26,01K040SQBN26,01K000LHBN26'",
                        "'02K000GBAN26,02K000KJAN26,02K040SQAN26,02K000LHAN26'",
                        "'02K000GBBN26,02K000KJBN26,02K040SQBN26,02K000LHBN26'",
                        "'03K000GBAN26,03K000KJAN26,03K040SQAN26,03K000LHAN26'",
                        "'03K000GBBN26,03K000KJBN26,03K040SQBN26,03K000LHBN26'",
                        "'04K000GBAN26,04K000KJAN26,04K040SQAN26,04K000LHAN26'",
                        "'04K000GBBN26,04K000KJBN26,04K040SQBN26,04K000LHBN26'",
                        "'05K000GB0L26,05K000KJ0L26,05K040SQ0L26,05K000LH0L26'",
                        "'06K000GB0L26,06K000KJ0L26,06K040SQ0L26,06K000LH0L26'",
                        "'07K000GB0L26,07K000KJ0L26,07K040SQ0L26,07K000LH0L26'",
                        "'08K000GB0L26,08K000KJ0L26,08K040SQ0L26,08K000LH0L26'",
                        "'09K000GB0L26,09K000KJ0L26,09K040SQ0L26,09K000LH0L26'"};
    public static List<string> aks_codes_TA_26 = new List<string>() {"'01T000DU0N26,01T000DD0N26,01T000LH0N26'",
                                                    "'02T000DU0N26,02T000DD0N26,02T000LH0N26'",
                                                    "'03T000DU0N26,03T000DD0N26,03T000LH0N26'",
                                                    "'04T000DU0N26,04T000DD0N26,04T000LH0N26'",
                                                    "'05T000DU0L26,05T000DD0L26,05T000LH0L26'",
                                                    "'06T000DU0L26,06T000DD0L26,06T000LH0L26'",
                                                    "'07T000DU0L26,07T000DD0L26,07T000LH0L26'",
                                                    "'08T000DU0L26,08T000DD0L26,08T000LH0L26'",
                                                    "'09T000DU0L26,09T000DD0L26,09T000LH0L26'" };
    //akscode для станции Кемеровская ГРЭС
    public static string[] aks_codes_05 =  {"'03K030SQ0005,03K000KJ0005'",
                        "'04K030SQ0005,04K000KJ0005'",
                        "'06K030SQ0005,06K000KJ0005'",
                        "'08K030SQ0005,08K000KJ0005'",
                        "'09K030SQ0005,09K000KJ0005'",
                        "'10K030SQ0005,10K000KJ0005'",
                        "'11K030SQ0005,11K000KJ0005'",
                        "'12K030SQ0005,12K000KJ0005'",
                        "'13K030SQ0005,13K000KJ0005'",
                        "'14K030SQ0005,14K000KJ0005'",
                        "'15K030SQ0005,15K000KJ0005'",
                        "'16K030SQ0005,16K000KJ0005'"};

    public static Dictionary<int, List<string>> matching_dict_KA = new Dictionary<int, List<string>>() { { 25, aks_codes_KA_25 }, { 9, aks_codes_KA_09 }, { 15, aks_codes_KA_15 }, { 1, aks_codes_KA_01 }, { 24, aks_codes_KA_24 }, { 26, aks_codes_KA_26 } };
    public static Dictionary<int, List<string>> matching_dict_TA = new Dictionary<int, List<string>>() { { 25, aks_codes_TA_25 }, { 9, aks_codes_TA_09 }, { 15, aks_codes_TA_15 }, { 1, aks_codes_TA_01 }, { 24, aks_codes_TA_24 }, { 26, aks_codes_TA_26 } };

    public static BoilerRecord rec_KA = new BoilerRecord();
    public static TurbinRecord rec_TA = new TurbinRecord();
    public static Turbin rec_WT = new Turbin();
    public static Boiler rec_WB = new Boiler();
    public static List<Turbin> weekTurbins = new List<Turbin>();
    public static List<Boiler> weekBoilers = new List<Boiler>(); 
}