﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Altair.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Boilers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    StationID = table.Column<int>(type: "integer", nullable: false),
                    BoilerID = table.Column<string>(type: "text", nullable: false),
                    PeriodType = table.Column<int>(type: "integer", nullable: false),
                    PeriodValue = table.Column<int>(type: "integer", nullable: false),
                    KPD = table.Column<double>(type: "double precision", nullable: false),
                    Production = table.Column<double>(type: "double precision", nullable: false),
                    Consumption = table.Column<double>(type: "double precision", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Boilers", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Boilers");
        }
    }
}
