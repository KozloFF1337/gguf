namespace Altair.Models
{
    public class HomeIndexViewModel
    {
        public HomePage HomePage { get; set; }
        public List<Boiler> Boilers { get; set; }
        public List<Turbin> Turbines { get; set; }
    }
}
