using System.Collections.Generic;
using Altair.Models;

namespace Altair.Models
{
    // ViewModel для страницы визуализации
    public class VisualisationViewModel
    {
        public List<Boiler>? Boilers { get; set; }
        public List<Turbin>? Turbins { get; set; }
        public PeriodType? SelectedPeriod { get; set; }
        public string? ChartTitle { get; set; }
        // Добавьте дополнительные свойства для визуализации, если нужно
    }
}
