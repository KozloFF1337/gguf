using System;

namespace Altair.Models
{
    public class BoilerRecord
    {
        public int StationID { get; set; }
        public string BoilerID { get; set; } = string.Empty;
        public double KPD { get; set; }
        public double Production { get; set; }
        public double Consumption { get; set; }
        public double Hours { get; set; }
        public DateTime Date { get; set; }
    }
}
