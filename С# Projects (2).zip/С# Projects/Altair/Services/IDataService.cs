using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;

public interface IDataService
{
    Task<List<Boiler>> GetBoilers(PeriodType periodType, int periodValue);
    Task<List<Turbin>> GetTurbins(PeriodType periodType, int periodValue);
    Task<HomePage> GetHomePageData();
}
