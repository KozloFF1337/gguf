# 📊 Интеграция TestConsole в Altair

## ✅ Выполненные работы:

### 1. **Сервис загрузки данных** (`Services/DBLoadService.cs`)
   - Создан новый `IDBLoadService` интерфейс с методами:
     - `ExecuteFullLoadAsync()` - полная загрузка всех данных
     - `LoadBoilersAsync()` - загрузка данных котлов
     - `LoadTurbinesAsync()` - загрузка данных турбин
   
   - Реализованы асинхронные методы:
     - `GenerateDB_KA()` - загрузка котлов из SQL Server → PostgreSQL
     - `GenerateDB_TA()` - загрузка турбин из SQL Server → PostgreSQL
     - Вспомогательные методы для недельных и месячных данных

### 2. **Контроллер управления** (`Controllers/DataLoadController.cs`)
   - Три POST endpoints:
     - `/DataLoad/LoadData` - загрузить все данные
     - `/DataLoad/LoadBoilers` - загрузить котлы
     - `/DataLoad/LoadTurbines` - загрузить турбины
   
   - JSON ответы с статусом успеха/ошибки

### 3. **Расширенные модели**
   - `BoilerRecord.cs` - добавлены поля: `humidity`, `ash`, `temp_fact`, `temp_nominal`, `temp_koef`
   - `TurbinRecord.cs` - добавлены поля: `variation`, `NominalURT`

### 4. **UI с кнопками загрузки** (в `Views/Home/Index.cshtml`)
   - 3 кнопки для управления загрузкой:
     - ⚡ **Загрузить все данные** - полная загрузка
     - 🔥 **Загрузить котлы** - только котлы
     - ⚙️ **Загрузить турбины** - только турбины
   
   - Статус-блок с:
     - Индикатором загрузки
     - Сообщениями об успехе/ошибке
     - Автоматическим скрытием через 5 сек

### 5. **Регистрация в DI контейнере** (в `Program.cs`)
   ```csharp
   builder.Services.AddScoped<IDBLoadService, DBLoadService>();
   ```

## 🔌 Подключение к БД:

- **SQL Server** (ASTEPSGKID): `KMR-S-APP-TEP3.CORP.SUEK.RU`
- **PostgreSQL** (ASTEP_RES): `localhost:5432`

Используются строки подключения из `appsettings.json`:
- `DefaultConnection` - PostgreSQL
- `ASTEPConnection` - SQL Server

## 📝 Использование:

1. На главной странице (`/Home/Index`) появятся 3 кнопки
2. Нажимаете нужную кнопку
3. Отправляется POST запрос на сервер
4. Сервер загружает данные из SQL Server в PostgreSQL
5. Отображается сообщение об успехе/ошибке

## 🔄 Процесс загрузки:

1. Подключение к обеим БД
2. Извлечение AKS кодов параметров
3. Выполнение хранимой процедуры `p_GetParamValuePivot` в SQL Server
4. Парсинг данных (преобразование ID, дат, чисел)
5. Вставка в PostgreSQL с `ON CONFLICT DO NOTHING`
6. Логирование прогресса

## ⚠️ Важные замечания:

- Все методы **асинхронные** (async/await)
- Используется **безопасное преобразование** чисел с fallback на 0
- **Логирование** всех операций через `ILogger<T>`
- Обработка **исключений** с отправкой сообщений пользователю
- Кнопки становятся **неактивными** во время загрузки

## 🚀 Для развертывания:

```bash
# Сборка проекта
dotnet build

# Запуск
dotnet run

# Кнопки появятся на http://localhost:5000/Home/Index
```

Теперь вся логика TestConsole полностью интегрирована в веб-приложение! ✨
