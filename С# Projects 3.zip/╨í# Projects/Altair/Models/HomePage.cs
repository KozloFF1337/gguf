using System.ComponentModel.DataAnnotations.Schema;

[Table("HomePage")]
public class HomePage
{
    public HomePage()
    {
        year = 0;
        boilers_total = 0;
        turbins_total = 0;
        reservs_total_rub = 0;
        reservs_total_tut = 0;
        boilers_prisosi = 0;
        boilers_nedozhogi = 0;
        boilers_rs = 0;
        boilers_temp = 0;
        boilers_consumption = 0;
        turbins_vac = 0;
        turbins_rezhim = 0;
        turbins_temp_pv = 0;
        turbins_steam_temp = 0;
        turbins_steam_pressure = 0;
        turbins_steam_after_pp = 0;
        turbins_steam_in_reg = 0;
        turbins_neplan = 0;
        boilers_final_1 = 0;
        boilers_final_2 = 0;
        boilers_final_3 = 0;
        boilers_final_4 = 0;
        boilers_final_5 = 0;
        boilers_final_6 = 0;
        boilers_final_7 = 0;
        boilers_final_8 = 0;
        boilers_final_9 = 0;
        boilers_final_10 = 0;
        boilers_final_11 = 0;
        boilers_final_12 = 0;
        boilers_final_1_rub = 0;
        boilers_final_2_rub = 0;
        boilers_final_3_rub = 0;
        boilers_final_4_rub = 0;
        boilers_final_5_rub = 0;
        boilers_final_6_rub = 0;
        boilers_final_7_rub = 0;
        boilers_final_8_rub = 0;
        boilers_final_9_rub = 0;
        boilers_final_10_rub = 0;
        boilers_final_11_rub = 0;
        boilers_final_12_rub = 0;
        turbins_final_1 = 0;
        turbins_final_2 = 0;
        turbins_final_3 = 0;
        turbins_final_4 = 0;
        turbins_final_5 = 0;
        turbins_final_6 = 0;
        turbins_final_7 = 0;
        turbins_final_8 = 0;
        turbins_final_9 = 0;
        turbins_final_10 = 0;
        turbins_final_11 = 0;
        turbins_final_12 = 0;
        turbins_final_1_rub = 0;
        turbins_final_2_rub = 0;
        turbins_final_3_rub = 0;
        turbins_final_4_rub = 0;
        turbins_final_5_rub = 0;
        turbins_final_6_rub = 0;
        turbins_final_7_rub = 0;
        turbins_final_8_rub = 0;
        turbins_final_9_rub = 0;
        turbins_final_10_rub = 0;
        turbins_final_11_rub = 0;
        turbins_final_12_rub = 0;
    }
    public HomePage(int year, double boilers_total, double turbins_total, double reservs_total_rub, double reservs_total_tut, double boilers_prisosi, double boilers_nedozhogi, double boilers_rs, double boilers_temp, double boilers_consumption, double turbins_vac, double turbins_rezhim, double turbins_temp_pv, double turbins_steam_temp, double turbins_steam_pressure, double turbins_steam_after_pp, double turbins_steam_in_reg, double turbins_neplan, double boilers_final_1, double boilers_final_2, double boilers_final_3, double boilers_final_4, double boilers_final_5, double boilers_final_6, double boilers_final_7, double boilers_final_8, double boilers_final_9, double boilers_final_10, double boilers_final_11, double boilers_final_12, double boilers_final_1_rub, double boilers_final_2_rub, double boilers_final_3_rub, double boilers_final_4_rub, double boilers_final_5_rub, double boilers_final_6_rub, double boilers_final_7_rub, double boilers_final_8_rub, double boilers_final_9_rub, double boilers_final_10_rub, double boilers_final_11_rub, double boilers_final_12_rub, double turbins_final_1, double turbins_final_2, double turbins_final_3, double turbins_final_4, double turbins_final_5, double turbins_final_6, double turbins_final_7, double turbins_final_8, double turbins_final_9, double turbins_final_10, double turbins_final_11, double turbins_final_12, double turbins_final_1_rub, double turbins_final_2_rub, double turbins_final_3_rub, double turbins_final_4_rub, double turbins_final_5_rub, double turbins_final_6_rub, double turbins_final_7_rub, double turbins_final_8_rub, double turbins_final_9_rub, double turbins_final_10_rub, double turbins_final_11_rub, double turbins_final_12_rub)
    {
        this.year = year;
        this.boilers_total = boilers_total;
        this.turbins_total = turbins_total;
        this.reservs_total_rub = reservs_total_rub;
        this.reservs_total_tut = reservs_total_tut;
        this.boilers_prisosi = boilers_prisosi;
        this.boilers_nedozhogi = boilers_nedozhogi;
        this.boilers_rs = boilers_rs;
        this.boilers_temp = boilers_temp;
        this.boilers_consumption = boilers_consumption;
        this.turbins_vac = turbins_vac;
        this.turbins_rezhim = turbins_rezhim;
        this.turbins_temp_pv = turbins_temp_pv;
        this.turbins_steam_temp = turbins_steam_temp;
        this.turbins_steam_pressure = turbins_steam_pressure;
        this.turbins_steam_after_pp = turbins_steam_after_pp;
        this.turbins_steam_in_reg = turbins_steam_in_reg;
        this.turbins_neplan = turbins_neplan;
        this.boilers_final_1 = boilers_final_1;
        this.boilers_final_2 = boilers_final_2;
        this.boilers_final_3 = boilers_final_3;
        this.boilers_final_4 = boilers_final_4;
        this.boilers_final_5 = boilers_final_5;
        this.boilers_final_6 = boilers_final_6;
        this.boilers_final_7 = boilers_final_7;
        this.boilers_final_8 = boilers_final_8;
        this.boilers_final_9 = boilers_final_9;
        this.boilers_final_10 = boilers_final_10;
        this.boilers_final_11 = boilers_final_11;
        this.boilers_final_12 = boilers_final_12;
        this.boilers_final_1_rub = boilers_final_1_rub;
        this.boilers_final_2_rub = boilers_final_2_rub;
        this.boilers_final_3_rub = boilers_final_3_rub;
        this.boilers_final_4_rub = boilers_final_4_rub;
        this.boilers_final_5_rub = boilers_final_5_rub;
        this.boilers_final_6_rub = boilers_final_6_rub;
        this.boilers_final_7_rub = boilers_final_7_rub;
        this.boilers_final_8_rub = boilers_final_8_rub;
        this.boilers_final_9_rub = boilers_final_9_rub;
        this.boilers_final_10_rub = boilers_final_10_rub;
        this.boilers_final_11_rub = boilers_final_11_rub;
        this.boilers_final_12_rub = boilers_final_12_rub;
        this.turbins_final_1 = turbins_final_1;
        this.turbins_final_2 = turbins_final_2;
        this.turbins_final_3 = turbins_final_3;
        this.turbins_final_4 = turbins_final_4;
        this.turbins_final_5 = turbins_final_5;
        this.turbins_final_6 = turbins_final_6;
        this.turbins_final_7 = turbins_final_7;
        this.turbins_final_8 = turbins_final_8;
        this.turbins_final_9 = turbins_final_9;
        this.turbins_final_10 = turbins_final_10;
        this.turbins_final_11 = turbins_final_11;
        this.turbins_final_12 = turbins_final_12;
        this.turbins_final_1_rub = turbins_final_1_rub;
        this.turbins_final_2_rub = turbins_final_2_rub;
        this.turbins_final_3_rub = turbins_final_3_rub;
        this.turbins_final_4_rub = turbins_final_4_rub;
        this.turbins_final_5_rub = turbins_final_5_rub;
        this.turbins_final_6_rub = turbins_final_6_rub;
        this.turbins_final_7_rub = turbins_final_7_rub;
        this.turbins_final_8_rub = turbins_final_8_rub;
        this.turbins_final_9_rub = turbins_final_9_rub;
        this.turbins_final_10_rub = turbins_final_10_rub;
        this.turbins_final_11_rub = turbins_final_11_rub;
        this.turbins_final_12_rub = turbins_final_12_rub;
    }

    public int year { get; set; }
    public double boilers_total { get; set; }
    public double turbins_total { get; set; }
    public double reservs_total_rub { get; set; }
    public double reservs_total_tut { get; set; }
    public double boilers_prisosi { get; set; }
    public double boilers_nedozhogi { get; set; }
    public double boilers_rs { get; set; }
    public double boilers_temp { get; set; }
    public double boilers_consumption { get; set; }
    public double turbins_vac { get; set; }
    public double turbins_rezhim { get; set; }
    public double turbins_temp_pv { get; set; }
    public double turbins_steam_temp { get; set; }
    public double turbins_steam_pressure { get; set; }
    public double turbins_steam_after_pp { get; set; }
    public double turbins_steam_in_reg { get; set; }
    public double turbins_neplan { get; set; }
    public double boilers_final_1 { get; set; }
    public double boilers_final_2 { get; set; }
    public double boilers_final_3 { get; set; }
    public double boilers_final_4 { get; set; }
    public double boilers_final_5 { get; set; }
    public double boilers_final_6 { get; set; }
    public double boilers_final_7 { get; set; }
    public double boilers_final_8 { get; set; }
    public double boilers_final_9 { get; set; }
    public double boilers_final_10 { get; set; }
    public double boilers_final_11 { get; set; }
    public double boilers_final_12 { get; set; }
    public double boilers_final_1_rub { get; set; }
    public double boilers_final_2_rub { get; set; }
    public double boilers_final_3_rub { get; set; }
    public double boilers_final_4_rub { get; set; }
    public double boilers_final_5_rub { get; set; }
    public double boilers_final_6_rub { get; set; }
    public double boilers_final_7_rub { get; set; }
    public double boilers_final_8_rub { get; set; }
    public double boilers_final_9_rub { get; set; }
    public double boilers_final_10_rub { get; set; }
    public double boilers_final_11_rub { get; set; }
    public double boilers_final_12_rub { get; set; }
    public double turbins_final_1 { get; set; }
    public double turbins_final_2 { get; set; }
    public double turbins_final_3 { get; set; }
    public double turbins_final_4 { get; set; }
    public double turbins_final_5 { get; set; }
    public double turbins_final_6 { get; set; }
    public double turbins_final_7 { get; set; }
    public double turbins_final_8 { get; set; }
    public double turbins_final_9 { get; set; }
    public double turbins_final_10 { get; set; }
    public double turbins_final_11 { get; set; }
    public double turbins_final_12 { get; set; }
    public double turbins_final_1_rub { get; set; }
    public double turbins_final_2_rub { get; set; }
    public double turbins_final_3_rub { get; set; }
    public double turbins_final_4_rub { get; set; }
    public double turbins_final_5_rub { get; set; }
    public double turbins_final_6_rub { get; set; }
    public double turbins_final_7_rub { get; set; }
    public double turbins_final_8_rub { get; set; }
    public double turbins_final_9_rub { get; set; }
    public double turbins_final_10_rub { get; set; }
    public double turbins_final_11_rub { get; set; }
    public double turbins_final_12_rub { get; set; }

    public static (HomePage homepage, string Error) Create(int year, double boilers_total, double turbins_total, double reservs_total_rub, double reservs_total_tut, double boilers_prisosi, double boilers_nedozhogi, double boilers_rs, double boilers_temp, double boilers_consumption, double turbins_vac, double turbins_rezhim, double turbins_temp_pv, double turbins_steam_temp, double turbins_steam_pressure, double turbins_steam_after_pp, double turbins_steam_in_reg, double turbins_neplan, double boilers_final_1, double boilers_final_2, double boilers_final_3, double boilers_final_4, double boilers_final_5, double boilers_final_6, double boilers_final_7, double boilers_final_8, double boilers_final_9, double boilers_final_10, double boilers_final_11, double boilers_final_12, double boilers_final_1_rub, double boilers_final_2_rub, double boilers_final_3_rub, double boilers_final_4_rub, double boilers_final_5_rub, double boilers_final_6_rub, double boilers_final_7_rub, double boilers_final_8_rub, double boilers_final_9_rub, double boilers_final_10_rub, double boilers_final_11_rub, double boilers_final_12_rub, double turbins_final_1, double turbins_final_2, double turbins_final_3, double turbins_final_4, double turbins_final_5, double turbins_final_6, double turbins_final_7, double turbins_final_8, double turbins_final_9, double turbins_final_10, double turbins_final_11, double turbins_final_12, double turbins_final_1_rub, double turbins_final_2_rub, double turbins_final_3_rub, double turbins_final_4_rub, double turbins_final_5_rub, double turbins_final_6_rub, double turbins_final_7_rub, double turbins_final_8_rub, double turbins_final_9_rub, double turbins_final_10_rub, double turbins_final_11_rub, double turbins_final_12_rub)
    {
        var error = string.Empty;
        if (year < 1)
        {
            error = "Incorrect value for year";
        }
        var homePage = new HomePage(year, boilers_total, turbins_total, reservs_total_rub, reservs_total_tut, boilers_prisosi, boilers_nedozhogi, boilers_rs, boilers_temp, boilers_consumption, turbins_vac, turbins_rezhim, turbins_temp_pv, turbins_steam_temp, turbins_steam_pressure, turbins_steam_after_pp, turbins_steam_in_reg, turbins_neplan, boilers_final_1, boilers_final_2, boilers_final_3, boilers_final_4, boilers_final_5, boilers_final_6, boilers_final_7, boilers_final_8, boilers_final_9, boilers_final_10, boilers_final_11, boilers_final_12, boilers_final_1_rub, boilers_final_2_rub, boilers_final_3_rub, boilers_final_4_rub, boilers_final_5_rub, boilers_final_6_rub, boilers_final_7_rub, boilers_final_8_rub, boilers_final_9_rub, boilers_final_10_rub, boilers_final_11_rub, boilers_final_12_rub, turbins_final_1, turbins_final_2, turbins_final_3, turbins_final_4, turbins_final_5, turbins_final_6, turbins_final_7, turbins_final_8, turbins_final_9, turbins_final_10, turbins_final_11, turbins_final_12, turbins_final_1_rub, turbins_final_2_rub, turbins_final_3_rub, turbins_final_4_rub, turbins_final_5_rub, turbins_final_6_rub, turbins_final_7_rub, turbins_final_8_rub, turbins_final_9_rub, turbins_final_10_rub, turbins_final_11_rub, turbins_final_12_rub);
        return (homePage, error);
    }
    
};