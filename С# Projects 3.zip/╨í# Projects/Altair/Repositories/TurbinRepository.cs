using System.Collections.Generic;
using System.Threading.Tasks;
using Altair.Models;
using Microsoft.EntityFrameworkCore;

using Altair.Data;
public class TurbinRepository : ITurbinRepository
{
    private readonly TurbinDbContext _context;
    public TurbinRepository(TurbinDbContext context)
    {
        _context = context;
    }

    public async Task<List<Turbin>> GetTurbins(PeriodType periodType)
    {
        // Возвращаем данные с максимальной датой для данного типа периода
        // Фильтруем по PeriodValue > 0 (hours > 0)
        var maxDate = await _context.Set<Turbin>()
            .Where(t => t.PeriodType == periodType && t.Date != null && t.PeriodValue > 0)
            .MaxAsync(t => (DateTime?)t.Date);

        if (maxDate == null)
        {
            return new List<Turbin>();
        }

        return await _context.Set<Turbin>()
            .Where(t => t.PeriodType == periodType && t.Date == maxDate && t.PeriodValue > 0)
            .ToListAsync();
    }

    public async Task<List<Turbin>> GetTurbinsByDate(PeriodType periodType, DateTime date)
    {
        // Фильтруем по PeriodValue > 0 (hours > 0)
        return await _context.Set<Turbin>()
            .Where(t => t.PeriodType == periodType && t.Date == date.Date && t.PeriodValue > 0)
            .ToListAsync();
    }

    public async Task<List<DateTime>> GetAvailableDates(PeriodType periodType)
    {
        // Возвращаем только даты где есть данные с PeriodValue > 0 (hours > 0)
        return await _context.Set<Turbin>()
            .Where(t => t.PeriodType == periodType && t.Date != null && t.PeriodValue > 0)
            .Select(t => t.Date!.Value)
            .Distinct()
            .OrderByDescending(d => d)
            .ToListAsync();
    }
}
