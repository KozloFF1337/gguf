public class WeekTurbin
{
    WeekTurbin(int stationID, string turbinID, double consumption, double URT)
    {
        this.stationID = stationID;
        this.turbinID = turbinID;
        Consumption = consumption;
        this.URT = URT;
    }
    public WeekTurbin()
    {
        stationID = 0;
        turbinID = "0";
        Consumption = 0;
        URT = 0;
    }
    public int stationID { get; set; }
    public string turbinID { get; set; }
    public double Consumption { get; set; }
    public double URT { get; set; }
    public static (WeekTurbin WeekTurbin, string Error) Create(int stationID, string turbinID, double consumption, double URT)
    {
        var error = string.Empty;
        if (string.IsNullOrEmpty(turbinID))
        {
            error = "Wrong value for turbinID";
        }
        var weekTurbin = new WeekTurbin(stationID, turbinID, consumption, URT);
        return (weekTurbin, error);
    }
} 