public class WeekBoiler
{
    public WeekBoiler()
    {
        BoilerID = "0";
        StationID = 0;
        KPD = 0;
        Production = 0;
    }
    public WeekBoiler(string boilerID, int stationID, double kpd, double production)
    {
        BoilerID = boilerID;
        StationID = stationID;
        KPD = kpd;
        Production = production;
    }

    public string BoilerID { get; set; }
    public int StationID { get; set; }
    public double KPD { get; set; }
    public double Production { get; set; }

    public static (WeekBoiler WeekBoiler, string Error) Create(string boilerID, int stationID, double kpd, double production)
    {
        var error = string.Empty;
        if (string.IsNullOrEmpty(boilerID))
        {
            error = "Wrong value for boilerID";
        }
        var weekBoiler = new WeekBoiler(boilerID, stationID, kpd, production);
        return (weekBoiler, error);
    }
};