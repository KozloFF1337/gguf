﻿using System;
using System.Data;
using System.Runtime.CompilerServices;
using Microsoft.Data.SqlClient;
using Npgsql;


using (NpgsqlConnection connection1 = new NpgsqlConnection(SQL_config.connectionStringPGSQL))
{
    try
    {
        DateTime dt = DateTime.Now.AddDays(-9);
        string select_KA = $@"SELECT *
                FROM boilers
                WHERE (boilerid, stationid) IN (
                    SELECT boilerid, stationid
                        FROM boilers
                        WHERE date > '{dt.Year + "-" + dt.Month + "-" + dt.Day}' AND hours = 24
                        GROUP BY boilerid, stationid
                        HAVING COUNT(*) > 3
                        AND NOT EXISTS (
                            SELECT 1
                            FROM boilers AS t2
                            WHERE t2.boilerid = boilers.boilerid
                            AND t2.stationid = boilers.stationid
                            AND t2.hours <> 24
                            AND t2.date = (SELECT MAX(date)
                                            FROM boilers AS t3
                                            WHERE t3.boilerid = t2.boilerid
                                            AND t3.stationid = t2.stationid)
                            )) and date > '{dt.Year + "-" + dt.Month + "-" + dt.Day}' AND hours = 24
                            ORDER BY stationid, boilerid, date;";
        string select_TA = $@"SELECT *
                FROM turbins
                WHERE (turbinid, stationid) IN (
                    SELECT turbinid, stationid
                        FROM turbins
                        WHERE date > '{dt.Year + "-" + dt.Month + "-" + dt.Day}' AND hours = 24
                        GROUP BY turbinid, stationid
                        HAVING COUNT(*) > 3
                        AND NOT EXISTS (
                            SELECT 1
                            FROM turbins AS t2
                            WHERE t2.turbinid = turbins.turbinid
                            AND t2.stationid = turbins.stationid
                            AND t2.hours <> 24
                            AND t2.date = (SELECT MAX(date)
                                            FROM turbins AS t3
                                            WHERE t3.turbinid = t2.turbinid
                                            AND t3.stationid = t2.stationid)
                            )) and date > '{dt.Year + "-" + dt.Month + "-" + dt.Day}' AND hours = 24
                                        ORDER BY stationid, turbinid, date;";
        using (SqlConnection connection = new SqlConnection(SQL_config.connectionString))
        {
            connection.Open();
            connection1.Open();
            DBFunctions.GenerateDB_KA(Akscodes.rec_KA, Akscodes.matching_dict_KA, SQL_config.insertQuerry_KA, SQL_config.format, connection1, connection);
            Console.WriteLine("Сделано -1");
            DBFunctions.GenerateDB_TA(Akscodes.rec_TA, Akscodes.matching_dict_TA, SQL_config.insertQuerry_TA, SQL_config.format, connection1, connection);
            Console.WriteLine("Сделано 0");
            DBFunctions.GetRelevantData_TA(Akscodes.rec_WT, Akscodes.weekTurbins, select_TA, connection1, connection);
            Console.WriteLine("Сделано 1");
            DBFunctions.GetRelevantData_KA(Akscodes.rec_WB, Akscodes.weekBoilers, select_KA, connection1, connection);
            Console.WriteLine("Сделано 2");
            DBFunctions.InsertFinalData_TA(SQL_config.truncate_week_TA, SQL_config.insertQuerry_week_TA, Akscodes.weekTurbins, connection1);
            Console.WriteLine("Сделано 3");
            DBFunctions.InsertFinalData_KA(SQL_config.truncate_week_KA, SQL_config.insertQuerry_week_KA, Akscodes.weekBoilers, connection1);
            Console.WriteLine("Сделано 4");
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Ошибка: {ex.Message} ");
    }
}

