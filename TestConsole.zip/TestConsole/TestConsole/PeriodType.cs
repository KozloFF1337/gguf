namespace Altair.Models
{
    public enum PeriodType
    {
        Week,
        Month,
        Year
    }
}
